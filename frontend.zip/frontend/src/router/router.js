import { createRouter, createWebHistory } from 'vue-router'

const routes = [
    {
        path: '/login',
        name: '登录',
        component:()=>import('@/views/login.vue')
    },
    {
        path: '/',
        name: '首页',
        component: ()=>import('@/views/index.vue'),
        meta: { requiresAuth: true }, // 添加登录状态验证标识
    },
    {
        path: '/customer',
        name: '客户服务中心',
        component: ()=>import('@/views/index.vue'),
        // meta: {title:'客户服务中心'},
        children:[
            {
                path: '/cusinfo',
                name: '客户信息管理',
                component: () => import('@/views/customer/CustomerInfo.vue'),
                // meta: {title:'客户信息管理'}
            },
            {
                path: '/operator-work-statistics',
                name: '操作员工作统计',
                component: () => import('@/views/customer/OperatorWorkSta.vue'),
            },
            {
                path: '/order',
                name: '订单管理',
                // component: () => import('@/views/index.vue'),
                children:[
                    {
                        path: 'ordinfo',
                        name: '订单信息查询',
                        component: () => import('@/views/customer/order/OrderInfo.vue'),
                    },
                    {
                        path: 'neword',
                        name: '新订',
                        redirect: '/neword/customer-query',
                        component: () => import('@/views/customer/order/NewOrder.vue'),
                        children:[
                            {
                                path: '/neword/customer-query',
                                name: '客户查询',
                                component: ()=> import('@/components/nOrderSteps/CustomerQuery.vue')
                            },
                            {
                                path: '/neword/delivery-info',
                                name: '配送信息',
                                component: ()=> import('@/components/nOrderSteps/DeliveryInfo.vue')
                            },
                            {
                                path: '/neword/item-info',
                                name: '商品信息',
                                component: ()=> import('@/components/nOrderSteps/ItemInfo.vue')
                            },
                            {
                                path: '/neword/finish',
                                name: '完成',
                                component: ()=> import('@/components/nOrderSteps/Finish.vue')
                            }
                        ]
                    },
                    {
                        path: 'returnord',
                        name: '退货订单',
                        redirect: '/returnord/return-customer-query',
                        component: () => import('@/views/customer/order/ReturnOrder.vue'),
                        children:[
                            {
                                path: '/returnord/return-customer-query',
                                name: '退货客户查询',
                                component: ()=> import('@/components/nOrderSteps/ReturnCustomerQuery.vue')
                            },
                            {
                                path: '/returnord/return-delivery-info',
                                name: '退货配送信息',
                                component: ()=> import('@/components/nOrderSteps/ReturnDeliveryInfo.vue')
                            },
                            {
                                path: '/returnord/return-finish',
                                name: '退货完成',
                                component: ()=> import('@/components/nOrderSteps/ReturnFinish.vue')
                            }
                        ]
                    },
                    {
                        path: 'exchangeord',
                        name: '换货订单',
                        redirect: '/exchangeord/exchange-customer-query',
                        component: () => import('@/views/customer/order/ExchangeOrder.vue'),
                        children:[
                            {
                                path: '/exchangeord/exchange-customer-query',
                                name: '换货客户查询',
                                component: ()=> import('@/components/nOrderSteps/ExchangeCustomerQuery.vue')
                            },
                            {
                                path: '/exchangeord/exchange-delivery-info',
                                name: '换货配送信息',
                                component: ()=> import('@/components/nOrderSteps/ExchangeDeliveryInfo.vue')
                            },
                            {
                                path: '/exchangeord/exchange-finish',
                                name: '换货完成',
                                component: ()=> import('@/components/nOrderSteps/ExchangeFinish.vue')
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        path:'/dispatcher',
        name:'调度中心',
        component: ()=>import('@/views/index.vue'),
        children:[
            {
                path: '/orderDis',
                name: '订单调度',
                children: [
                    {
                        path: 'auto',
                        name: '自动调度',
                        component: () => import('@/views/dispatcher/orderDis/auto.vue')
                    },
                    {
                        path: 'manual',
                        name: '手动调度',
                        component: () => import('@/views/dispatcher/orderDis/manual.vue')
                    }
                ]
            },
            {
                path: '/task-info',
                name: '任务单的查询',
                component: () => import('@/views/dispatcher/TaskInfo.vue')
            },
            {
                path: '/modify-order-state',
                name: '订单状态修改',
                component: ()=>import('@/views/dispatcher/ModifyOrdSta.vue')
            }
        ]
    },
    {
        path: '/warehouseManagement',
        name: '库房总管理',
        component:() =>import('@/views/index.vue'),
        children: [
            {
                path: '/center-in',
                name: '中心库房进货入库',
                component: () =>import('@/views/warehouse/CenIn.vue')
            },
            {
                path: '/center-out',
                name: '中心库房调拨出库',
                component: () =>import('@/views/warehouse/CenOut.vue')
            },
            {
                path: '/fetch-item',
                name: '领货',
                component: () =>import('@/views/warehouse/FetchItem.vue')
            },
            {
                path: '/sub-in',
                name: '分站库房调拨入库',
                component: () =>import('@/views/warehouse/SubIn.vue')
            },
            {
                path: '/print-launch-order',
                name: '打印分发单',
                component: () =>import('@/views/warehouse/PrintLaunchOrder.vue')
            },
            {
                path: '/print-out-order',
                name: '打印出库单',
                component: () =>import('@/views/warehouse/PrintOutOrder.vue')
            },
            {
                path: '/return-man',
                name:'退货管理',
                children: [
                    {
                        path: 'return-in-substation',
                        name: '退货分站',
                        component: () =>import('@/views/warehouse/ReturnInSubstation.vue')
                    },
                    {
                        path:'return-out-substation',
                        name:'退货出库',
                        component:()=>import('@/views/warehouse/ReturnOutSubstation.vue')
                    },
                    {
                        path:'return-in-center',
                        name: '退货入库',
                        component:()=>import('@/views/warehouse/ReturnInCenter.vue')
                    },
                    {
                        path:'return-out-center',
                        name:'中心出库',
                        component:()=>import('@/views/warehouse/ReturnOutCenter.vue')
                    }
                ]
            }
        ]
    },
    {
        path: '/substation',
        name: '分站管理',
        component: () => import('@/views/index.vue'),
        children: [
            {
                path: '/payment-query',
                name: '缴款查询',
                component: () => import('@/views/substation/PayQuery.vue')
            },
            {
                path: '/receipt',
                name: '回执录入',
                component: () => import('@/views/substation/Receipt.vue')
            },
            {
                path: '/task-assignment',
                name: '任务分配',
                component: () => import('@/views/substation/TaskAssign.vue')
            },
            {
                path: '/task-assignment-modification',
                name: '任务分配修改',
                component: () => import('@/views/substation/TaskAssModified.vue')
            },
            {
                path: '/task-query',
                name: '任务单查询',
                component: () => import('@/views/substation/TaskQuery.vue')
            },
            {
                path:'/print-signature-form',
                name:'打印配送单',
                component: () => import('@/views/substation/PrintSignatureForm.vue')
            },
            {
                path:'/invoice-man',
                name:'发票管理',
                component: () => import('@/views/substation/InvoiceMan.vue')
            }
        ]
    },
    {
        path: '/distributer',
        name: '配送中心管理',
        component: () => import('@/views/index.vue'),
        children: [
            {
                path: '/business-man',
                name: '业务管理',
                children: [
                    {
                        path: 'customer-satisfication-analysis',
                        name: '客户满意度分析',
                        component: () => import('@/views/distributer/businessMan/CusSatAna.vue')
                    },
                    {
                        path: 'deliver-analysis',
                        name: '分站配送情况分析',
                        component: () => import('@/views/distributer/businessMan/DelvAna.vue')
                    },
                    {
                        path: 'rank-query',
                        name: '订购排行榜查询',
                        component: () => import('@/views/distributer/businessMan/RankQuery.vue')
                    }
                ]
            },
            {
                path: '/warehouse-man',
                name: '库房管理',
                children: [
                    {
                        path: 'inout-query',
                        name: '出入库查询',
                        component: () => import('@/views/distributer/whouseMan/InOutQuery.vue')
                    },
                    {
                        path: 'inventory-query',
                        name: '库存量查询',
                        component: () => import('@/views/distributer/whouseMan/InventoryQuery.vue')
                    },
                    {
                        path: 'warehouse-set',
                        name: '库房设置',
                        component: () => import('@/views/distributer/whouseMan/WarehouseSet.vue')
                    },
                    {
                        path: 'warehouse-store-set',
                        name: '库房储备设置',
                        component: () => import('@/views/distributer/whouseMan/WarehouseStoreSet.vue')
                    }
                ]
            },
            {
                path: '/item-man',
                name: '商品管理',
                children: [
                    {
                        path: 'class-one-item',
                        name: '商品一级分类管理',
                        component: () => import('@/views/distributer/itemMan/COneItem.vue')
                    },
                    {
                        path: 'class-two-item',
                        name: '商品二级分类管理',
                        component: () => import('@/views/distributer/itemMan/CTwoItem.vue')
                    },
                    {
                        path: 'man-item',
                        name: '商品管理',
                        component: () => import('@/views/distributer/itemMan/ItemMan.vue')
                    }
                ]
            },
            {
                path: '/provider-man',
                name: '供应商管理',
                component: () => import('@/views/distributer/ProviderMan.vue')
            },
            {
                path: '/stock-out',
                name: '缺货进货',
                component: () => import('@/views/distributer/StockOut.vue')
            },
            {
                path: '/warn-out',
                name: '预警进货',
                component: () => import('@/views/distributer/WarnOut.vue')
            }
        ]
    },
    {
        path:'/finance',
        name:'财务管理',
        component:()=>import('@/views/index.vue'),
        children: [
            {
                path: '/supplier-deal',
                name: '供应商结算',
                component: () => import('@/views/finance/SupplierDeal.vue')
            },
            {
                path: '/invoice-adm',
                name: '发票的管理',
                component: () => import('@/views/finance/InvoiceAdm.vue')
            },
            {
                path: '/substation-deal',
                name: '分站结算',
                component: () => import('@/views/finance/SubstationDeal.vue')
            }

        ]
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

// 添加导航守卫用于验证登录状态
router.beforeEach((to, from, next) => {
    const isLoggedIn =  localStorage.getItem('isLoggedIn') === 'true'// 这里需要根据实际的登录状态进行判断
    if (to.matched.some(record => record.meta.requiresAuth)) {
        if (isLoggedIn) {
            next();
        } else {
            next('/login'); // 未登录则跳转到登录页面
        }
    } else {
        next();
    }
})

export default router
