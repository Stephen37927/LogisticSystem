import './assets/theme/index.css'
import './assets/theme/fonts/font-test.css'

import './assets/theme/fonts/font-test.css'
import locale from 'element-plus/es/locale/lang/zh-cn'




import { createApp } from 'vue'
import App from './App.vue'
import router from './router/router'
// import store from './store'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
// import './assets/global.css'
import * as ElIcons from '@element-plus/icons-vue'
import request from './request/request'
import * as JsonExcel from 'vue-json-excel'
//import echarts from "echarts";
import * as echarts from 'echarts'


const app = createApp(App)
for (const icname in ElIcons){
    app.component(icname,ElIcons[icname])
}

app.config.globalProperties.$echarts = echarts
// app.prototype.$echarts = echarts;
app.component('downloadExcel', JsonExcel)
app.config.globalProperties.$http = request
app.use(router)
app.use(ElementPlus, {
    locale})
app.use(ElementPlus,{size: 'default'})
app.mount('#app')
