<script lang="ts" setup>


import {
  Document,
  Menu as IconMenu,
  Location,
  Setting, UserFilled,
} from '@element-plus/icons-vue'

const handleOpen = (key: string, keyPath: string[]) => {
  console.log("key:"+key)
  console.log("keyPath:"+keyPath)
}
const handleClose = (key: string, keyPath: string[]) => {
  console.log(key, keyPath)

}
</script>

<template>
  <el-menu
      default-active="/index"
      class="el-menu-vertical-demo"

      @open="handleOpen"
      @close="handleClose"
      active-text-weight="bold"
      :router="true"


      background-color="#ededed"
      style="border-color: white;"
      text-color="#434146"

  >

    <el-menu-item index="/">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>首页</span>
      </template>
    </el-menu-item>

    <el-sub-menu index="/customer">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>客户服务中心</span>
      </template>
      <el-menu-item index="/cusinfo">客户信息查询</el-menu-item>
      <el-menu-item index="/operator-work-statistics">操作员工作统计</el-menu-item>
      <el-sub-menu index="/order">
        <template #title>订单管理</template>
          <el-menu-item index="/order/ordinfo">订单信息查询</el-menu-item>
          <el-menu-item index="/order/neword">新订</el-menu-item>
        <el-menu-item index="/order/returnord">退货订单</el-menu-item>
        <el-menu-item index="/order/exchangeord">换货订单</el-menu-item>
      </el-sub-menu>
    </el-sub-menu>

    <el-sub-menu index="/substation">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>分站管理</span>
      </template>
      <el-menu-item index="/payment-query">缴款查询</el-menu-item>
      <el-menu-item index="/receipt">回执录入</el-menu-item>
      <el-menu-item index="/task-assignment">任务分配</el-menu-item>
<!--      <el-menu-item index="/task-assignment-modification">任务分配修改</el-menu-item>-->
      <el-menu-item index="/task-query">任务单查询</el-menu-item>
      <el-menu-item index="/print-signature-form">打印配送单</el-menu-item>
      <el-menu-item index="/invoice-man">发票管理</el-menu-item>

    </el-sub-menu>

    <el-sub-menu index="/warehouseManagement">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>库房管理</span>
      </template>
      <el-menu-item index="/center-in">中心库房进货入库</el-menu-item>
      <el-menu-item index="/center-out">中心库房调拨出库</el-menu-item>
      <el-menu-item index="/print-out-order">打印出库单</el-menu-item>
      <el-menu-item index="/print-launch-order">打印分发单</el-menu-item>
      <el-menu-item index="/sub-in">分站库房调拨入库</el-menu-item>
      <el-menu-item index="/fetch-item">领货</el-menu-item>
      <el-sub-menu index="/return-man">
        <template #title>退货管理</template>
        <el-menu-item index="/return-man/return-in-substation">分库房退货入库</el-menu-item>
        <el-menu-item index="/return-man/return-out-substation">分库房退货出库</el-menu-item>
        <el-menu-item index="/return-man/return-in-center">总库房退货入库</el-menu-item>
        <el-menu-item index="/return-man/return-out-center">总库房退货出库</el-menu-item>
      </el-sub-menu>
    </el-sub-menu>


<!--    调度中心-->
    <el-sub-menu index="/dispatcher">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>调度中心</span>
      </template>

      <el-sub-menu index="/orderDis">
        <template #title>订单调度</template>
        <el-menu-item index="/orderDis/auto">自动调度</el-menu-item>
        <el-menu-item index="/orderDis/manual">手工调度</el-menu-item>
      </el-sub-menu>
      <el-menu-item index="/task-info">任务单查询</el-menu-item>
      <el-menu-item index="/modify-order-state">订单状态修改</el-menu-item>
    </el-sub-menu>

<!--配送中心管理-->
    <el-sub-menu index="/distributer">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>配送中心管理</span>
      </template>
      <el-sub-menu index="/item-man">
        <template #title>商品管理</template>
        <el-menu-item index="/item-man/class-one-item">一级商品管理</el-menu-item>
        <el-menu-item index="/item-man/class-two-item">二级商品管理</el-menu-item>
        <el-menu-item index="/item-man/man-item">商品管理</el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/warehouse-man">
        <template #title>库房管理</template>
        <el-menu-item index="/warehouse-man/inout-query">出入库查询</el-menu-item>
        <el-menu-item index="/warehouse-man/inventory-query">库存量查询</el-menu-item>
        <el-menu-item index="/warehouse-man/warehouse-set">库房设置</el-menu-item>
        <el-menu-item index="/warehouse-man/warehouse-store-set">库存储备设置</el-menu-item>
      </el-sub-menu>
      <el-menu-item index="/provider-man">供应商管理</el-menu-item>
      <el-menu-item index="/stock-out">缺货进货</el-menu-item>
      <el-menu-item index="/warn-out">预警进货</el-menu-item>
      <el-menu-item index="/warn-out">过往销量统计</el-menu-item>
    </el-sub-menu>

<!--    财务管理-->
    <el-sub-menu index="/finance">
      <template #title>
        <el-icon><icon-menu/></el-icon>
        <span>财务管理</span>
      </template>
      <el-menu-item index="/supplier-deal">供应商结算</el-menu-item>
      <el-menu-item index="/invoice-adm">发票管理</el-menu-item>
      <el-menu-item index="/substation-deal">分站结算</el-menu-item>
    </el-sub-menu>
  </el-menu>
</template>

<style>
body {
  margin: 0;
  padding: 0;
}
.el-menu-vertical-demo {
  float: left;
  top: 0;
  left: 0;
  height: 100vh;
  //width: 200px;
  //height: 900px;
}
</style>
