<script>
export default {
  name: 'return-finish',
  data() {
    return {

    }
  },
  methods: {
    // 点击上一步
    handlePrev() {
      this.$emit('handlePrev')
    },

  }
}
</script>

<template>
完成
  <div class="finish">
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handlePrev()">上一步</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
