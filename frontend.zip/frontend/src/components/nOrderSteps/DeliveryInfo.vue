<script>
import router from '@/router/router'
import {ElMessage} from "element-plus";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

let ipaddress = "/customerManagement"
let subIpaddress = "/substationManagement"

export default {
  name: 'delivery-info',
  data() {
    return {
      customer:{},
      form:{},
      delivery:{},
      obj:{},
      rules:{
        receiver:[{required:true,message:'请输入收货人姓名',trigger:'blur'}],
        receiverPhone:[{required:true,message:'请输入收货人手机号',trigger:'blur'}],
        generationDate: [{ required: true, message: '请选择生成日期', trigger: 'blur' }],
        requestArrivalDate: [{ required: true, message: '请选择要求完成日期', trigger: 'blur' }],
        deliveryAddress: [{ required: true, message: '请输入送货地址', trigger: 'blur' }],
        type: [{ required: true, message: '请选择订单类型', trigger: 'blur' }],
        receiverPostcode: [{ required: true, message: '请输入收货人邮编', trigger: 'blur' }],
        isReceipt: [{ required: true, message: '请选择是否需要发票', trigger: 'blur' }],

      },
      orderTypes:[
        {
          value: '1',
          label: '普通配送订单'
        },
        {
          value: '2',
          label: '换货单'
        },
        {
          value: '3',
          label: '退货单'
        },
        {
          value:'4',
          label:'退订单'
        }
      ],
      subStations:[],
    }
  },
  methods: {
    // 点击上一步
    handlePrev() {
      this.$emit('handlePrev')
    },
    // 点击下一步
    handleNext(resetForm) {
      console.log(resetForm)
      console.log(this.form)
      this.$refs[resetForm].validate((valid)=>{
        if(valid){
          this.obj.customer = this.customer;
          this.form.generationDate = this.filterTime(this.form.generationDate)
          this.form.requestArrivalDate = this.filterTime(this.form.requestArrivalDate)
          this.obj.delivery = this.form;
          console.log('delivery-info obj')
          console.log(this.obj)
          this.$emit('handleNext',this.obj);
        }
      })

    },
    getSubStations(){
      this.$http.get(subIpaddress+`/substation/getAllSubstation`
      ).then(res=>{
        if(res.code === '666'){
          console.log(res)
          this.subStations = res.data
        }
      }).catch(err=>{
        ElMessage.error('获取分站信息失败')
      })
    },
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
  },
  created(){
    console.log('delivery-info created')
    // console.log(this.$route.query)
    this.customer = this.$route.query
    console.log(this.customer)
    this.getSubStations();
  }
}
</script>

<template>
配送信息
  <div class="deliveryShow">
    <div class="deliveryInfo">
      <el-form :inline="true" :model="form" :rules="rules" ref="form" label-width="120px">
        <el-form-item label="客户名称">
          <el-input v-model="customer.name" disabled></el-input>
        </el-form-item>
        <el-form-item label="客户办公电话">
          <el-input v-model="customer.officePhone" disabled></el-input>
        </el-form-item>
        <el-form-item label="客户手机号码">
          <el-input v-model="customer.cellPhone" disabled></el-input>
        </el-form-item>
        <el-form-item label="客户工作单位">
          <el-input v-model="customer.company" disabled></el-input>
        </el-form-item>
        <el-form-item label="客户联系地址">
          <el-input v-model="customer.deliveryAddress" disabled></el-input>
        </el-form-item>
        <el-form-item label="客户邮政编码">
          <el-input v-model="customer.postcode" disabled></el-input>
        </el-form-item>
        <el-form-item label="接收人" prop="receiver">
          <el-input v-model="form.receiver" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="接收人电话" prop="receiverPhone">
          <el-input v-model="form.receiverPhone" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="订单类型" prop="type">
          <el-select v-model="form.type">
            <el-option
              v-for="item in orderTypes"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="订单生成日期" prop="generationDate">
          <el-date-picker
            v-model="form.generationDate"
            type="datetime"
            placeholder="选择日期"
            format="YYYY/MM/DD HH:mm:ss"
            autocomplete="off"
          />
        </el-form-item>
        <el-form-item item label="投递分站" prop="subStation">
          <el-select v-model="form.subStation">
            <el-option
              v-for="item in subStations"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="要求完成日期" prop="requestArrivalDate">
          <el-date-picker
            v-model="form.requestArrivalDate"
            type="datetime"
            placeholder="选择日期"
            format="YYYY/MM/DD HH:mm:ss"
          />
        </el-form-item>
        <el-form-item label="是否索取发票" prop="isReceipt">
          <el-radio-group v-model="form.isReceipt">
            <el-radio label="1">是</el-radio>
            <el-radio label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="送货地址" prop="deliveryAddress">
          <el-input v-model="form.deliveryAddress" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="接收人邮政编码" prop="receiverPostcode">
          <el-input v-model="form.receiverPostcode" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="备注信息" prop="comment">
          <el-input v-model="form.comment" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div style="text-align:center;margin-top:18px;">
        <el-button type="primary" @click="handlePrev()">上一步</el-button>
        <el-button type="primary" @click="handleNext('form')">下一步</el-button>
      </div>
    </div>

  </div>
</template>

<style scoped>
.el-select, .el-input_inner{
  //width: 150px;
  width: 10%;
}
</style>
