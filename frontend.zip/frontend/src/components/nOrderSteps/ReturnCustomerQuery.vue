<script>

import {ElMessage} from "element-plus";
import zhCn from 'element-plus/lib/locale/lang/zh-cn'

let ipaddress = "/customerManagement"

let requestData = {
  "name": "",
  "idCardNum":"",
  "company":"",
  "officePhone":"",
  "cellPhone":"",
  "postcode":"",
  "email":"",
  "deliveryAddress":"",
  "region":""
}

export default {
  name: 'return-customer-query',

  data(){
    return {
      name: '',
      cellPhone: '',
      idCardNum: '',
      locale: zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      isFound: false,
      notFound: false,
      dialogFormVisible: false,
      formLabelWidth: '100px',
      multipleSelection: [],
      customer:{},
      form: {},
      rules: {
        name: [{ required: true, message: '请输入客户姓名', trigger: 'blur' }],
        idCardNum:[{required: true, message: '请输入客户卡号', trigger: 'blur'}],
        company:[{required: true, message: '请输入公司', trigger: 'blur'}],
        officePhone:[{required: true, message: '请输入座机', trigger: 'blur'}],
        cellPhone:[{required: true, message: '请输入手机号', trigger: 'blur'}],
        postcode:[{required: true, message: '请输入邮编', trigger: 'blur'}],
        email:[{required: true, message: '请输入邮编', trigger: 'blur'}],
        deliveryAddress:[{required: true, message: '请输入收货地址', trigger: 'blur'}],
        region:[{required: true, message: '请输入地区', trigger: 'blur'}],
      }
    }
  },

  methods: {
    handleNext() {
      if(this.multipleSelection.length === 1){
        console.log(this.multipleSelection)
        this.customer.id = this.multipleSelection[0].id
        this.customer.name = this.multipleSelection[0].name
        this.customer.idCardNum = this.multipleSelection[0].idCardNum
        this.customer.company = this.multipleSelection[0].company
        this.customer.officePhone = this.multipleSelection[0].officePhone
        this.customer.cellPhone = this.multipleSelection[0].cellPhone
        this.customer.postcode = this.multipleSelection[0].postcode
        this.customer.email = this.multipleSelection[0].email
        this.customer.deliveryAddress = this.multipleSelection[0].deliveryAddress
        this.customer.region = this.multipleSelection[0].region
        this.$emit('handleNext',this.customer)
      }else if(this.multipleSelection.length === 0){
        ElMessage({
          message: '请选择一条数据！',
          type: 'warning',
        })
      }else{
        ElMessage({
          message: '只能选择一条数据！',
          type: 'warning',
        })
      }
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addData(resetForm){
      let dialogFormVisible = this.dialogFormVisible;
      if(dialogFormVisible){
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            this.$http.post(ipaddress+"/customer/addCustomer",this.form).then(res=>{
              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
    },
    network(){
      requestData.name = this.name;
      requestData.cellPhone = this.cellPhone;
      requestData.idCardNum = this.idCardNum;
      // console.log(ipaddress)
      this.$http.post(ipaddress+`/customer/getCustomerByQuery?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,requestData).then(res=>{
        console.log(res);
        if(res.code === '666'){
          this.tableData = res.data.list;
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}

        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    }
  },
  created() {
    console.log('created')
  }
}
</script>

<template>
客户信息查询
  <div class="customerShow">
    <el-input placeholder="请输入客户名称" style="width: 200px;padding: 10px;" v-model="name"></el-input>
    <el-input placeholder="请输入手机号码" style="width: 200px;padding: 10px;" v-model="cellPhone"></el-input>
    <el-input placeholder="请输入身份证号" style="width: 200px;padding: 10px;" v-model="idCardNum"></el-input>
    <el-button @click="network()">查找客户</el-button>
    <div v-if="isFound">
      <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed type="selection" width="80px" align="center"></el-table-column>
        <el-table-column fixed prop="id" label="id" width="80px" sortable align="center"></el-table-column>
        <el-table-column prop="name" label="客户名称" width="100px" align="center"></el-table-column>
        <el-table-column prop="idCardNum" label="卡号" width="150px" align="center"></el-table-column>
        <el-table-column prop="company" label="公司" width="80px" align="center"></el-table-column>
        <el-table-column prop="officePhone" label="座机" width="120px" align="center"></el-table-column>
        <el-table-column prop="cellPhone" label="手机" width="100px"  align="center"></el-table-column>
        <el-table-column prop="postcode" label="邮编" width="100px" align="center"></el-table-column>
        <el-table-column prop="email" label="邮箱" width="80px" align="center"></el-table-column>
        <el-table-column prop="deliveryAddress" label="收货地址" width="100px" align="center"></el-table-column>
        <el-table-column prop="region" label="地区" width="80px" align="center"></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <div v-if="notFound">
      没找到
      <br/>
      <el-button type="primary" @click="dialogFormVisible = true">新增客户</el-button>
      <el-dialog title="客户添加" v-model="dialogFormVisible" width="50%">
        <el-form :model="form" size="medium" :rules="rules" ref="form">
          <el-form-item label="客户姓名" :label-width="formLabelWidth" prop="name">
            <el-input v-model="form.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="卡号" :label-width="formLabelWidth" prop="idCardNum">
            <el-input v-model="form.idCardNum" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="公司" :label-width="formLabelWidth" prop="company">
            <el-input v-model="form.company" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="座机" :label-width="formLabelWidth" prop="officePhone">
            <el-input v-model="form.officePhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="手机" :label-width="formLabelWidth" prop="cellPhone">
            <el-input v-model="form.cellPhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">
            <el-input v-model="form.postcode" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
            <el-input v-model="form.email" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="收货地址" :label-width="formLabelWidth" prop="deliveryAddress">
            <el-input v-model="form.deliveryAddress" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="地区" :label-width="formLabelWidth" prop="region">
            <el-input v-model="form.region" autocomplete="off"></el-input>
          </el-form-item>

        </el-form>

        <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="addData('form')"> 确认</el-button>
      </span>
        </template>
      </el-dialog>
    </div>
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handleNext()">下一步</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
