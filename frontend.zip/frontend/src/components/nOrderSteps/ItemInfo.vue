<script>

import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage} from "element-plus";
import {CirclePlus, Search} from "@element-plus/icons-vue";

let ipaddress = "/customerManagement";
let disIpaddress = "/distributionManagement";

let requestData = { // Declare requestData as a global variable
  product: {
    id: '',
    name: "",
    description: "",
    firstProductId: '',
    secondProductId: '',
    unit: "",
    sellingPrice: '',
    discount: '',
    costPrice: '',
    supplierId: '',
    shelfLife: '',
    canReturn: "",
    canExchange: ""
  },
  secondProduct: {
    id: '',
    name: "",
    description: "",
    firstProductId: ''
  },
  firstProduct: {
    id: '',
    name: "",
    description: ""
  }
};

let orderRequest = {
  "type":"",
  "customerId":"",
  "receiver":"",
  "receiverPhone":"",
  "receiverPostCode":"",
  "isReceipt":"",
  "orderItemList":[],
  "comment":"",
  "subStationId":"",
  "deliveryAddress":"",
  "status":""
};

export default {
  name: 'item-info',
  components: {Search, CirclePlus},
  data() {
    return {
      itemInfo:{},
      obj:{},
      // amountBought:0,
      totalPrice:0,
      itemTable:[],
      orderTable:[],
      locale:zhCn,
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      firstGroupState:"",
      secondGroupState:"",
      searchName:"",
      firstProductList:[],
      secondProductList:[],
      multipleSelection: [],

    }
  },
  methods: {
    // 点击上一步
    handlePrev() {
      this.$emit('handlePrev')
    },
    // 点击下一步
    handleNext() {
      let objReceived = this.$route.query
      let orderList = []
      this.orderTable.forEach(item=>{
        orderList.push({
          "productId":item.id,
          "num":item.purchaseAmt
        })
      })
      objReceived.orderItemList = orderList
      objReceived.sumPrice = this.totalPrice
      console.log('objReceived',objReceived)
      this.$http.post(ipaddress+`/order/addOrder`,objReceived).then(res=>{
        if(res.code === '666'){
          ElMessage.success('订单添加成功！')
          this.$emit('handleNext')
        }else{
          ElMessage.error('订单添加失败！')
        }
      }).catch(()=>{
        ElMessage.error('订单添加失败！')
      })
      // orderRequest.
      // this.$emit('handleNext')
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleCurrentChange(val){ //当前页改变
      console.log(val)
      this.pageNum = val
      this.network()
    },
    handleSizeChange(val){ //页大小改变
      console.log(val)
      this.pageSize = val
      this.network()
    },
    getFirstProductList(){

      this.$http.get(disIpaddress+`/firstproduct/getAllFirstProduct`).then(fpl_1=>{

        this.firstProductList = fpl_1.data
        // this.firstGroupState
        this.getSecondProductList()
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    getSecondProductList(){
      let requestData2 = {
        "firstProductId": "",
      }
      requestData2.firstProductId = (this.firstGroupState === "全部" || this.firstGroupState === "") ? "" : this.firstGroupState
      this.$http.post(disIpaddress+`/secondproduct/getSecondProductByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData2
      ).then(res=>{
        if(res.code === '666'){
          res.data.pageItems.forEach(item => {
            this.secondProductList.push(item.secondProduct)
          })
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })
    },
    addItem(){
      if(this.multipleSelection.length>0){
        // console.log(this.multipleSelection)
        this.multipleSelection.forEach(item=>{
          let order = {}
          order.id = item.id;
          order.name = item.name;
          order.sellingPrice = item.sellingPrice;
          order.discount = item.discount;
          order.supplier = item.supplier;
          order.shelfLife = item.shelfLife;
          order.inventoryAmt = item.inventoryAmt;
          order.purchaseAmt = item.purchaseAmt;
          order.unit = item.unit;
          order.singleSum = item.sellingPrice * item.purchaseAmt*item.discount/10;
          this.totalPrice = this.totalPrice + order.singleSum
          this.orderTable.push(order)
        })
        this.itemTable = []
        // this.multipleSelection = []
      }else{
        ElMessage.error('请选择商品！')
      }
    },

    network(){ //分页查询


      console.log("-----search-----")
      console.log(this.searchType,this.searchName)
      console.log("-----search-----")

      if(this.searchName !== "") {
        requestData.product.name = this.searchName
      }else {
        requestData.product.name = ""
      }

      if(this.firstGroupState !== "全部"){
        requestData.product.firstProductId = this.firstGroupState
      }else{
        requestData.product.firstProductId = ""
      }

      if(this.secondGroupState !== "全部"){
        requestData.product.secondProductId = this.secondGroupState
      }else{
        requestData.product.secondProductId = ""
      }


      this.$http.post(disIpaddress+
          `/store/getItemListByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}&storeId=1`,requestData.product
      ).then(res=>{
        console.log(res)
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.total
          this.itemTable = []
          res.data.list.forEach(item =>{
            let obj = {}
            obj.id = item.product.product.id
            obj.name = item.product.product.name
            obj.unit = item.product.product.unit
            obj.sellingPrice = item.product.product.sellingPrice
            obj.discount = item.product.product.discount
            obj.shelfLife = item.product.product.shelfLife
            obj.inventoryAmt = item.storeItem.unallocatedNum
            obj.supplier = (item.product.supplier === null) ? "无" : item.product.supplier.name
            this.itemTable.push(obj)
          })
          console.log("_____")
          console.log(this.tableData)
          console.log("_____")
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },
  created(){
    console.log('item-info created')
    console.log(this.$route.query)
    // let customer = this.$route.query.customer
    // let delivery = this.$route.query.delivery
    // console.log('customer',customer)
    // console.log('delivery',delivery)
    // console.log('customer.name',customer.name)
    this.getFirstProductList();
    this.network();
  }
}
</script>

<template>
商品信息
  <div class="itemShow">
    <div style="padding: 0px 0">
      <el-select
        v-model="firstGroupState"
        placeholder="一级分类"
        filterable
        allow-create
        default-first-option
        :reserve-keyword="false">
        <el-option
            key=""
            label="全部"
            value="全部"></el-option>
        <el-option
            v-for="option in firstProductList"
            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>
      <el-select
          placeholder="请选择二级分类"
          v-model="secondGroupState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
        <!--        添加一个“全部”选项且值为空-->
        <el-option
            key=""
            label="全部"
            value="全部"></el-option>
        <el-option
            v-for="option in secondProductList"
            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>
      <el-input placeholder="商品名称" v-model="searchName" style="width: 200px;"></el-input>
      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertical-align: middle;">查找商品</span>
      </el-button>
      <el-button type="primary" @click="addItem"><el-icon style="margin-left: 3px"><circle-plus /></el-icon>添加到订单</el-button>
    </div>
    <div class="itemInfo">
      <el-table :data="itemTable" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed type="selection" width="50px" align="center"></el-table-column>
        <el-table-column fixed prop="id" label="id" width="50px" sortable align="center"></el-table-column>
        <el-table-column prop="name" label="商品名称" width="150px" align="center"></el-table-column>
        <el-table-column prop="sellingPrice" label="原价" width="100px" align="center"></el-table-column>
        <el-table-column prop="discount" label="折扣" width="100px" align="center"></el-table-column>
        <el-table-column prop="supplier" label="供应商" width="100px" align="center"></el-table-column>
        <el-table-column prop="shelfLife" label="保质期" width="100px" align="center"></el-table-column>
        <el-table-column prop="inventoryAmt" label="库存" width="100px" align="center"></el-table-column>
        <el-table-column prop="purchaseAmt" label="购买数量" width="150px" align="center" scoped >
<!--          <template slot-scope="scope">-->
<!--            <el-input-number v-model="scope.row.purchaseAmt" :min="1" :max="scope.row.inventoryAmt" :step="1"></el-input-number>-->
<!--          </template>-->
          <template v-slot="scope">
            <el-input v-model="scope.row.purchaseAmt" placeholder="购买数量" style="width: 100px;"></el-input>
          </template>
<!--          嵌入一个可输入的文本框并绑定到数据对象的 purchaseAmt 属性-->
<!--          <template slot-scope="scope">-->
<!--            <el-input-number v-model="scope.row.purchaseAmt" :min="1" :max="scope.row.inventoryAmt" :step="1"></el-input-number>-->
<!--          </template>-->
        </el-table-column>
        <el-table-column prop="unit" label="单位" width="100px" align="center"></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[8, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <br/>
    <div class="totalPrice">
      <span>总价：</span>
      <span>{{totalPrice}}</span>
    </div>
    <br/>
    <div class="orderInfo">
      <el-table :data="orderTable" border style="width: 100%">
        <el-table-column prop="id" label="id" width="50px" sortable align="center"></el-table-column>
        <el-table-column prop="name" label="商品名称" width="150px" align="center"></el-table-column>
        <el-table-column prop="sellingPrice" label="原价" width="100px" align="center"></el-table-column>
        <el-table-column prop="discount" label="折扣" width="100px" align="center"></el-table-column>
        <el-table-column prop="supplier" label="供应商" width="100px" align="center"></el-table-column>
        <el-table-column prop="shelfLife" label="保质期" width="100px" align="center"></el-table-column>
        <el-table-column prop="inventoryAmt" label="库存" width="100px" align="center"></el-table-column>
        <el-table-column prop="purchaseAmt" label="购买数量" width="150px" align="center"></el-table-column>
        <el-table-column prop="unit" label="单位" width="100px" align="center"></el-table-column>
        <el-table-column prop="singleSum" label="单笔总额" width="100px" align="center"></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[8, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handlePrev()">上一步</el-button>
      <el-button type="primary" @click="handleNext()">下一步</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
