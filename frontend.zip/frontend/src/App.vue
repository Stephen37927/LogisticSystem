<template>

  <div class="layout">
    <breadcrumbs></breadcrumbs>
    <router-view class="view"></router-view>
  </div>


</template>

<script>
export default {
  name: 'App',
  components: {

  },
  data(){
    return {
      isRouterAlive:true
    }
  },
  provide(){ //提供
    return {
      reload: this.reload
    }
  },
  methods: {},
  mounted () {}
}
</script>


<style lang="scss">
#App {
  list-style: none;
  font-family: PingFang SC;
  color: var(--colorText);
}

/* 设置持续时间和动画函数 */
.slide-fade-enter-active {
  transition: all .5s ease;
}
.slide-fade-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-enter-from, .slide-fade-leave-to {
  transform: translateX(10px);
  opacity: 0;
}

</style>

<!--<style>-->
<!--#app{-->
<!--  height: 100%;-->
<!--  padding: 0px;-->
<!--}-->
<!--html,body{-->
<!--  height: 100%;-->
<!--  font-family: test;-->
<!--}-->
<!--{-->
<!--  margin: 0;-->
<!--  padding: 0;-->
<!--}-->
<!--body {-->
<!--  margin: 0;-->
<!--  padding: 0;-->
<!--  border: 0;-->
<!--}-->

<!--</style>-->


<script setup>
</script>
