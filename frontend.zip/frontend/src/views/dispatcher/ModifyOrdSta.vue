<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElDialog, ElMessage} from "element-plus";

let ipaddress = '/dispatchManagement';

export default{
  name:'modify-order-state',
  data(){
    return {
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      locale: zhCn,
      orderTable: [],
      dialogMsg: false,
      orderId: '',
      startDateR: '',
      finishDateR: '',
    }
  },
  methods:{
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    check(row){
      this.$http.get(ipaddress+`/dispatch/checkIfArrivalByOrderId?orderId=${row.orderId}`).then(res=> {
        if (res.code === '666') {
          ElMessage.success(res.message)
        }
      }).catch(()=>{
          ElMessage.error('数据加载失败,请刷新！')
      })
    },
    network(){
      let requestData = []
      this.orderTable = []
      requestData.push({
        "id":this.orderId,
        "startDateR":this.startDateR===''?'':this.filterTime(this.startDateR),
        "finishDateR":this.finishDateR===''?'':this.filterTime(this.finishDateR),
        "status":2
      })
      this.$http.post(ipaddress+`/order/getOrderByQuery?pageNum=${this.pageNum}
      &PageSize=${this.pageSize}`,requestData).then(res=>{
        if(res.code === '666'){
          res.data.pageItems.forEach(item=>{
            let obj = {}
            obj.orderId = item.order.id
            obj.customer = item.customer.name
            obj.address = item.order.deliveryAddress
            obj.postcode = item.order.receiverPostCode
            obj.telephone = item.order.receiverPhone
            obj.generationDate = this.filterTime(item.order.requestArrivalDate)
            obj.sumPrice = item.order.sumPrice
            this.orderTable.push(obj)
          })

        }
      })
    }
  },
  created(){
    this.network();
  }
}
</script>

<template>
  <div class="status-modification">
    <div class="header">
      <el-input placeholder="输入订单号查询" v-model="orderId" style="width: 200px;"></el-input>
      <span style="margin-left: 15px;margin-right: 10px;">订单日期</span>
      <el-date-picker
          label="订单日期"
          v-model="startDateR"
          type="datetime"
          placeholder="开始日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;">至 </span>
      <el-date-picker
          label="订单日期"
          v-model="finishDateR"
          type="datetime"
          placeholder="结束日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;"></span>
      <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
    </div>
    <br/>
    <div class="orderInfo">
      <el-table :data="orderTable" border style="width: fit-content">
<!--        订单号、客户名、地址、邮编、电话、订购日期、订购总额-->
        <el-table-column fixed type="index" label="序号" width="50" align="center"></el-table-column>
        <el-table-column fixed prop="orderId" label="订单号" width="70" align="center"></el-table-column>
        <el-table-column prop="customer" label="客户名" width="150" align="center"></el-table-column>
        <el-table-column prop="address" label="地址" width="150" align="center"></el-table-column>
        <el-table-column prop="postcode" label="邮编" width="150" align="center"></el-table-column>
        <el-table-column prop="telephone" label="电话" width="150" align="center"></el-table-column>
        <el-table-column prop="generationDate" label="订购日期" width="150" align="center"></el-table-column>
        <el-table-column prop="sumPrice" label="订购总额" width="150" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" width="100px"  align="center">
          <template v-slot="scope" #default>
            <el-button @click="check(scope.row)" type="warning" size="default">检查&thinsp;
            </el-button>
          </template>
        </el-table-column>
      </el-table>
<!--      <el-dialog v-model="dialogMsg" border title="提示">-->

<!--      </el-dialog>-->
    </div>
  </div>
</template>

<style scoped>

</style>
