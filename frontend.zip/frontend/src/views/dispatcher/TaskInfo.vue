<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage} from "element-plus";

let ipaddress = '/dispatchManagement'
let ordIpaddress = '/customerManagement'

export default{
  name:'task-info',
  data(){
    return {
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      taskTotal: 0, //总记录数
      locale: zhCn,
      typeT: '',
      statusT: '',
      subStation: '',
      startDateR: '',
      finishDateR: '',
      tableData: [],
      itemInfoTable: [],
      typeTs:[],
      statusTs:[],
      subStations:[],
      // response:{},
      dialogItemVisible: false,
    }
  },
  methods:{
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    showGoodsInfo(row){
      let request = []
      request.push({"id":row.orderId})
      this.itemInfoTable = []
      this.$http.post(ordIpaddress+`order/getOrderByQuery?pageNum=1&PageSize=5`,request)
          .then(res=>{
            if(res.code === '666'){
              res.data.pageItems[0].orderItems.forEach(item=>{
                let obj = {}
                obj.goodsName = item.product.name
                obj.purchaseAmt = item.num
                obj.goodsPrice = item.product.sellingPrice
                this.itemInfoTable.push(obj)
              })
              // this.dialogItemVisible = true
            }
          }).catch(err=>{
            ElMessage.error('网络错误')
          })
    },
    // getTaskById(id){
    //   this.response.data.pageItems.forEach(item=>{
    //     if(item.task.id === id){
    //       return item
    //     }
    //   })
    //   return null
    // },
    getTypeTs(){
      this.typeTs = [
        // {
        //   value:"",
        //   label:"全部"
        // },
        {
          value:"送货收款",
          label:"送货收款"
        },
        {
          value:"送货",
          label:"送货"
        },
        {
          value:"退货",
          label:"退货"
        },
        {
          value:"换货",
          label:"换货"
        },
        {
          value:"退款",
          label:"退款"
        }
      ]
    },
    getStatusTs(){
      let arr = []
      for(let i = 1; i < 10; i++){
        arr.push(i)
      }
      arr.forEach(item=>{
        let obj = {}
        obj.id = item
        obj.name = this.statusTransfer(item)
        this.statusTs.push(obj)
      })
    },
    statusTransfer(status){
      let result = ''
      switch(status){
        case 1:
          result = '可分配'
          break
        case 2:
          result = '缺货挂起'
          break
        case 3:
          result = '已调度'
          break
        case 4:
          result = '中心库房出库'
          break
        case 5:
          result = '配送站到货'
          break
        case 6:
          result = '已分配'
          break
        case 7:
          result = '已领货'
          break
        case 8:
          result = '已完成'
          break
        case 9:
          result = '取消订单'
          break
        // case '':
        //   result = '全部'
        //   break
        case '可分配':
          result = 1
          break
        case '缺货挂起':
          result = 2
          break
        case '已调度':
          result = 3
          break
        case '中心库房出库':
          result = 4
          break
        case '配送站到货':
          result = 5
          break
        case '已分配':
          result = 6
          break
        case '已领货':
          result = 7
          break
        case '已完成':
          result = 8
          break
        case '取消订单':
          result = 9
          break
        // case '全部':
        //   result = ''
        //   break
        default:
          result = '未知状态'
      }
      return result
    },
    getSubStations(){
      this.subStations = [
        {
          "id": "1",
          "name": "福建分站"
        },
        {
          "id": "2",
          "name": "浙江分站"
        }
      ]
    },
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    network(){
      let request = {
        "startDateR": this.startDateR===''?'':this.filterTime(this.startDateR),
        "finishDateR": this.finishDateR===''?'':this.filterTime(this.finishDateR),
        "typeT": this.typeT,
        "statusT": this.statusT,
        "subStationId": this.subStation,
      }
      this.tableData = []
      this.$http.post(ipaddress+`task/getTaskByQuery?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,request).then(res=>{
        if(res.code === '666'){
          // ElMessage.success('任务单信息查询成功')
          this.taskTotal = res.data.totalItems
          // this.response = res
          console.log('res',res)
          let obj = {}
          res.data.pageItems.forEach(item=>{
            obj = {}
            obj.orderId = item.order.id
            obj.taskId = item.task.id
            obj.customer = item.customer.name
            obj.address = item.task.deliveryAddress
            obj.requestArrivalDate = item.task.requestFinishDate
            obj.typeT = item.task.type
            obj.statusT = item.task.status
            this.tableData.push(obj)
          })
        }
      }).catch(err=>{
        ElMessage.error('任务单信息查询失败')
      })
    }
  },
  created(){
    this.getTypeTs()
    this.getStatusTs()
    this.getSubStations()
    this.network()
  }
}
</script>

<template>
<!--任务单查询-->
<div class="taskQuery">
  <div class="header">
    <div>
      <span style="margin-left: 15px">类型</span>
      <el-select v-model="typeT" placeholder="请选择任务单类型">
        <el-option
            v-for="item in typeTs"
            :label="item.label"
            :value="item.value">
        </el-option>
      </el-select>
      <span style="margin-left: 15px">状态</span>
      <el-select v-model="statusT" placeholder="请选择任务单状态">
        <el-option
            v-for="item in statusTs"
            :label="item.name"
            :value="item.name">
        </el-option>
      </el-select>
      <span style="margin-left: 15px">分站</span>
      <el-select v-model="subStation" placeholder="请选择分站">
        <el-option
            v-for="item in subStations"
            :label="item.name"
            :value="item.name">
        </el-option>
      </el-select>
    </div>
    <br/>
    <div>
      <span style="margin-left: 15px;margin-right: 10px;">要求完成日期</span>
      <el-date-picker
          label="订单日期"
          v-model="startDateR"
          type="datetime"
          placeholder="开始日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;">至</span>
      <el-date-picker
          label="订单日期"
          v-model="finishDateR"
          type="datetime"
          placeholder="结束日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;"></span>
      <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
    </div>
  </div>
  <br/>
  <div class="taskInfo">
    <el-table :data="tableData" border style="width: min-content">
      <el-table-column fixed type="index" label="序号" width="50" align="center"/>
      <el-table-column fixed prop="orderId" label="订单号" width="100" align="center"/>
      <el-table-column prop="taskId" label="任务单号" width="100" align="center"/>
      <el-table-column prop="customer" label="客户" width="100" align="center"/>
      <el-table-column prop="address" label="投递地址" width="100" align="center"/>
      <el-table-column prop="requestArrivalDate" label="要求完成日期" width="100" align="center"/>
      <el-table-column prop="typeT" label="任务类型" width="100" align="center"/>
      <el-table-column prop="statusT" label="任务状态" width="100" align="center"/>
      <el-table-column fixed="right" label="商品信息" width="100" align="center">
        <template v-slot="scope" #default>
          <el-button size="default" @click="this.dialogItemVisible=true;showGoodsInfo(scope.row)" type="info">查看&thinsp;</el-button>
        </template></el-table-column>
    </el-table>
    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[5, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="taskTotal">
        </el-pagination>
      </div>
    </el-config-provider>
    <el-dialog v-model="dialogItemVisible" title="商品信息" width="30%">
      <el-table :data="itemInfoTable" style="padding-left: 10px;width:min-content;">
        <el-table-column fixed type="index" width="40" align="center"></el-table-column>
        <el-table-column prop="goodsName" label="商品名称" align="center" width="100"></el-table-column>
        <el-table-column prop="purchaseAmt" label="购买数量" align="center" width="100"></el-table-column>
        <el-table-column prop="goodsPrice" label="单价" align="center" width="100"></el-table-column>
      </el-table>
    </el-dialog>
  </div>
</div>
</template>

<style scoped>
.el-select{
  padding: 10px;
}
</style>
