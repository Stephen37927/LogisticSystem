<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage} from "element-plus";

let disIpaddress = '/dispatchManagement'
let ordIpaddress = '/customerManagement'


export default{
  name:'manual',

  data(){
    return {
      selectedOrdType:"",
      orderTypes:[],
      disOrdTable:[],
      itemInfoTable:[],
      subStations:[],
      typeTs:[],
      startDateG:"",
      finishDateG:"",
      dialogDisVisible: false,
      dialogCFVisible: false,
      formDis:{},
      formBuchong:{},
      total: 0, //数据总条数
      itemTotal:0,
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      itemPgNum: 1,
      itemPgSize: 5,
      locale: zhCn,
      formLabelWidth: '100px',
      rules: {
        typeT:[{required: true, message: '请选择类型', trigger: 'blur'}],
        deliveryDate:[{required: true, message: '请选择配送日期', trigger: 'blur'}],
        planOutDate:[{required: true, message: '请选择计划出库日期', trigger: 'blur'}]
      }
    }
  },
  methods: {
    getOrdTypes() {
      this.orderTypes = [
        {
          value: "",
          label: '全部'
        },
        {
          value: 1,
          label: '普通配送订单'
        },
        {
          value: 2,
          label: '换货单'
        },
        {
          value: 3,
          label: '退货单'
        },
        // {
        //   value:4,
        //   label:'退订单'
        // }
      ]
    },
    getTypesT(){
      this.typeTs = [
        {
          "name":"送货收款"
        },
        {
          "name":"送货"
        },
        {
          "name":"退货"
        },
        {
          "name":"换货"
        },
        {
          "name":"退款"
        }
      ]
    },
    handleSizeChange(val) { //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val) { //当前页改变
      this.pageNum = val
      this.network()
    },
    statusTransfer(status) {
      let result = ''
      switch (status) {
        case 1:
          result = '可分配'
          break
        case 2:
          result = '缺货挂起'
          break
        case 3:
          result = '已调度'
          break
        case 4:
          result = '中心库房出库'
          break
        case 5:
          result = '到货'
          break
        case 6:
          result = '已分配'
          break
        case 7:
          result = '已领货'
          break
        case 8:
          result = '已完成'
          break
        case 9:
          result = '取消订单'
          break
        case '可分配':
          result = 1
          break
        case '缺货挂起':
          result = 2
          break
        case '已调度':
          result = 3
          break
        case '中心库房出库':
          result = 4
          break
        case '到货':
          result = 5
          break
        case '已分配':
          result = 6
          break
        case '已领货':
          result = 7
          break
        case '已完成':
          result = 8
          break
        case '取消订单':
          result = 9
          break
        default:
          result = '未知状态'
      }
      return result
    },
    typeTransfer(type) {
      let result = ''
      switch (type) {
        case 1:
          result = '普通配送订单'
          break
        case 2:
          result = '换货单'
          break
        case 3:
          result = '退货单'
          break
        case 4:
          result = '退订单'
          break
        default:
          result = '未知状态'
      }
      return result
    },
    dispatch(row) {
      let requestData = []
      let parsedRow = JSON.parse(JSON.stringify(row))
      let obj = {}
      console.log('exec dispatch')
      console.log('row', row)
      obj.orderId = parsedRow.orderId
      obj.type = parsedRow.orderType
      obj.status = parsedRow.status
      obj.inputUser = "徐璟涛"
      requestData.push({"id": parsedRow.orderId})
      console.log('requestData', requestData)
      console.log('this.pageNum', this.pageNum)
      console.log('this.pageSize', this.pageSize)
      this.$http.post(ordIpaddress + `/order/getOrderByQuery?pageNum=${this.pageNum}
      &PageSize=${this.pageSize}`, requestData).then(res => {
        console.log('res', res)
        if (res.code === '666') {
          this.itemTotal = res.data.totalItems
          res.data.pageItems.forEach(item => {
            obj.customer = item.customer.name
            obj.deliveryDate = item.order.generationDate
            obj.receiver = item.order.receiver
            obj.address = item.order.deliveryAddress
            obj.phone = item.order.receiverPhone
            obj.postCode = item.order.receiverPostCode
            obj.isReceipt = (item.order.isReceipt === 1) ? "是" : "否"
            obj.comment = item.order.comment
            console.log('item.orderItems', item.orderItems)
            item.orderItems.forEach(goods => {
              console.log('goods', goods)
              let itemInfo = {}
              itemInfo.goodsName = goods.product.name
              itemInfo.purchaseAmt = goods.num
              itemInfo.goodsPrice = goods.product.sellingPrice
              this.itemInfoTable.push(itemInfo)
            })
            this.formDis = obj

          })
        }

      }).catch(() => {
        ElMessage.error('获取订单信息失败')
      })

      this.dialogDisVisible = true;
    },
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    confirm() {
      let requestUpdate = {
        "id": this.formDis.orderId,
        "subStationId": this.formDis.subStation
      }
      console.log('requestUpdate', requestUpdate)
      this.$http.post(ordIpaddress + '/order/updateOrderById', requestUpdate).then(res => {
        if (res.code === '666') {
          ElMessage.success('分配成功')
          this.formBuchong.orderId = this.formDis.orderId
          this.dialogCFVisible = true
          // this.network()
        } else {
          ElMessage.error('分配失败')
        }
      }).catch(() => {
        ElMessage.error('分配失败')
      })
    },
    okay(){
      let form = this.formBuchong
      let requestDis = {
        "orderId": form.orderId,
        "typeT": form.typeT,
        "deliveryDate": this.filterTime(form.deliveryDate),
        "planOutDate": this.filterTime(form.planOutDate)
      }
      console.log('requestDis',requestDis)
      this.$http.post(disIpaddress+'/dispatch/dispatching',requestDis).then(res=>{
        if(res.code === '666'){
          ElMessage.success('调度成功')
          this.dialogCFVisible = false
          this.dialogDisVisible = false
          this.network()
        }else{
          ElMessage.error('调度失败')
        }
      }).catch(()=>{
        ElMessage.error('调度失败')
      })
    },
    getSubStations() {
      this.subStations = [
        {
          "id": "1",
          "name": "福建分站"
        },
        {
          "id": "2",
          "name": "浙江分站"
        }
      ]
    },
    network() {
      let requestData = []
      this.disOrdTable = []
      requestData.push({
        "type": this.selectedOrdType,
        "startDateG": this.startDateG===''?'':this.filterTime(this.startDateG),
        "finishDateG": this.finishDateG===''?'':this.filterTime(this.finishDateG),
        "status":1,
        "subStationId": 0
      })
      this.$http.post(ordIpaddress + `/order/getOrderByQuery?pageNum=${this.pageNum}
      &PageSize=${this.pageSize}`, requestData).then(res => {
        if (res.code === '666') {
          this.total = res.data.totalItems
          res.data.pageItems.forEach(item => {
            console.log('item', item)
            this.disOrdTable.push({
              orderId: item.order.id,
              status: this.statusTransfer(item.order.status),
              orderType: "可分配",
              customer: item.customer.name,
              receiver: item.order.receiver,
              orderDate: item.order.generationDate
            })
          })
        }
      })
    }
  },
  created(){
    this.getSubStations()
    this.getTypesT()
    this.getOrdTypes()
    this.network()
  }
}
</script>

<template>
  <div class="manual">
    <div class="header">
      <el-select
        v-model="selectedOrdType"
        placeholder="请选择订单类型"
        filterable
        >
        <el-option
          v-for="type in orderTypes"
          :key="type.value"
          :value="type.value"
          :label="type.label">
        </el-option>
      </el-select>
<!--      一点横向的空隙-->
      <span style="margin-left: 15px;margin-right: 10px;">订单日期</span>
      <el-date-picker
        label="订单日期"
        v-model="startDateG"
        type="datetime"
        placeholder="开始日期"
        format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;">至</span>
      <el-date-picker
        label="订单日期"
        v-model="finishDateG"
        type="datetime"
        placeholder="结束日期"
        format="YYYY/MM/DD HH:mm:ss"
        ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;"></span>
      <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
    </div>
    <br/>
    <div class="dispatchedOrderInfo">
      <el-table :data="disOrdTable" border style="width: fit-content">
        <el-table-column fixed type="index" label="序号" width="50" align="center"></el-table-column>
        <el-table-column fixed prop="orderId" label="订单号" width="100" align="center"></el-table-column>
        <el-table-column prop="status" label="订单状态" width="200" align="center"></el-table-column>
        <el-table-column prop="orderType" label="订单类型" width="200" align="center"></el-table-column>
        <el-table-column prop="customer" label="客户" width="100" align="center"></el-table-column>
        <el-table-column prop="receiver" label="收货人" width="140" align="center"></el-table-column>
        <el-table-column prop="orderDate" label="订单日期" width="200" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" width="90px"  align="center">
          <template v-slot="scope" #default>
            <el-button @click="dispatch(scope.row)" type="warning" size="default">调度&thinsp;
              <!--              <el-icon> <edit/></el-icon>-->
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>

      <el-dialog v-model="dialogDisVisible" border title="订单调度" style="width: 70%;">
        <el-form :model="formDis" ref="formDis" :inline="true">
          <el-row>
            <el-col :span="12">
              <el-form-item label="订单号" prop="orderId" :label-width="formLabelWidth">
                <el-input v-model="formDis.orderId" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="订单类型" prop="type" :label-width="formLabelWidth">
                <el-input v-model="formDis.type" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="用户名" prop="customer" :label-width="formLabelWidth">
                <el-input v-model="formDis.customer" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="订单状态" prop="status" :label-width="formLabelWidth">
                <el-input v-model="formDis.status" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="配送日期" prop="deliveryDate" :label-width="formLabelWidth">
                <el-input v-model="formDis.deliveryDate" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="录入员" prop="inputUser" :label-width="formLabelWidth">
                <el-input v-model="formDis.inputUser" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="收货人" prop="receiver" :label-width="formLabelWidth">
                <el-input v-model="formDis.receiver" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="地址" prop="address" :label-width="formLabelWidth">
                <el-input v-model="formDis.address" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="电话" prop="phone" :label-width="formLabelWidth">
                <el-input v-model="formDis.phone" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="邮编" prop="postCode" :label-width="formLabelWidth">
                <el-input v-model="formDis.postCode" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="是否要发票" prop="isReceipt" :label-width="formLabelWidth">
                <el-input v-model="formDis.isReceipt" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="备注" prop="comment" :label-width="formLabelWidth">
                <el-input v-model="formDis.comment" disabled autocomplete="off"></el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="商品信息" prop="itemInfo" :label-width="formLabelWidth">
            <el-table :data="itemInfoTable" style="padding-left: 10px;width:350px;">
              <el-table-column fixed type="index" width="40" align="center"></el-table-column>
              <el-table-column prop="goodsName" label="商品名称" align="center" width="100"></el-table-column>
              <el-table-column prop="purchaseAmt" label="购买数量" align="center" width="100"></el-table-column>
              <el-table-column prop="goodsPrice" label="单价" align="center" width="100"></el-table-column>
            </el-table>
            <el-config-provider :locale="locale">
              <div style="padding: 10px 0">
                <el-pagination
                    background
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    v-model:currentPage="itemPgNum"
                    :page-sizes="[5, 15, 50, 100]"
                    v-model:page-size="itemPgSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="itemTotal">
                </el-pagination>
              </div>
            </el-config-provider>
          </el-form-item>
          <el-form-item label="选择分站" :label-width="formLabelWidth">
            <el-select v-model="formDis.subStation" placeholder="请选择分站" style="padding-left: 10px;">
              <el-option
                  v-for="item in subStations"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <template #footer>
      <span class="dialog-footer">
        <el-button @click="this.dialogDisVisible=false;this.itemInfoTable=[]"> 取消</el-button>
        <el-button type="primary" @click="confirm();this.itemInfoTable=[]"> 提交</el-button>
      </span>
        </template>
      </el-dialog>
      <el-dialog v-model="dialogCFVisible" border title="补充信息">
        <el-form :model="formBuchong" :label-width="formLabelWidth" :rules="rules">
          <el-form-item label="订单编号" prop="orderId">
            <el-input v-model="formBuchong.orderId" disabled autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="配送日期" prop="deliveryDate">
            <el-date-picker
                v-model="formBuchong.deliveryDate"
                type="datetime"
                placeholder="选择日期"
                format="YYYY/MM/DD HH:mm:ss"/>
          </el-form-item>
          <el-form-item label="调拨日期" prop="planOutDate">
            <el-date-picker
                v-model="formBuchong.planOutDate"
                type="datetime"
                placeholder="选择日期"
                format="YYYY/MM/DD HH:mm:ss"/>
          </el-form-item>
          <el-form-item label="任务单类型" prop="typeT">
            <el-select v-model="formBuchong.typeT" placeholder="请选择任务单类型">
              <el-option
                  v-for="item in typeTs"
                  :label="item.name"
                  :value="item.name">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" @click="okay()"> 确认 </el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<style scoped>
.el-input{
  width: 250px;
  margin:0;
  padding-left: 10px
}
</style>
