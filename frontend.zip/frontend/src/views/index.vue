<script>

import Navigation from "@/components/Navigation.vue";
import Breadcrumb from "@/components/Breadcrumb.vue";
// import HomepageImg from "@/assets/homepageImg.jpg"

import * as echarts from 'echarts';

export default {
  // name: "index",
  components: {
    Navigation,
    Breadcrumb,
  },
  // data(){
  //   return {
  //     mainStyles:{},
  //   }
  // },
  // watch: {
  //   $route: {
  //     immediate: true,
  //     handler(to, from) {
  //       // Check if the current route is the homepage route
  //       const isHomepage = to.name === '首页'; // Replace 'homepage' with the name of your homepage route
  //
  //       // Set the background image style based on whether it's the homepage or not
  //       this.mainStyles = isHomepage ? { backgroundImage: `url(${HomepageImg})` } : {};
  //     },
  //   },
  // },
};

// export const ipaddress = "http://172.20.10.2:8081";
</script>


<template>
  <div>
    <el-container class="main-container">
      <el-aside width="15%" class="sidebar">
          <Navigation/>
<!--        导航-->
      </el-aside>
      <el-container  width="85%" direction="vertical">
        <el-header class="header">
          <div class="breadcrumb-container">
            <Breadcrumb/>
<!--            面包屑导航-->
          </div>
        </el-header>
        <el-main class="main">
          <router-view/>

        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped>

.main-container{
  height: 100%;
  padding-left: 0;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}




</style>
