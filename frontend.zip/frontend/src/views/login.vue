<template>
  <div class="box">
    <div ref="vantaRef" style="width: 100%; height: 100%">
      <div class="login-container">
        <div class="login-form">
          <h2>登录</h2> <br>
          <form @submit.prevent="handleLogin">
            <div class="form-group">
              <label for="username">用户名:</label><br>
              <input type="text" id="username" v-model="username" required />
            </div>
            <div class="form-group">
              <label for="password">密码:</label><br>
              <input type="password" id="password" v-model="password" required />
            </div><br>
            <button type="submit">登录</button>
          </form>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import * as THREE from "three";
import WAVES from "vanta/src/vanta.waves";


export default {
  data() {
    return {
      username: "",
      password: "",
    };
  },
  mounted() {
    this.vantaEffect = WAVES({
      el: this.$refs.vantaRef,
      THREE: THREE,
    });
    VANTA.WAVES({
      el: this.$refs.vantaRef,
      mouseControls: true,
      touchControls: true,
      gyroControls: false,
      minHeight: 200.00,
      minWidth: 200.00,
      scale: 1.00,
      scaleMobile: 1.00,
      color: 0x989898
    });
  },
  beforeDestroy() {
    if (this.vantaEffect) {
      this.vantaEffect.destroy();
    }
  },
  methods: {
    handleLogin() {
      // This is just a simple example, handle the login logic accordingly
      if (this.username === "admin" && this.password === "admin") {
        localStorage.setItem("isLoggedIn", "true");
        this.$router.push("/");
      } else {
        alert("用户名或密码错误");
      }
    },
  },
};
</script>

<style lang="less" scoped>
.box {
  position: relative;
  .banner {
    z-index: 999;
    position: absolute;
    top: 30%;
    left: 10%;
    //color: #fff;
  }
}
h1 {
  font-size: 66px;
}
p {
  margin-top: 60px;
  font-size: 18px;
}

.login-container {
  //
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* Adjust this as needed to center the login form on the screen */
}

.login-form {
  //max-width: 800px;
  background-color: rgba(34,34,34,0.2);
  width:  380px;
  padding: 70px;
  border: 1px solid #ccc;
  border-radius: 5px;

}

.form-group {
  margin-bottom: 15px;
  margin-right: 20px;
}

label {
  display: block;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

button {
  padding: 10px 15px;
  background-color: #464646;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}
</style>






<!--<script>-->
<!--export default {-->
<!--  data() {-->
<!--    return {-->
<!--      username: "",-->
<!--      password: "",-->
<!--    };-->
<!--  },-->
<!--  methods: {-->
<!--    handleLogin() {-->
<!--      // This is just a simple example, handle the login logic accordingly-->
<!--      if (this.username === "admin" && this.password === "admin") {-->
<!--        localStorage.setItem("isLoggedIn", "true");-->
<!--        this.$router.push("/");-->
<!--      } else {-->
<!--        alert("用户名或密码错误");-->
<!--      }-->
<!--    },-->
<!--  },-->
<!--};-->
<!--</script>-->

<!--<style>-->
<!--.login-container {-->
<!--  display: flex;-->
<!--  justify-content: center;-->
<!--  align-items: center;-->
<!--  height: 100vh; /* Adjust this as needed to center the login form on the screen */-->
<!--}-->

<!--.login-form {-->
<!--  //max-width: 800px;-->
<!--  width:  380px;-->
<!--  padding: 30px;-->
<!--  border: 1px solid #ccc;-->
<!--  border-radius: 5px;-->
<!--}-->

<!--.form-group {-->
<!--  margin-bottom: 15px;-->
<!--  margin-right: 20px;-->
<!--}-->

<!--label {-->
<!--  display: block;-->
<!--}-->

<!--input {-->
<!--  width: 100%;-->
<!--  padding: 8px;-->
<!--  border: 1px solid #ccc;-->
<!--  border-radius: 3px;-->
<!--}-->

<!--button {-->
<!--  padding: 10px 15px;-->
<!--  background-color: #007bff;-->
<!--  color: #fff;-->
<!--  border: none;-->
<!--  border-radius: 3px;-->
<!--  cursor: pointer;-->
<!--}-->
<!--</style>-->
