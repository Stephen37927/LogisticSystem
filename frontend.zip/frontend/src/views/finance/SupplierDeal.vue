<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import * as echarts from "echarts";

let ipadderss = 'http://localhost:8098'

export default {
  data(){
    return {
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      taskTotal: 0, //总记录数
      locale: zhCn,
      tableData:[],
      supplierId:0,
      startDate: '',
      finishDate: '',
      chart:null,
    }
  },
  methods:{
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    generateEChartData() {
      // 初始化一个对象来保存 ECharts 所需的数据
      const echartData = {
        categories: [],
        values: [],
      };

      console.log('enter generateEChartData')
      console.log('tableData',this.tableData)
      // 遍历 tableData 并提取 ECharts 所需的数据
      this.tableData.forEach((item) => {
        console.log('echart item',item)
        echartData.categories.push(item.name);
        echartData.values.push(item.settleNum);
      });

      return echartData;
    },
    network() {
      let request = {
        'supplierId': this.supplierId,
        'startDate': this.startDate===null?'':this.filterTime(this.startDate),
        'finishDate': this.finishDate===null?'':this.filterTime(this.finishDate),
      }
      this.tableData = []
      this.$http.post(ipadderss+`/settlement/settlementWithSupplier`,request).then(res=>{
        if(res.code === '666'){

          this.taskTotal = res.data.total
          res.data.forEach(item=>{
            let obj = {}
            obj.name = item.product.name
            obj.price = item.product.sellingPrice
            obj.num = item.details.inNum
            obj.returnNum = item.details.outNum
            obj.settleNum = item.details.snum
            obj.settlePrice = item.details.sprice
            obj.inPrice = item.details.inPrice
            obj.outPrice = item.details.outPrice
            // obj.date = item.
            this.tableData.push(obj)
          })
        }else{
          this.$message({
            type: 'error',
            message: res.msg
          })
        }
      }).catch(err=>{
        this.$message({
          type: 'error',
          message: '网络错误'
        })
      })

      // // 调用生成 ECharts 数据的方法
      // const echartData = this.generateEChartData();
      //
      // // 绘制 ECharts 图表
      // if (this.chart) {
      //   this.chart.setOption({
      //     series: [
      //       {
      //         name: "商品名称",
      //         type: "pie",
      //         radius: "80%",
      //         data: echartData.values.map((value, index) => ({
      //           value,
      //           name: echartData.categories[index],
      //         })),
      //       },
      //     ],
      //   });
      // }
    },

  },
  created(){
    // 在页面加载时进行 ECharts 图表的初始化
    // this.chart = echarts.init(document.getElementById("bingtu"));
    // this.chart.setOption({
    //   tooltip: {
    //     trigger: "item",
    //     formatter: "{a} <br/>{b}: {c} ({d}%)",
    //   },
    //   series: [
    //     {
    //       name: "商品名称",
    //       type: "pie",
    //       radius: "80%",
    //       data: [],
    //     },
    //   ],
    // });
  }
}
</script>

<template>
  <div class="supplierDeal">
    <div class="header">
      <span style="margin-left: 15px;margin-right: 10px;">供应商代码</span>
      <el-input label="供应商编号" placeholder="请输入供应商编号" v-model="supplierId" style="width: 150px;padding-left:10px;"></el-input>
      <span style="margin-left: 15px;margin-right: 10px;">要求完成日期</span>
      <el-date-picker
          label="订单日期"
          v-model="startDate"
          type="datetime"
          placeholder="开始日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;">至</span>
      <el-date-picker
          label="订单日期"
          v-model="finishDate"
          type="datetime"
          placeholder="结束日期"
          format="YYYY/MM/DD HH:mm:ss"
      ></el-date-picker>
      <span style="margin-left: 15px;margin-right: 10px;"></span>
      <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
    </div>
    <br/>
    <div class="info">
      <el-table :data="tableData" border style="width: fit-content">
        <el-table-column type="index" label="序号" width="50" align="center"></el-table-column>
<!--        商品名称、单价、供货数量、退回数量、结算数量、结算金额、合计金额、日期-->
        <el-table-column prop="name" label="商品名称" width="100" align="center"></el-table-column>
        <el-table-column prop="price" label="单价" width="100" align="center"></el-table-column>
        <el-table-column prop="num" label="供货数量" width="100" align="center"></el-table-column>
        <el-table-column prop="returnNum" label="退回数量" width="100" align="center"></el-table-column>
        <el-table-column prop="settleNum" label="结算数量" width="100" align="center"></el-table-column>
        <el-table-column prop="settlePrice" label="结算金额" width="100" align="center"></el-table-column>
        <el-table-column prop="inPrice" label="进货金额" width="100" align="center"></el-table-column>
        <el-table-column prop="outPrice" label="退货金额" width="100" align="center"></el-table-column>
<!--        <el-table-column prop="totalPrice" label="合计金额" width="100" align="center"></el-table-column>-->
<!--        <el-table-column prop="date" label="日期" width="200" align="center"></el-table-column>-->
      </el-table>
<!--      <div class="echart" id="bingtu" :style="{ float: 'left', width: '80%', height: '240px' }"></div>-->
    </div>
  </div>
</template>

<style scoped>

</style>
