<script>

import {ElMessage, ElMessageBox} from "element-plus";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'





let ipaddress = "/warehouseManagement"

let requestData = {

}

export default {
  name: 'print-out-order',

  data(){
    return {
      date: '',
      title: "标题",
      productName: "",
      locale: zhCn,
      tableData: [],
      json_fields: {
        "商品代码":'productId',
        "商品名称":'productName',
        "售价":'sellingPrice',
        "数量":'productNum',
        "厂商":'supplier',
        "折扣":'discount',
        "总金额":'totalPrice',
        "日期":'date'
      },
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      isFound: false,
      notFound: false,
      dialogFormVisible: false,
      formLabelWidth: '100px',
      multipleSelection: [],
      dispatchingOrder:{},
      form: {},
      printObj: {
        id: 'printOrder',
        popTitle: '出库单一览表'
      },
    }
  },

  methods: {
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleNext() {
      let ids = this.multipleSelection.map(v=>{
        this.dispatchingOrder.id = v.id
        this.dispatchingOrder.outId = v.outId
        this.dispatchingOrder.inId = v.inId
        this.dispatchingOrder.status = v.status
        this.dispatchingOrder.type = v.type
        this.dispatchingOrder.productId = v.productId
        this.dispatchingOrder.productNum = v.productNum
        this.dispatchingOrder.actualNum = v.actualNum
        this.dispatchingOrder.unit = v.unit
        this.dispatchingOrder.planOutDate = v.planOutDate
        this.dispatchingOrder.orderId = v.orderId
        this.dispatchingOrder.taskId = v.taskId
      })
      ElMessageBox.confirm(
          '是否打印出库单？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          // this.$http.post(ipaddress+"/storeManagement/inCenterStore",this.dispatchingOrder).then(res=>{
          //   if(res.code === '666'){
              ElMessage({
                message: '成功！',
                type: 'success',
               })
          //     this.network()
          //   }
          // }).catch(()=>{
          //   ElMessage.error('失败！')
          // })
        })
      })
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    network(){
      this.date = this.filterTime(this.date)
      console.log("_____date&name____");
      console.log(this.date)
      console.log(this.productName)
      console.log("_____date&name____");
      console.log(requestData)
      this.$http.post(ipaddress+`/storeManagement/printOutStoreOrder?date=${this.date}&productName=${this.productName}&PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,requestData).then(res=>{
        console.log("_____res____");
        console.log(res);
        console.log("_____res____");
        if(res.code === '666'){
          console.log(res.data.list)
          this.tableData = res.data.list;
          //console.log(res)
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    }
  },
  created() {
    //console.log('created')
    //this.network()
  },

  // exportData() {
  //   const headers = ['商品代码', '商品名称', '售价']
  //   const data = this.tableData.map(item => [item.productId, item.productName, item.sellingPrice])
  //   const worksheet = XLSX.utils.aoa_to_sheet([headers, data])
  //   const workbook = XLSX.utils.book_new()
  //   XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
  //   XLSX.writeFile(workbook, 'data.xlsx')
  // }
}
</script >

<template>

  <div class="dispatchingOrderShow">
    <el-date-picker
        v-model="date"
        type="datetime"
        placeholder="选择日期"
        format="YYYY-MM-DD HH:mm:ss"
        autocomplete="off"
    /> &thinsp;
    <el-input placeholder="请输入商品名称" style="width: 200px;padding: 10px;" v-model="productName"></el-input>

    <el-button @click="network()">查找出库单</el-button>
    <div v-if="isFound">
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="productId" label="商品代码" width="80px" sortable align="center"></el-table-column>
        <el-table-column prop="productName" label="商品名称" width="100px" align="center"></el-table-column>
        <el-table-column prop="sellingPrice" label="售价" width="150px" align="center"></el-table-column>
        <el-table-column prop="productNum" label="数量" width="80px" align="center"></el-table-column>
        <el-table-column prop="supplier" label="厂商" width="120px" align="center"></el-table-column>
        <el-table-column prop="discount" label="折扣" width="120px" align="center"></el-table-column>
        <el-table-column prop="totalPrice" label="总金额" width="120px" align="center"></el-table-column>
        <el-table-column prop="date" label="日期" width="120px" align="center"></el-table-column>
      </el-table>

      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>




<!--      <download-excel-->
<!--          class="export-excel-wrapper"-->
<!--          :data="tableData"-->
<!--          :fields="json_fields"-->
<!--          :header="title"-->
<!--          name="出库.xls"-->
<!--      >-->
<!--        <el-button type="success">打印</el-button>-->
<!--      </download-excel>-->

    </div>
    <div v-if="notFound">
      不存在此日期此商品的出库单
      <br/>
    </div>
<!--    <download-excel-->
<!--        class="export-excel-wrapper"-->
<!--        :data="tableData"-->
<!--        :fields="json_fields"-->
<!--        :header="title"-->
<!--        name="需要导出的表格名字.xls"-->
<!--    >-->
<!--      &lt;!&ndash; 上面可以自定义自己的样式，还可以引用其他组件button &ndash;&gt;-->
<!--      <el-button type="success">导出</el-button>-->
<!--    </download-excel>-->
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handleNext()">打印</el-button>
    </div>




  </div>
</template>

<style scoped>

</style>
