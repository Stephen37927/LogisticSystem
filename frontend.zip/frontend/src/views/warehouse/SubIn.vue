<script>

import {ElMessage, ElMessageBox} from "element-plus";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

let ipaddress = "/warehouseManagement"

let requestData = {
  "status":"初始状态",
  "type":"调拨入库",
  "planOutDate": ""
}

export default {
  name: 'sub-in',

  data(){
    return {
      status: '初始状态',
      type: '调拨入库',
      planOutDate: '',
      locale: zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      isFound: false,
      notFound: false,
      dialogFormVisible: false,
      formLabelWidth: '100px',
      multipleSelection: [],
      dispatchingOrder:{},
      form: {}
      // rules: {
      //   // outId: [{ required: true, message: '请输入出库库房代码', trigger: 'blur' }],
      //   // inId:[{required: true, message: '请输入入库库房代码', trigger: 'blur'}],
      //   status:[{required: true, message: '请输入状态', trigger: 'blur'}],
      //   type:[{required: true, message: '请输入类型', trigger: 'blur'}],
      //   // productId:[{required: true, message: '请输入商品代码', trigger: 'blur'}],
      //   // productNum:[{required: true, message: '请输入商品数量', trigger: 'blur'}],
      //   // unit:[{required: true, message: '请输入商品单位', trigger: 'blur'}],
      //   planOutDate:[{required: true, message: '请输入时间', trigger: 'blur'}],
      //   // orderId:[{required: true, message: '请输入订单代码', trigger: 'blur'}],
      //   // taskId:[{required: true, message: '请输入任务单代码', trigger: 'blur'}],
      // }
    }
  },

  methods: {
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleNext() {
      let ids = this.multipleSelection.map(v=>{
        this.dispatchingOrder.id = v.id
        this.dispatchingOrder.outId = v.outId
        this.dispatchingOrder.inId = v.inId
        this.dispatchingOrder.status = v.status
        this.dispatchingOrder.type = v.type
        this.dispatchingOrder.productId = v.productId
        this.dispatchingOrder.productNum = v.productNum
        this.dispatchingOrder.actualNum = v.actualNum
        this.dispatchingOrder.unit = v.unit
        this.dispatchingOrder.planOutDate = v.planOutDate
        this.dispatchingOrder.orderId = v.orderId
        this.dispatchingOrder.taskId = v.taskId
      })
      ElMessageBox.confirm(
          '是否入库选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          this.$http.post(ipaddress+"/storeManagement/inSubstationStore",this.dispatchingOrder).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('失败！')
          })
        })
      })
      //   if(this.multipleSelection.length === 1){
      //     console.log(this.multipleSelection)
      //     this.dispatchingOrder.id = this.multipleSelection[0].id
      //     this.dispatchingOrder.outId = this.multipleSelection[0].outId
      //     this.dispatchingOrder.inId = this.multipleSelection[0].inId
      //     this.dispatchingOrder.status = this.multipleSelection[0].status
      //     this.dispatchingOrder.type = this.multipleSelection[0].type
      //     this.dispatchingOrder.productId = this.multipleSelection[0].productId
      //     this.dispatchingOrder.productNum = this.multipleSelection[0].productNum
      //     this.dispatchingOrder.actualNum = this.multipleSelection[0].actualNum
      //     this.dispatchingOrder.unit = this.multipleSelection[0].unit
      //     this.dispatchingOrder.planOutDate = this.multipleSelection[0].planOutDate
      //     this.dispatchingOrder.orderId = this.multipleSelection[0].orderId
      //     this.dispatchingOrder.taskId = this.multipleSelection[0].taskId
      //     this.$emit('handleNext',this.dispatchingOrder)
      //   }else if(this.multipleSelection.length === 0){
      //     ElMessage({
      //       message: '请选择一条数据！',
      //       type: 'warning',
      //     })
      //   }else{
      //     ElMessage({
      //       message: '只能选择一条数据！',
      //       type: 'warning',
      //     })
      //   }
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    // addData(resetForm){
    //   let dialogFormVisible = this.dialogFormVisible;
    //   if(dialogFormVisible){
    //     this.$refs[resetForm].validate((valid)=>{
    //       if(valid){
    //         this.$http.post(ipaddress+"/customer/addCustomer",this.form).then(res=>{
    //           if(res.code === '666'){
    //             ElMessage({
    //               message: '成功！',
    //               type: 'success',
    //             })
    //             this.dialogFormVisible=false
    //             this.network()
    //           }
    //         }).catch(()=>{
    //           ElMessage.error('失败！')
    //         })
    //       }else{
    //         ElMessage({
    //           message: '已取消！',
    //           type: 'warning',
    //         })
    //         return false;
    //       }
    //     })
    //   }
    // },
    network(){
      requestData.status = this.status;
      requestData.type = this.type;
      requestData.planOutDate = this.filterTime(this.planOutDate);
      // console.log(ipaddress)
      this.$http.post(ipaddress+`/dispatchingOrder/getDispatchingOrderByQuery?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,requestData).then(res=>{
        console.log(res);
        if(res.code === '666'){
          this.tableData = res.data.list;
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}

        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    }
  },
  created() {
    console.log('created')
  }
}
</script>

<template>

  <div class="dispatchingOrderShow">
    <!--    <el-input placeholder="请输入查询日期" style="width: 200px;padding: 10px;" v-model="planOutDate"></el-input>-->
    <el-date-picker
        v-model="planOutDate"
        type="datetime"
        placeholder="选择日期"
        format="YYYY-MM-DD HH:mm:ss"
        autocomplete="off"
    />
    <el-button @click="network()">查找调拨入库单</el-button>
    <div v-if="isFound">
      <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed type="selection" width="80px" align="center"></el-table-column>
        <el-table-column fixed prop="id" label="id" width="80px" sortable align="center"></el-table-column>
        <el-table-column prop="productId" label="商品代码" width="100px" align="center"></el-table-column>
        <el-table-column prop="productNum" label="商品数量" width="150px" align="center"></el-table-column>
        <el-table-column prop="unit" label="计量单位" width="80px" align="center"></el-table-column>
        <el-table-column prop="planOutDate" label="日期" width="120px" align="center"></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <div v-if="notFound">
      不存在此日期的调拨入库单
      <br/>
      <!--      <el-button type="primary" @click="dialogFormVisible = true">新增客户</el-button>-->
      <!--      <el-dialog title="客户添加" v-model="dialogFormVisible" width="50%">-->
      <!--        <el-form :model="form" size="medium" :rules="rules" ref="form">-->
      <!--          <el-form-item label="客户姓名" :label-width="formLabelWidth" prop="name">-->
      <!--            <el-input v-model="form.name" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="卡号" :label-width="formLabelWidth" prop="idCardNum">-->
      <!--            <el-input v-model="form.idCardNum" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="公司" :label-width="formLabelWidth" prop="company">-->
      <!--            <el-input v-model="form.company" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="座机" :label-width="formLabelWidth" prop="officePhone">-->
      <!--            <el-input v-model="form.officePhone" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="手机" :label-width="formLabelWidth" prop="cellPhone">-->
      <!--            <el-input v-model="form.cellPhone" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">-->
      <!--            <el-input v-model="form.postcode" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">-->
      <!--            <el-input v-model="form.email" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="收货地址" :label-width="formLabelWidth" prop="deliveryAddress">-->
      <!--            <el-input v-model="form.deliveryAddress" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->
      <!--          <el-form-item label="地区" :label-width="formLabelWidth" prop="region">-->
      <!--            <el-input v-model="form.region" autocomplete="off"></el-input>-->
      <!--          </el-form-item>-->

      <!--        </el-form>-->

      <!--        <template #footer>-->
      <!--      <span class="dialog-footer">-->
      <!--        <el-button @click="dialogFormVisible = false"> 取消</el-button>-->
      <!--        <el-button type="primary" @click="addData('form')"> 确认</el-button>-->
      <!--      </span>-->
      <!--        </template>-->
      <!--      </el-dialog>-->
    </div>
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handleNext()">入库</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
