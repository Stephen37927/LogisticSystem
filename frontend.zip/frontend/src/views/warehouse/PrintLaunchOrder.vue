<script>

import {ElMessage, ElMessageBox} from "element-plus";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

let ipaddress = "/warehouseManagement"

let requestData = {

}

export default {
  name: 'print-out-order',

  data(){
    return {
      date: '',
      productName: "",
      storeName: "",
      locale: zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      isFound: false,
      notFound: false,
      dialogFormVisible: false,
      formLabelWidth: '100px',
      multipleSelection: [],
      dispatchingOrder:{},
      form: {}
    }
  },

  methods: {
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleNext() {
      let ids = this.multipleSelection.map(v=>{
        this.dispatchingOrder.id = v.id
        this.dispatchingOrder.outId = v.outId
        this.dispatchingOrder.inId = v.inId
        this.dispatchingOrder.status = v.status
        this.dispatchingOrder.type = v.type
        this.dispatchingOrder.productId = v.productId
        this.dispatchingOrder.productNum = v.productNum
        this.dispatchingOrder.actualNum = v.actualNum
        this.dispatchingOrder.unit = v.unit
        this.dispatchingOrder.planOutDate = v.planOutDate
        this.dispatchingOrder.orderId = v.orderId
        this.dispatchingOrder.taskId = v.taskId
      })
      ElMessageBox.confirm(
          '是否打印分发单？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          // this.$http.post(ipaddress+"/storeManagement/inCenterStore",this.dispatchingOrder).then(res=>{
          //   if(res.code === '666'){
          ElMessage({
            message: '成功！',
            type: 'success',
          })
          //     this.network()
          //   }
          // }).catch(()=>{
          //   ElMessage.error('失败！')
          // })
        })
      })
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    network(){
      // console.log(ipaddress)
      console.log("aaa")
      console.log(this.date)
      console.log(this.productName)
      this.date = this.filterTime(this.date)
      this.$http.post(ipaddress+`/storeManagement/printOutStoreOrder?date=${this.date}&productName=${this.productName}&PageSize=${this.pageSize}
      &pageNum=${this.pageNum}&storeName=${this.storeName}`,requestData).then(res=>{
        console.log(res);
        if(res.code === '666'){
          this.tableData = res.data.list;
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}

        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    }
  },
  created() {
    console.log('created')
  }
}
</script>

<template>

  <div class="dispatchingOrderShow">
    <el-date-picker
        v-model="date"
        type="datetime"
        placeholder="选择日期"
        format="YYYY-MM-DD HH:mm:ss"
        autocomplete="off"
    /> &thinsp;
    <el-input placeholder="请输入商品名称" style="width: 200px;padding: 10px;" v-model="productName"></el-input>
    <el-input placeholder="请输入仓库名称" style="width: 200px;padding: 10px;" v-model="storeName"></el-input>

    <el-button @click="network()">查找分发单</el-button>
    <div v-if="isFound">
      <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed prop="productId" label="商品代码" width="80px" sortable align="center"></el-table-column>
        <el-table-column prop="productName" label="商品名称" width="100px" align="center"></el-table-column>
        <el-table-column prop="sellingPrice" label="售价" width="150px" align="center"></el-table-column>
        <el-table-column prop="productNum" label="数量" width="80px" align="center"></el-table-column>
        <el-table-column prop="supplier" label="厂商" width="120px" align="center"></el-table-column>
        <el-table-column prop="discount" label="折扣" width="120px" align="center"></el-table-column>
        <el-table-column prop="totalPrice" label="总金额" width="120px" align="center"></el-table-column>
        <el-table-column prop="date" label="日期" width="120px" align="center"></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <div v-if="notFound">
      不存在此日期此商品的分发单
      <br/>
    </div>
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handleNext()">打印</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
