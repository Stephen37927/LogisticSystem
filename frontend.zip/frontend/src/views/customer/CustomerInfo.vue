<template>
    <div class="classOneItemShow">
      <!--    页面头部选择筛选条件-->
      <div style="padding: 0px 0">
        <el-input style="width: 250px" placeholder="请输入名称" :suffix-icon="Search" v-model="searchName"></el-input>
        &emsp;

        <el-select v-model="searchType" placeholder="请选择搜索类型">
          <el-option v-for="option in options" :key="option.value" :value="option.value" :label="option.label"></el-option>
        </el-select>
        &emsp;
        <!--    查询按钮-->
        <el-button type="primary" style="margin-left: 0px" @click="network">
          <el-icon style="vertical-align: middle;">
            <search />
          </el-icon>
          <span style="vertical-align: middle;"> 添加筛选 </span>
        </el-button>
      </div>
      <!--    选中的标签-->
      <div>
        <el-tag v-for="tag in tags" :key="tag" closable @close="removeTag(tag)">
          {{ tag }}
        </el-tag>
      </div>
      <!--    查询按钮-->
      <div style="padding: 10px 0">
        <el-button type="primary" @click="addItem">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
        <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
      </div>
      <!--    主表格-->
      <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed type="selection" width="80px" align="center"></el-table-column>
        <el-table-column fixed prop="id" label="id" width="80px" sortable align="center"></el-table-column>
        <el-table-column prop="name" label="客户名称" width="100px" align="center"></el-table-column>
        <el-table-column prop="idCardNum" label="卡号" width="150px" align="center"></el-table-column>
        <el-table-column prop="company" label="公司" width="80px" align="center"></el-table-column>
        <el-table-column prop="officePhone" label="座机" width="120px" align="center"></el-table-column>
        <el-table-column prop="cellPhone" label="手机" width="100px"  align="center"></el-table-column>
        <el-table-column prop="postcode" label="邮编" width="100px" align="center"></el-table-column>
        <el-table-column prop="email" label="邮箱" width="80px" align="center"></el-table-column>
        <el-table-column prop="deliveryAddress" label="收货地址" width="100px" align="center"></el-table-column>
        <el-table-column prop="region" label="地区" width="80px" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" width="200px"  align="center">
          <template v-slot="scope" #default>
            <!-- 编辑按钮 -->
            <el-button @click="handleClick(scope.row)" type="warning" size="default">编辑&thinsp;
              <el-icon> <edit/></el-icon>
            </el-button>
            <!-- 删除按钮 -->
            <el-button @click="delOne(scope.row.id)" type="danger" size="default">删除&thinsp;
              <el-icon> <DeleteFilled /></el-icon>
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!--    控制分页-->
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[8, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
      <!--    添加客户信息对话框-->
      <el-dialog title="客户添加" v-model="dialogFormVisible" width="50%">
        <el-form :model="form" size="medium" :rules="rules" ref="form">
          <el-form-item label="客户姓名" :label-width="formLabelWidth" prop="name">
            <el-input v-model="form.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="卡号" :label-width="formLabelWidth" prop="idCardNum">
            <el-input v-model="form.idCardNum" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="公司" :label-width="formLabelWidth" prop="company">
            <el-input v-model="form.company" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="座机" :label-width="formLabelWidth" prop="officePhone">
            <el-input v-model="form.officePhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="手机" :label-width="formLabelWidth" prop="cellPhone">
            <el-input v-model="form.cellPhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">
            <el-input v-model="form.postcode" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
            <el-input v-model="form.email" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="收货地址" :label-width="formLabelWidth" prop="deliveryAddress">
            <el-input v-model="form.deliveryAddress" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="地区" :label-width="formLabelWidth" prop="region">
            <el-input v-model="form.region" autocomplete="off"></el-input>
          </el-form-item>

        </el-form>

        <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
        </template>
      </el-dialog>
      <!--修改客户信息对话框-->
      <el-dialog title="客户信息修改" v-model="dialogModVisible" width="50%">
        <el-form :model="formMod" size="default" :rules="rules" ref="formMod">
          <el-form-item label="客户姓名" :label-width="formLabelWidth" prop="name">
            <el-input v-model="formMod.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="卡号" :label-width="formLabelWidth" prop="idCardNum">
            <el-input v-model="formMod.idCardNum" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="公司" :label-width="formLabelWidth" prop="company">
            <el-input v-model="formMod.company" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="工作电话" :label-width="formLabelWidth" prop="officePhone">
            <el-input v-model="formMod.officePhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="手机" :label-width="formLabelWidth" prop="cellPhone">
            <el-input v-model="formMod.cellPhone" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">
            <el-input v-model="formMod.postcode" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
            <el-input v-model="formMod.email" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="收货地址" :label-width="formLabelWidth" prop="deliveryAddress">
            <el-input v-model="formMod.deliveryAddress" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="地区" :label-width="formLabelWidth" prop="region">
            <el-input v-model="formMod.region" autocomplete="off"></el-input>
          </el-form-item>

        </el-form>

        <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogModVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
        </template>
      </el-dialog>

    </div>

</template>

<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {CirclePlus, Search} from '@element-plus/icons-vue'
import {ElMessageBox, ElMessage } from 'element-plus'
import { ref } from 'vue'

let ipaddress = "/customerManagement";

let requestData = { // Declare requestData as a global variable
  "id": "",
  "name": "",
  "idCardNum": "",
  "company": "",
  "officePhone": "",
  "cellPhone": "",
  "postcode": "",
  "email": "",
  "deliveryAddress": "",
  "region": ""
};

export default {
  name: "CustomerInfo",
  components:{
    CirclePlus,
    Search,
  },
  data() {
    return {
      tags:[],
      options: ["姓名","卡号","公司","公司电话","手机","邮编","邮箱","地址","地区"],
      Search,
      locale:zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 8, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        name: [{ required: true, message: '请输入客户姓名', trigger: 'blur' }],
        idCardNum:[{required: true, message: '请输入客户卡号', trigger: 'blur'}],
        company:[{required: true, message: '请输入公司', trigger: 'blur'}],
        officePhone:[{required: true, message: '请输入座机', trigger: 'blur'}],
        cellPhone:[{required: true, message: '请输入手机号', trigger: 'blur'}],
        postcode:[{required: true, message: '请输入邮编', trigger: 'blur'}],
        email:[{required: true, message: '请输入邮编', trigger: 'blur'}],
        deliveryAddress:[{required: true, message: '请输入收货地址', trigger: 'blur'}],
        region:[{required: true, message: '请输入地区', trigger: 'blur'}],
      }
    }
  },

  methods:{
    removeTag(tag) {
      const index = this.tags.indexOf(tag);

      if (index !== -1) {
        this.tags.splice(index, 1);

        if (tag.type === 'name') {
          //console.log("hello")
          requestData.name = '';
        } else if (tag.type === 'idCardNum') {
          requestData.idCardNum = '';
        } else if (tag.type === 'company') {
          requestData.company = '';
        } else if (tag.type === 'officePhone') {
          requestData.officePhone = '';
        } else if (tag.type === 'cellPhone') {
          requestData.cellPhone = '';
        } else if (tag.type === 'postcode') {
          requestData.postcode = '';
        } else if (tag.type === 'email') {
          requestData.email = '';
        } else if (tag.type === 'deliveryAddress') {
          requestData.deliveryAddress = '';
        } else if (tag.type === 'region') {
          requestData.region = '';
        }

        this.$http.post(ipaddress+
            `/customer/getCustomerByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
        ).then(res=>{
          if(res.code == '666'){
            console.log(res)
            this.total = res.data.total //need
            console.log(res.data.list)
            this.tableData = res.data.list
            console.log(this.tableData)
          }
        }).catch(()=>{
          ElMessage.error('数据加载失败,请刷新！')
        })
      }
    },
    getOptions() {
      // 发起请求或从其他地方获取选项数据
      // 将获取到的数据赋值给options数组
      this.options = [
        { value: 'name', label: '姓名' },
        { value: 'idCardNum', label: '卡号' },
        { value: 'company', label: '公司' },
        { value: 'officePhone', label: '座机' },
        { value: 'cellPhone', label: '手机' },
        { value: 'postcode', label: '邮编' },
        { value: 'email', label: '邮箱' },
        { value: 'deliveryAddress', label: '收货地址' },
        { value: 'region', label: '地区'}
      ];
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/customer/deleteCustomer",{"id":v}).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '删除成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    delOne(id){ //删除
      console.log(id)
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/customer/deleteCustomer",{"id":id}).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    handleClick(row){ //编辑
      console.log("_______");
      console.log(row);
      console.log("_______");
      //console.log(form);
      this.formMod = JSON.parse(JSON.stringify(row));
      this.dialogModVisible=true
    },
    saveData(resetForm){ //用于数据的添加和更新
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      if(dialogFormVisible){
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            this.$http.post(ipaddress+"/customer/addCustomer",this.form).then(res=>{
              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        this.$http.post(ipaddress+"/customer/updateCustomerById",this.formMod).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }

    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      this.form = {}
    },
    network(){ //分页查询

      if(this.searchName!="")
        this.tags.push({ name: this.searchName, type: this.searchType });


      if (this.searchType === 'name') {
        requestData.name = this.searchName;
      } else if (this.searchType === 'idCardNum') {
        requestData.idCardNum = this.searchName;
      }else if (this.searchType === 'company') {
        requestData.company = this.searchName;
      }else if (this.searchType === 'officePhone') {
        requestData.officePhone = this.searchName;
      }else if (this.searchType === 'cellPhone') {
        requestData.cellPhone = this.searchName;
      }else if (this.searchType === 'postcode') {
        requestData.postcode = this.searchName;
      }else if (this.searchType === 'email') {
        requestData.email = this.searchName;
      }else if (this.searchType === 'deliveryAddress') {
        requestData.deliveryAddress = this.searchName;
      }else if (this.searchType === 'region') {
        requestData.region = this.searchName;
      }

      this.$http.post(ipaddress+
          `/customer/getCustomerByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
      ).then(res=>{
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.total //need
          console.log(res.data.list)
          this.tableData = res.data.list
          console.log(this.tableData)
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },
  created() {
    this.getOptions();
    this.network()
  }
}
</script>

<style >
.classOneItemShow{
  margin-left: 0px;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}

</style>

