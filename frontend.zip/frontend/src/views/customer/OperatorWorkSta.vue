<script>
import { defineComponent ,onMounted ,getCurrentInstance ,ref } from 'vue'
export default defineComponent({
  mounted() {
    // this.$echarts调用 初始化
    let myChart = this.$echarts.init(document.getElementById("echart"));
    // 绘制图表
    myChart.setOption({
      title:{
        text: "操作员工作统计",
      },
      tooltip: {},
      legend:{
        data:["送货","退货","换货","退订"]
      },
      xAxis: {
        data :['徐璟涛','赵静好','林旭','沈祺','瑟米'],
        name:'操作员'
      },
      yAxis: {
        name: '金额 ￥'
      },
      series: [
        {
          name: "送货",
          type: "bar",
          data: [1789,3149,2398,1738,488],
        },
        {
          name:"退货",
          type:"bar",
          data:[248,1728,3142,1298,231]
        },
        {
          name:"换货",
          type:"bar",
          data:[1389,2934,1291,2471,52]
        },
        {
          name:"退订",
          type:"bar",
          data:[2671,2811,1271,2942,118]
        }
      ]
    });
  },
})

</script>

<template>

<!--  <div id="myChart" style="width: 1000px;height:400px"></div>-->
  <div id="echart" :style="{ float: 'left', width: '90%', height: '400px'  }"></div>
</template>

<style scoped>

</style>
