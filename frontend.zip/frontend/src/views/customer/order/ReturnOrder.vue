<script>
import router from '@/router/router'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

export default {
  name: 'return-order',

  data() {
    return {
      active: 0,//当前步骤
      stepSuccess: [0],//已完成步骤
      stepTitle: ['退货客户查询', '退货配送信息', '退货完成']

    }
  },

  computed: {
    stepClassObj() {
      return (val) => {
        return {
          stepSuccess: this.stepSuccess.includes(val),
          stepError: !this.stepSuccess.includes(val)
        }
      }
    }
  },

  methods: {
    handleStep(val) {
      console.log(val, 'click steps')
      if (this.stepSuccess.includes(val) === true) {
        this.active = val
        // if(this.active === 0){
        //   router.push("/neword/customer-query");
        // }
        switch (this.active) {
          case 0:
            router.push("/returnord/return-customer-query");
            break;
          case 1:
            router.push("/returnord/return-delivery-info");
            break;
          case 2:
            router.push("/returnord/return-finish");
            break;
        }
      }
    },
    handleNext(obj) {
      if (this.active < 2) {
        this.active++
        this.stepSuccess.push(this.active)
        switch (this.active) {
          case 0:
            router.push("/returnord/return-customer-query");
            break;
          case 1:
            router.push({
              path: '/returnord/return-delivery-info',
              query: obj
            })
            break;
          case 2:
            router.push({
              path: '/returnord/return-finish',
              query: obj
            })
            break;
        }
      }
    },
    handlePrev() {
      console.log('click prev')
      if (this.active > 0) {
        this.active--
        this.stepSuccess.pop()
        switch (this.active) {
          case 0:
            router.push("/returnord/return-customer-query");
            break;
          case 1:
            router.push("/returnord/return-delivery-info");
            break;
          case 2:
            router.push("/returnord/return-finish");
            break;
        }
      }
    },
    handlePathChange(){
      console.log('path change')
      // 获取当前路径
      let path = router.currentRoute.value.path
      console.log(path)
      if(path === '/returnord/return-finish') {
        this.active = 2
        this.stepSuccess = [0, 1, 2]
      }else{
        console.log('error')
      }
    },
    transferObj(obj){
      console.log(obj)
      let customer = obj.customer
      let delivery = obj.delivery
      let order = {}
      order.type = delivery.type;
      order.customerId = customer.id
      order.receiver = delivery.receiver
      order.receiverPhone = delivery.receiverPhone
      order.receiverPostCode = delivery.receiverPostcode
      order.isReceipt = delivery.isReceipt
      order.comment = delivery.comment
      order.subStationId = delivery.subStation
      order.deliveryAddress = delivery.deliveryAddress
      order.generationDate = delivery.generationDate
      order.requestArrivalDate = delivery.requestArrivalDate
      console.log('return-order')
      console.log(order)
      return order;
    }
  },
  mounted() {
    this.handlePathChange()
    console.log('return-order')
  }
}
</script>

<template>
  <div class="returnOrder">
    新建退货订单
    <el-steps :active="active" finish-status="success">
      <el-step
          v-for="(item,index) of stepTitle"
          :key="index"
          :title="item"
          :class="stepClassObj(index)"
          @click.native="handleStep(index)">
      </el-step>
    </el-steps>
    <router-view @handleNext="handleNext" @handlePrev="handlePrev()"></router-view>
  </div>
</template>

<style scoped>
/*
.newOrder {
  padding: 18px 12px 16px;
  background-color: rgb(38, 38, 63);
}

.pane {
  margin-top: 18px;
  padding: 18px 12px 16px;
  background-color: #cccccc;
}

 */

.stepSuccess :hover{
  cursor: pointer;
}

.stepError :hover{
  cursor: not-allowed;
}
</style>
