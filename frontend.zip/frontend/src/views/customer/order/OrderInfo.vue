<script>

import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage} from "element-plus";
import {Edit} from "@element-plus/icons-vue";

let ipaddress = "/customerManagement"
let disIpaddress = "/distributionManagement"

export default{
  name:'order-info',
  components: {Edit},

  data(){
    return {
      orderId: '',
      startDateR: '',
      finishDateR: '',
      startDateG: '',
      finishDateG: '',
      customer: '',
      receiver:'',
      mainInfoTable: [],
      detailInfoTable: [],
      multipleSelection: [],
      states: [],
      selectedStates: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      locale: zhCn,
      dialogVisible: false,
      tuidingVisible:false,
      tuidingForm:{} //退订表单
    }
  },
  methods:{
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    statusTransfer(status){
      let result = ''
      switch(status){
        case 1:
          result = '可分配'
          break
        case 2:
          result = '缺货挂起'
          break
        case 3:
          result = '已调度'
          break
        case 4:
          result = '中心库房出库'
          break
        case 5:
          result = '配送站到货'
          break
        case 6:
          result = '已分配'
          break
        case 7:
          result = '已领货'
          break
        case 8:
          result = '已完成'
          break
        case 9:
          result = '取消订单'
          break
        case 10:
          result = '部分完成'
          break
        case 11:
          result = '失败'
          break
        case 12:
          result = '换货中'
          break
        case '可分配':
          result = 1
          break
        case '缺货挂起':
          result = 2
          break
        case '已调度':
          result = 3
          break
        case '中心库房出库':
          result = 4
          break
        case '配送站到货':
          result = 5
          break
        case '已分配':
          result = 6
          break
        case '已领货':
          result = 7
          break
        case '已完成':
          result = 8
          break
        case '取消订单':
          result = 9
          break
        case '部分完成':
          result = 10
          break
        case '失败':
          result = 11
          break
        case '换货中':
          result = 12
          break
        default:
          result = '未知状态'
      }
      return result
    },
    isReceiptTransfer(isReceipt){
      let result = ''
      switch(isReceipt){
        case 0:
          result = '未填'
          break
        case 1:
          result = '否'
          break
        case 2:
          result = '是'
          break
        default:
          result = '未知状态'
      }
      return result
    },
    typeTransfer(type){
      let result = ''
      switch(type){
        case 1:
          result = '普通配送订单'
          break
        case 2:
          result = '换货单'
          break
        case 3:
          result = '退货单'
          break
        case 4:
          result = '退订单'
          break
        default:
          result = '未知状态'
      }
      return result
    },
    getStates(){
      // 生成一个1-9的数组
      let arr = []
      for(let i = 1; i < 13; i++){
        arr.push(i)
      }
      arr.forEach(item=>{
        let obj = {}
        obj.id = item
        obj.name = this.statusTransfer(item)
        this.states.push(obj)
      })
      console.log(this.states)
    },
    handleCheckChange(){
      console.log('checkChange')

    },
    getSupplierName(id){
      let supplierName = ""
      this.$http.get(disIpaddress + `/supplier/getSupplierById/`+id).then(response=>{
        console.log('supplier',response)
        if(response.code === '666'){
          supplierName = response.data.name
        }else{
          console.log('unknown')
          supplierName = "未知"
          console.log('unknown supplierName',supplierName)
        }
      }).catch(err=>{
        console.log(err)
        supplierName = "未知"
      })
      return supplierName
    },
    handleClick(row){
      this.dialogVisible = true;
      let requestData = {
        "id": row.orderId
      }
      this.$http.post(ipaddress + `/order/getOrderItemsByQuery?pageNum=${this.pageNum}&PageSize=${this.pageSize}`,requestData).then(res=>{
        console.log(res)
        if(res.code === '666'){
          // this.detailInfoTable = res.data.data
          this.detailInfoTable = []
          res.data.list.forEach(item=>{
            let supplierName = this.getSupplierName(item.product.supplierId)
            console.log('transferred supplierName',supplierName)
            this.detailInfoTable.push({
              "goodsName":item.product.name,
              "goodsPrice":item.product.sellingPrice,
              "discount":item.product.discount,
              "supplier":supplierName,
              "shelfLife":item.product.shelfLife,
              "purchaseAmt":item.num,
              "unit":item.product.unit,
              "singleSum":item.product.sellingPrice * item.num * item.product.discount/10,
            })
          })
          console.log('success')
        }
      }).catch(err=>{
        console.log(err)
      })
    },
    confirm(){
      this.dialogVisible = false;
    },
    tuiding(row){
      let request = {
        "id": row.orderId,
        "type":4
      }
      this.$http.post(ipaddress+`/order/updateOrderById`,request).then(res=>{
        if(res.code==='666'){
          ElMessage.success('退订成功')
          this.network()
        }else{
          ElMessage.error(res.message)
        }
      }).catch(err=>{
        console.log(err)
      })
    },
    network(){
      console.log('ipaddress',ipaddress)
      let requestData = []
      this.mainInfoTable = []
      console.log('selected options',this.selectedStates)
      if(this.selectedStates.length >0){
        this.selectedStates.forEach(item => {
          requestData.push({
            "id": this.orderId,
            "startDateR": this.startDateR===''?'':this.filterTime(this.startDateR),
            "finishDateR": this.finishDateR===''?'':this.filterTime(this.finishDateR),
            "startDateG": this.startDateG===''?'':this.filterTime(this.startDateG),
            "finishDateG": this.finishDateG===''?'':this.filterTime(this.finishDateG),
            "customer": this.customer,
            "receiver": this.receiver,
            "status": this.statusTransfer(item)
          })
          console.log("reque",requestData)
        })
      }else{
        requestData.push({
          "id": this.orderId,
          "startDateR": this.startDateR===''?'':this.filterTime(this.startDateR),
          "finishDateR": this.finishDateR===''?'':this.filterTime(this.finishDateR),
          "startDateG": this.startDateG===''?'':this.filterTime(this.startDateG),
          "finishDateG": this.finishDateG===''?'':this.filterTime(this.finishDateG),
          "customer": this.customer,
          "receiver": this.receiver,
          "status": ''
        })
        console.log("reque",requestData)
      }
      this.mainInfoTable = []
      this.$http.post(ipaddress+`/order/getOrderByQuery?pageNum=${this.pageNum}
      &PageSize=${this.pageSize}`, requestData).then(response=>{
        if(response.code === '666'){
          this.total = response.data.totalItems
          response.data.pageItems.forEach(item=>{
            let obj = {}
            obj.orderId = item.order.id
            obj.customer = item.customer.name
            obj.receiver = item.order.receiver
            obj.receiverPhone = item.order.receiverPhone
            obj.sumPrice = item.order.sumPrice
            obj.status = this.statusTransfer(item.order.status)
            obj.type = this.typeTransfer(item.order.type)
            obj.generationDate = this.filterTime(item.order.generationDate)
            obj.requestArrivalDate = this.filterTime(item.order.requestArrivalDate)
            obj.isReceipt = this.isReceiptTransfer(item.order.isReceipt)
            this.mainInfoTable.push(obj)
          })
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    },
  },
  created(){
    this.getStates()
    this.network()
  }

}
</script>

<template>
<!--  订单信息查询-->
  <div class="order-info">
    <div class="header">
      <el-input placeholder="订单编号" style="width: 200px;padding: 10px;" v-model="orderId"></el-input>
      <el-input placeholder="客户姓名" style="width: 200px;padding: 10px;" v-model="customer"></el-input>
      <el-input placeholder="收货人姓名" style="width: 200px;padding: 10px;" v-model="receiver"></el-input>
      <el-button type="primary" style="margin-left: 10px;" @click="network">查询</el-button>
      <el-button type="primary" style="margin-left: 10px;" @click="reset">重置</el-button>

      <div class="datePickers" style="margin-left: 10px;">
        <el-date-picker
            v-model="startDateG"
            type="datetime"
            placeholder="开始日期(订单生成）"
            style="width: 285px; --el-input-placeholder-color: darkgreen;"
            format="YYYY/MM/DD HH:mm:ss"/>&emsp;
        <el-date-picker
            v-model="finishDateG"
            type="datetime"
            placeholder="结束日期(订单生成）"
            style="width: 285px; --el-input-placeholder-color: darkred;"
            format="YYYY/MM/DD HH:mm:ss"/>&emsp;
        <el-date-picker
            v-model="startDateR"
            type="datetime"
            placeholder="开始日期(要求完成）"
            style="width: 285px; --el-input-placeholder-color: darkgreen;"
            format="YYYY/MM/DD HH:mm:ss"/>&emsp;
        <el-date-picker
            v-model="finishDateR"
            type="datetime"
            placeholder="结束日期(要求完成）"
            style="width: 285px; --el-input-placeholder-color: darkred;"
            format="YYYY/MM/DD HH:mm:ss"/>&emsp;
      </div>
      <div class="statusPickers">
<!--        <span>订单状态：</span>-->
        <el-checkbox-group v-model="selectedStates">
          <el-checkbox v-for="item in states"
                       :label="item.name"
                       :value="item.id"
                       @change="handleCheckChange"
          />
        </el-checkbox-group>
      </div>
    </div>
    <br/>
    <div class="main-info">
      <el-table :data="mainInfoTable" border style="width: 100%" @selection-change="handleSelectionChange">
        <el-table-column fixed type="index" width="40" align="center"></el-table-column>
        <el-table-column fixed prop="orderId" label="订单编号" align="center" sortable></el-table-column>
        <el-table-column prop="customer" label="客户姓名" align="center"></el-table-column>
        <el-table-column prop="receiver" label="接收人" align="center"></el-table-column>
        <el-table-column prop="receiverPhone" label="接收人电话" align="center"></el-table-column>
        <el-table-column prop="sumPrice" label="订单总金额" align="center"></el-table-column>
        <el-table-column prop="status" label="订单状态" align="center"></el-table-column>
        <el-table-column prop="type" label="订单类型" align="center"></el-table-column>
        <el-table-column prop="generationDate" label="订单生成日期" align="center"></el-table-column>
        <el-table-column prop="requestArrivalDate" label="要求完成日期" align="center"></el-table-column>
        <el-table-column prop="isReceipt" label="是否索取发票" align="center"></el-table-column>
        <el-table-column fixed="right" label="操作" width="200px"  align="center">
          <template v-slot="scope" #default>
            <el-button @click="handleClick(scope.row)" type="warning" size="default">详情&thinsp;
<!--              <el-icon> <edit/></el-icon>-->
            </el-button>
            <el-button type="danger" size="default" @click="tuidingVisible=true;tuiding(scope.row)">退订&thinsp;</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
    </div>
    <el-dialog v-model="dialogVisible">
      <el-table :data="detailInfoTable" border style="width: 100%">
        <el-table-column fixed type="index" width="40" align="center"></el-table-column>
        <el-table-column prop="goodsName" label="商品名称" align="center"></el-table-column>
        <el-table-column prop="goodsPrice" label="单价" align="center"></el-table-column>
        <el-table-column prop="discount" label="折扣" align="center"></el-table-column>
<!--        <el-table-column prop="supplier" label="供应商" align="center"></el-table-column>-->
        <el-table-column prop="shelfLife" label="保质期" align="center"></el-table-column>
        <el-table-column prop="purchaseAmt" label="购买数量" align="center"></el-table-column>
        <el-table-column prop="unit" label="单位" align="center"></el-table-column>
        <el-table-column prop="singleSum" label="单笔总价" align="center"></el-table-column>
<!--        <el-table-column prop="tuidingAmt" label="退订数量" align="center">-->
<!--          <el-input type="text" v-model="row.tuidingAmt" auto-complete="off"></el-input>-->
<!--        </el-table-column>-->
      </el-table>
      <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="confirm"> 确认 </el-button>
<!--        <el-button type="danger" @click="tuiding">退订</el-button>-->
      </span>
      </template>
    </el-dialog>
<!--    <el-dialog v-model="tuidingVisible">-->
<!--      <el-form :model="tuidingForm" ref="tuidingForm" label-width="80px" class="demo-ruleForm">-->
<!--        <el-form-item label="退订个数" prop="tuidingAmt">-->
<!--          <el-input type="text" v-model="tuidingForm.reason" auto-complete="off"></el-input></el-form-item>-->
<!--        <el-form-item label="退订原因" prop="tuidingRson">-->
<!--          <el-input type="text" v-model="tuidingForm.reason" auto-complete="off"></el-input></el-form-item>-->
<!--      </el-form>-->
<!--      <template #footer>-->
<!--      <span class="dialog-footer">-->
<!--        <el-button type="primary"> 确认 </el-button>-->
<!--      </span>-->
<!--      </template>-->
<!--    </el-dialog>-->
  </div>
</template>

<style scoped>

</style>
