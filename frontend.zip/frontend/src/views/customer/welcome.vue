<script>
import router from '@/router/router'

export default {
  name: 'welcome-page'
}
</script>

<template>
  <el-card shadow= 'hover'>
    <div class="userCard">
      <div>
        <el-avatar :size="15" :src=imgUrl style="background-color: greenyellow"></el-avatar>
        <b5 style="font-size: 20px"> &thinsp; WELCOME</b5>
      </div>

      <div class="userInfo">
        <p class="important-font" style="color: #007bff; font-size: 15px">Admin</p>
        <p class="secondary-font" style="font-size: 15px">管理员</p>
      </div>
    </div>
    <div class="login-info">
      <p style="font-size: 15px">上次登录时间: 2022/07/21</p>
    </div>
  </el-card>
</template>

<style scoped>


</style>
