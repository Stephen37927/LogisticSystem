<template>
  <div class="classOneItemShow">
<!--    filter conditions-->
    <div style="padding: 10px 0">
      <el-input style="width: 250px;padding-right: 10px" placeholder="请输入名称" :suffix-icon="Search" v-model="searchName"></el-input>

      <el-select v-model="searchType" placeholder="请选择搜索类型">
        <el-option v-for="option in options" :key="option.value" :value="option.value" :label="option.label"></el-option>
      </el-select>

      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertical-align: middle;"> 添加筛选 </span>
      </el-button>
    </div>
    <div>
      <el-tag v-for="tag in tags" :key="tag" closable @close="removeTag(tag)">
        {{ tag }}
      </el-tag>
    </div>
    <div style="padding: 10px 0">
      <el-button type="primary" @click="addItem">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
      <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
    </div>
    <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="80px" align="center"></el-table-column>
<!--      <el-table-column type="index"-->
      <el-table-column fixed prop="id" label="id" width="80px" sortable align="center"></el-table-column>
      <el-table-column prop="name" label="供应商名称" width="100px" align="center"></el-table-column>
      <el-table-column prop="address" label="地址" width="150px" align="center"></el-table-column>
      <el-table-column prop="linkman" label="联系人" width="80px" align="center"></el-table-column>
      <el-table-column prop="phone" label="电话" width="120px" align="center"></el-table-column>
      <el-table-column prop="bank" label="开户银行" width="100px"  align="center"></el-table-column>
      <el-table-column prop="bankAccount" label="银行账号" width="100px" align="center"></el-table-column>
      <el-table-column prop="legalPerson" label="法人" width="80px" align="center"></el-table-column>
      <el-table-column prop="fax" label="传真" width="100px" align="center"></el-table-column>
      <el-table-column prop="postcode" label="邮编" width="80px" align="center"></el-table-column>
      <el-table-column prop="comment" label="备注" width="80px" align="center"></el-table-column>
      <el-table-column fixed="right" label="操作" width="200px"  align="center">
        <template v-slot="scope" #default>
          <!-- 编辑按钮 -->
          <el-button @click="handleClick(scope.row)" type="warning" size="default">编辑&thinsp;
            <el-icon> <edit/></el-icon>
          </el-button>
          <!-- 删除按钮 -->
          <el-button @click="delOne(scope.row.id)" type="danger" size="default">删除&thinsp;
            <el-icon> <DeleteFilled /></el-icon>
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[5, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>
    <el-dialog title="供应商添加" v-model="dialogFormVisible" width="50%">
      <el-form :model="form" size="medium" :rules="rules" ref="form">
        <el-form-item label="供应商名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="地址" :label-width="formLabelWidth" prop="address">
          <el-input v-model="form.address" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系人" :label-width="formLabelWidth" prop="linkman">
          <el-input v-model="form.linkman" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" :label-width="formLabelWidth" prop="phone">
          <el-input v-model="form.phone" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="开户银行" :label-width="formLabelWidth" prop="bank">
          <el-input v-model="form.bank" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="银行账号" :label-width="formLabelWidth" prop="bankAccount">
          <el-input v-model="form.bankAccount" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="传真" :label-width="formLabelWidth" prop="fax">
          <el-input v-model="form.fax" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">
          <el-input v-model="form.postcode" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="法人" :label-width="formLabelWidth" prop="legalPerson">
          <el-input v-model="form.legalPerson" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth" prop="comment">
          <el-input v-model="form.comment" autocomplete="off"></el-input>
        </el-form-item>

      </el-form>

      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>
    <el-dialog title="供应商修改" v-model="dialogModVisible" width="50%">
      <el-form :model="formMod" size="medium" :rules="rules" ref="formMod">
        <el-form-item label="供应商名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="formMod.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="地址" :label-width="formLabelWidth" prop="address">
          <el-input v-model="formMod.address" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系人" :label-width="formLabelWidth" prop="linkman">
          <el-input v-model="formMod.linkman" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" :label-width="formLabelWidth" prop="phone">
          <el-input v-model="formMod.phone" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="开户银行" :label-width="formLabelWidth" prop="bank">
          <el-input v-model="formMod.bank" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="银行账号" :label-width="formLabelWidth" prop="bankAccount">
          <el-input v-model="formMod.bankAccount" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="传真" :label-width="formLabelWidth" prop="fax">
          <el-input v-model="formMod.fax" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮编" :label-width="formLabelWidth" prop="postcode">
          <el-input v-model="formMod.postcode" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="法人" :label-width="formLabelWidth" prop="legalPerson">
          <el-input v-model="formMod.legalPerson" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="备注" :label-width="formLabelWidth" prop="comment">
          <el-input v-model="formMod.comment" autocomplete="off"></el-input>
        </el-form-item>

      </el-form>

      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogModVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {CirclePlus, Delete, Search} from '@element-plus/icons-vue'
import {ElMessageBox, ElMessage } from 'element-plus'
import { ref } from 'vue'
let ipaddress = "/distributionManagement";
let requestData = { // Declare requestData as a global variable
  "id": "",
  "name": "",
  "address": "",
  "linkman": "",
  "phone": "",
  "bank": "",
  "bankAccount": "",
  "legalPerson": "",
  "fax": "",
  "postcode": "",
  "comment": ""
};
export default {
  name: "provider-man",
  components:{
    Delete,
    CirclePlus,
    Search,
  },//store components used
  data() {
    return {
      tags:[],
      options: ["姓名","地址","联系人","电话","开户银行","银行账户","法人","传真","邮编"],
      Search,
      locale:zhCn,//中文
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 8, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        name: [{ required: true, message: '请输入供应商名称', trigger: 'blur' }],
        address:[{required: true, message: '请输入地址', trigger: 'blur'}],
        linkman:[{required: true, message: '请输入联系人', trigger: 'blur'}],
        phone:[{required: true, message: '请输入联系电话', trigger: 'blur'}],
        bank:[{required: true, message: '请输入开户银行', trigger: 'blur'}],
        bankAccount:[{required: true, message: '请输入银行账号', trigger: 'blur'}],
        legalPerson:[{required: true, message: '请输入法人', trigger: 'blur'}],
        fax:[{required: true, message: '请输入传真', trigger: 'blur'}],
        postcode:[{required: true, message: '请输入邮编', trigger: 'blur'}],
      }
    }
  },//store global variables
  methods:{
    removeTag(tag) {
      const index = this.tags.indexOf(tag);

      if (index !== -1) {
        this.tags.splice(index, 1);

        if (tag.type === 'name') {
          //console.log("hello")
          requestData.name = '';
        } else if (tag.type === 'address') {
          requestData.address = '';
        } else if (tag.type === 'linkman') {
          requestData.linkman = '';
        } else if (tag.type === 'phone') {
          requestData.phone = '';
        } else if (tag.type === 'bank') {
          requestData.bank = '';
        } else if (tag.type === 'bankAccount') {
          requestData.bankAccount = '';
        } else if (tag.type === 'legalPerson') {
          requestData.legalPerson = '';
        } else if (tag.type === 'fax') {
          requestData.fax = '';
        } else if (tag.type === 'postcode') {
          requestData.postcode = '';
        }

        this.$http.post(ipaddress+
            `/supplier/getSupplierByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
        ).then(res=>{
          if(res.code == '666'){
            console.log(res)
            this.total = res.data.total //need
            console.log(res.data.list)
            this.tableData = res.data.list
            console.log(this.tableData)
          }
        }).catch(()=>{
          ElMessage.error('数据加载失败,请刷新！')
        })
      }
    },
    getOptions() {
      // 发起请求或从其他地方获取选项数据
      // 将获取到的数据赋值给options数组
      this.options = [
        { value: 'name', label: '姓名' },
        { value: 'address', label: '地址' },
        { value: 'linkman', label: '联系人' },
        { value: 'phone', label: '电话' },
        { value: 'bank', label: '开户银行' },
        { value: 'bankAccount', label: '银行账户' },
        { value: 'legalPerson', label: '法人' },
        { value: 'fax', label: '传真' },
        { value: 'postcode', label: '邮编'}

      ];
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/supplier/deleteSupplier",{"id":v}).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '删除成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    delOne(id){ //删除
      console.log(id)
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/supplier/deleteSupplier",{"id":id}).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    handleClick(row){ //编辑
      this.formMod = JSON.parse(JSON.stringify(row));
      this.dialogModVisible=true
    },
    saveData(resetForm){ //用于数据的添加和更新
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      if(dialogFormVisible){
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            this.$http.post(ipaddress+"/supplier/addSupplier",this.form).then(res=>{
              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        this.$http.post(ipaddress+"/supplier/updateSupplierById",this.formMod).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }

    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      this.form = {}
    },
    network(){ //分页查询

      if(this.searchName!="")
        this.tags.push({ name: this.searchName, type: this.searchType });


      if (this.searchType === 'name') {
        requestData.name = this.searchName;
      } else if (this.searchType === 'address') {
        requestData.address = this.searchName;
      }else if (this.searchType === 'linkman') {
        requestData.linkman = this.searchName;
      }else if (this.searchType === 'phone') {
        requestData.phone = this.searchName;
      }else if (this.searchType === 'bank') {
        requestData.bank = this.searchName;
      }else if (this.searchType === 'bankAccount') {
        requestData.bankAccount = this.searchName;
      }else if (this.searchType === 'legalPerson') {
        requestData.legalPerson = this.searchName;
      }else if (this.searchType === 'fax') {
        requestData.fax = this.searchName;
      }else if (this.searchType === 'postcode') {
        requestData.postcode = this.searchName;
      }

      this.$http.post(ipaddress+
          `/supplier/getSupplierByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
      ).then(res=>{
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.total //need
          console.log(res.data.list)
          this.tableData = res.data.list
          console.log(this.tableData)
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },//methods to pass and process data
  created() {
    this.getOptions();
    this.network()
  }//serves as the mounted function
}
</script>

<style >
.classOneItemShow{
  margin-left: 0px;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}

</style>

