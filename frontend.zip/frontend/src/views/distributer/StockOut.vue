<script>

import {ElMessage, ElMessageBox} from "element-plus";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

let ipaddress = "/warehouseManagement"

let requestData = {
  "outId":"0",
  "inId":"1",
  "status":"初始状态",
  "type":"入库调拨单",
  "productId":"",
  "productNum":"",
  "actualNum":"",
  "unit":"",
  "planOutDate":"",
  "orderId":""
}

export default {
  name: 'stock-out',

  data(){
    return {
      status: '初始状态',
      type: '购货入库',
      planOutDate: '',
      actualNum: 0,
      locale: zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      isFound: false,
      notFound: false,
      dialogFormVisible: false,
      formLabelWidth: '100px',
      multipleSelection: [],
      dispatchingOrder:{},
      form: {}
    }
  },

  methods: {
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleNext() {
      let ids = this.multipleSelection.map(v=>{
        this.dispatchingOrder.outId = 0
        this.dispatchingOrder.inId = 1
        this.dispatchingOrder.status = "初始状态"
        this.dispatchingOrder.type = "入库调拨单"
        this.dispatchingOrder.productId = v.productId
        this.dispatchingOrder.productNum = v.productNum
        this.dispatchingOrder.actualNum = 0
        this.dispatchingOrder.unit = v.unit
        this.dispatchingOrder.planOutDate = v.date
        this.dispatchingOrder.orderId = v.orderId
        this.dispatchingOrder.taskId = 0
      })
      ElMessageBox.confirm(
          '是否补货选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          this.$http.post('/dispatchManagement'+"/dispatchingOrder/addDispatchingOrder",this.dispatchingOrder).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('失败！')
          })
        })
      })
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    network(){
      // console.log(ipaddress)
      this.$http.post(ipaddress+`/storeManagement/getLackItemByOrder?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,requestData).then(res=>{
        console.log(res);
        if(res.code === '666'){
          this.tableData = res.data.list;
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}

        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
    }
  },
  created() {
    console.log('created')
    this.network()
  }
}
</script>

<template>
缺货进货
  <div class="stockOut">
    <el-table :data="tableData" border style="width:fit-content;" @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="80px" align="center"></el-table-column>
      <el-table-column fixed type="index" label="序号" width="50" align="center"></el-table-column>
<!--      每个字段属性为:productId,productNum,productName,unit,firstProductName,secondProductName,date-->
      <el-table-column prop="productId" label="商品编号" width="100" align="center"></el-table-column>
      <el-table-column prop="productNum" label="商品数量" width="100" align="center"></el-table-column>
      <el-table-column prop="productName" label="商品名称" width="100" align="center"></el-table-column>
      <el-table-column prop="unit" label="单位" width="100" align="center"></el-table-column>
      <el-table-column prop="firstProductName" label="一级分类" width="100" align="center"></el-table-column>
      <el-table-column prop="secondProductName" label="二级分类" width="100" align="center"></el-table-column>
      <el-table-column prop="orderId" label="订单代码" width="100" align="center"></el-table-column>
      <el-table-column prop="date" label="日期" width="100" align="center"></el-table-column>
    </el-table>
    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[5, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>
<!--    在页面中央放一个补货按钮-->
    <br/>
    <div style="text-align:center;margin-top:18px;">
      <el-button type="primary" @click="handleNext()">补货</el-button>
    </div>
  </div>
</template>

<style scoped>

</style>
