<template>
  <div class="itemShow">

    <div style="padding: 0px 0">
      <el-input style="width: 250px" placeholder="商品名称" :suffix-icon="Search" v-model="projectName"></el-input> <br><br>

      <el-select
          placeholder="请选择库房"
          v-model="warehouseState"
      >
        <el-option
            v-for="warehouseState in warehouseList"
            :key="warehouseState"
            :value="warehouseState"
            :label="warehouseState">
        </el-option>
      </el-select>
      &emsp;

      <el-date-picker
          v-model="planOutDate"
          type="datetime"
          placeholder="选择日期"
          format="YYYY-MM-DD HH:mm:ss"
          autocomplete="off"
      /> &emsp;
      &emsp;
      <el-select
          placeholder="请选择调拨单类型"
          v-model="type"
      >
        <el-option
            v-for="type in typeList"
            :key="type"
            :value="type"
            :label="type">
        </el-option>
      </el-select>


      &emsp;

      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertl-align: middle;"> 筛选结果 </span>
      </el-button>
    </div>




    <el-table :data="tableData" border style="width: 100%" >
      <el-table-column fixed type="selection" width="50px" align="center"></el-table-column>
      <el-table-column prop="id" label="出入库单id" width="70px" align="center"></el-table-column>
      <el-table-column prop="status" label="状态" width="70px" align="center"></el-table-column>
      <el-table-column prop="type" label="出入库类型" width="70px" align="center"></el-table-column>
      <el-table-column prop="outId" label="出库库房代码" width="70px" align="center"></el-table-column>
      <el-table-column prop="inId" label="入库库房代码" width="70px" align="center"></el-table-column>
      <el-table-column prop="productId" label="商品名代码" width="70px" align="center"></el-table-column>
      <el-table-column prop="productNum" label="商品数量" width="70px" align="center"></el-table-column>
      <el-table-column prop="unit" label="单位" width="120px" align="center"></el-table-column>
      <el-table-column prop="planOutDate" label="日期" width="100px" align="center"></el-table-column>
      <el-table-column prop="orderId" label="订单代码" width="70px" align="center"></el-table-column>
      <el-table-column prop="taskId" label="任务单代码" width="70px" align="center"></el-table-column>
    </el-table>

    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[8, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>




  </div>
</template>

<script >
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {CirclePlus, DeleteFilled, Edit, Search} from '@element-plus/icons-vue'
import {ElMessageBox, ElMessage } from 'element-plus'
import { shallowRef } from 'vue'

let ipaddress = "/distributionManagement";


let requestData = { // Declare requestData as a global variable
  "status": "",
  "type": "",
  "planOutDate": "",
}

export default {
  name: "in-out-query",
  components:{
    Edit,
    DeleteFilled,
    CirclePlus,
    Search,
  },
  data() {
    return {
      tags:[],
      planOutDate:"",
      options: ["一级商品分类","二级商品分类","商品名称"],
      Search,
      locale:zhCn,
      tableData: [],
      type:"",
      typeList:["购货入库","调拨出库","调拨入库","领货出库","退货分站","退货出库","退货入库","中心出库"],
      projectName: "",
      firstGroupName: "",
      secondGroupName: "",

      warehouseList: ["中心库房","福建分库房","浙江分库房"],


      warehouseState:"",

      // returnData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 8, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        // warehouseId:[{required: true, message: '请输入', trigger: 'blur'}],
        productName:[{required: true, message: '请输入商品名称', trigger: 'blur'}]
      }
    }
  },

  methods:{
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    getAllWarehouseList(){
      this.$http.get(ipaddress+`/store/getAllStore`).then(whl_3=>{
        this.warehousetList = []
        console.log("--------warehouseList--------")
        console.log(whl_3)
        whl_3.data.forEach((obj) => {
          // 将当前JSON对象添加到新数组中
          this.warehousetList.push(obj);
          //console.log(obj)
        });

        console.log(this.warehousetList)
        console.log("--------warehouseList--------")
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    network(){ //分页查询
      requestData.type = this.type;
      requestData.planOutDate = this.filterTime(this.planOutDate);
      console.log("requestData",requestData);
      // console.log(ipaddress)
      this.$http.post(ipaddress+`/dispatchingOrder/getDispatchingOrderByQuery?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,requestData).then(res=>{
        console.log(res);
        if(res.code === '666'){
          this.tableData = res.data.list;
          this.total = res.data.total;
          if(this.total > 0) {this.isFound = true;this.notFound = false}
          if(this.total === 0) {this.notFound = true;this.isFound = false}

        }
      }).catch(()=>{
        ElMessage.error('数据加载失败，请刷新!')
      })
      console.log(tableData)
    //   requestData.status = this.status;
    //   requestData.type = this.type;
    //   requestData.planOutDate = this.filterTime(this.planOutDate);
    //
    //   console.log("-----search-----")
    //   console.log(requestData)
    //   console.log("-----search-----")
    //
    //
    //
    //   this.$http.post(
    //       `http://10.25.38.170:8095/dispatchingOrder/getDispatchingOrderByQuery?PageSize=${this.pageSize}&pageNum=${this.pageNum}`,requestData
    //   ).then(res=>{
    //     console.log(res)
    //     if(res.code == '666'){
    //       console.log(res)
    //       this.total = res.data.totalItems
    //       this.tableData = []
    //       res.data.list.forEach(item =>{
    //         // this.$http.post(ipaddress+
    //         //     `/product/getProductById?id=${item.id}`
    //         // ).then(res0=>{
    //         //   this.productName=res0.data.product.name
    //         //   this.firstGroupName=res0.data.firstProduct.name
    //         //   this.secondGroupName=res0.data.secondProduct.name
    //         // })
    //         let obj = {}
    //         obj.id = item.id
    //         obj.productName = this.productName
    //         obj.secondGroupName = this.firstGroupName
    //         obj.secondGroupName = this.secondGroupName
    //         obj.status = item.status
    //         obj.type = item.type
    //         obj.unit = item.unit
    //         obj.planOutDate = item.planOutDate
    //
    //         this.tableData.push(obj)
    //       })
    //       console.log("_____")
    //       console.log(this.tableData)
    //       console.log("_____")
    //     }
    //   }).catch(()=>{
    //     ElMessage.error('数据加载失败,请刷新！')
    //   })
    //
    //   this.searchName=""
     },
  },
  created() {
  }
}
</script>

<style >
.itemShow{
  margin-left: 0px;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}

</style>

