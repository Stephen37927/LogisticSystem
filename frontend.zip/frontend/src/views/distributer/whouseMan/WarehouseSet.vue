<script>
import {CirclePlus, Delete, DeleteFilled, Edit, Search} from "@element-plus/icons-vue";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage, ElMessageBox} from "element-plus";

let ipaddress = "/distributionManagement";

let requestData = {
  "name":"",
  "storeAddress":"",
  "manager":"",
  "stage":""
};

export default {
  name:"warehouse-set",
  components:{
    CirclePlus,
    Delete,
    DeleteFilled,
    Edit,
    Search
  },
  data(){
    return {
      tags:[],
      options: ["名称","地址","级别"],
      Search,
      locale:zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        name: [{ required: true, message: '请输入库房名称', trigger: 'blur' }],
        storeAddress:[{required: true, message: '请输入库房地址', trigger: 'blur'}],
        manager: [{ required: true, message: '请输入库管人', trigger: 'blur' }],
        stage: [{ required: true, message: '请输入库房级别', trigger: 'blur' }]
      }
    }
  },
  methods:{
    removeTag(tag) {
      const index = this.tags.indexOf(tag);

      if (index !== -1) {
        this.tags.splice(index, 1);

        if (tag.type === 'name') {
          requestData.name = '';
        } else if (tag.type === 'storeAddress') {
          requestData.storeAddress = '';
        } else if (tag.type === 'stage') {
          requestData.stage = '';
        }

        this.$http.post(ipaddress+
            `/store/getStoreByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
        ).then(res=>{
          if(res.code == '666'){
            console.log(res)
            this.total = res.data.total //need
            console.log(res.data.list)
            this.tableData = res.data.list
            console.log(this.tableData)
          }
        }).catch(()=>{
          ElMessage.error('数据加载失败,请刷新！')
        })
      }
    },
    getOptions() {
      // 发起请求或从其他地方获取选项数据
      // 将获取到的数据赋值给options数组
      this.options = [
        { value: 'name', label: '名称' },
        { value: 'storeAddress', label: '地址' },
        { value: 'stage', label: '级别' }
      ];
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        let flag = true
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/store/deleteStore",{"id":v}).then(res=>{
            if(res.code === '666'){
              console.log(res)
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
        if(flag){
          ElMessage.success('批量删除成功！')
          this.network()
        }
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    delOne(id){ //删除
      console.log(id)
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/store/deleteStore",{"id":id}).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    saveData(resetForm){ //用于数据的添加和更新
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      if(dialogFormVisible){
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            console.log(this.form)
            this.$http.post(ipaddress+"/store/addStore",this.form).then(res=>{
              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        this.$http.post(ipaddress+"/store/updateStoreById",this.formMod).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }

    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleClick(row){ //编辑
      this.formMod = JSON.parse(JSON.stringify(row));
      this.dialogModVisible=true
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      this.form = {}
    },
    network(){ //分页查询

      if(this.searchName!=="")
        this.tags.push({ name: this.searchName, type: this.searchType });


      if (this.searchType === 'name') {
        requestData.name = this.searchName;
      } else if (this.searchType === 'storeAddress') {
        requestData.storeAddress = this.searchName;
      } else if (this.searchType === 'stage') {
        requestData.stage = this.searchName;
      } else {
        requestData.name = '';
        requestData.storeAddress = '';
        requestData.stage = '';
      }

      this.$http.post(ipaddress+
          `/store/getStoreByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
      ).then(res=>{
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.total //need
          console.log(res.data.list)
          this.tableData = res.data.list
          console.log(this.tableData)
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },
  created(){
    this.getOptions();
    this.network();
  }
}
</script>

<template>
库房设置
  <div class="warehouseShow">
    <div style="padding: 0px 0">
      <el-input style="width: 250px" placeholder="请输入要搜索的内容" v-model="searchName"></el-input>

      <el-select v-model="searchType" placeholder="请选择搜索类型">
        <el-option v-for="option in options" :key="option.value" :value="option.value" :label="option.label"></el-option>
      </el-select>

      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertical-align: middle;"> 添加筛选 </span>
      </el-button>
    </div>

    <div>
      <el-tag v-for="tag in tags" :key="tag" closable @close="removeTag(tag)">
        {{ tag }}
      </el-tag>
    </div>

    <div style="padding: 10px 0">
      <el-button type="primary" @click="addItem">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
      <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
    </div>

    <el-table
      :data="tableData"
      style="width: 100%"
      :row-key="row => row.id"
      :header-cell-style="{'background-color':'#f5f7fa','color':'#909399'}"
      :cell-style="{'color':'#606266'}"
      stripe
      border
      highlight-current-row
      @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="55" align="center"></el-table-column>
      <el-table-column fixed prop="id" label="id" width="55" align="center" sortable></el-table-column>
      <el-table-column prop="name" label="库房名称" width="150" align="center"></el-table-column>
      <el-table-column prop="storeAddress" label="库房地址" width="150" align="center"></el-table-column>
      <el-table-column prop="manager" label="库管人" width="150" align="center"></el-table-column>
      <el-table-column prop="stage" label="库房级别" width="150" align="center"></el-table-column>
      <el-table-column fixed="right" label="操作" width="300px"  align="center">
        <template v-slot="scope" #default>
          <!-- 编辑按钮 -->
          <el-button @click="handleClick(scope.row)" type="warning" size="default">编辑&thinsp;
            <el-icon> <edit/></el-icon>
          </el-button>
          <!-- 删除按钮 -->
          <el-button @click="delOne(scope.row.id)" type="danger" size="default">删除&thinsp;
            <el-icon> <DeleteFilled /></el-icon>
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[5, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>

    <el-dialog title="库房添加" v-model="dialogFormVisible" width="50%">
      <el-form :model="form" size="default" :rules="rules" ref="form">
        <el-form-item label="库房名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库房地址" :label-width="formLabelWidth" prop="storeAddress">
          <el-input v-model="form.storeAddress" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库管人" :label-width="formLabelWidth" prop="manager">
          <el-input v-model="form.manager" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库房级别" :label-width="formLabelWidth" prop="stage">
          <el-select v-model="form.stage" placeholder="请选择">
            <el-option label="中心库房" value="中心库房"></el-option>
            <el-option label="分站库房" value="分站库房"></el-option>
          </el-select>
        </el-form-item>
      </el-form>

      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>

    <el-dialog title="库房信息修改" v-model="dialogModVisible" width="50%">
      <el-form :model="formMod" size="medium" :rules="rules" ref="formMod">
        <el-form-item label="库房名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="formMod.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库房地址" :label-width="formLabelWidth" prop="storeAddress">
          <el-input v-model="formMod.storeAddress" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库管人" :label-width="formLabelWidth" prop="manager">
          <el-input v-model="formMod.manager" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="库房级别" :label-width="formLabelWidth" prop="stage">
          <el-select v-model="formMod.stage" placeholder="请选择">
            <el-option label="中心库房" value="中心库房"></el-option>
            <el-option label="分站库房" value="分站库房"></el-option>
          </el-select>
        </el-form-item>
      </el-form>

      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogModVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>


  </div>
</template>

<style scoped>

</style>
