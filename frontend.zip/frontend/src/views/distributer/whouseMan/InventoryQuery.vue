
<template>
  <div class="itemShow">

    <div style="padding: 0px 0">
      <el-input style="width: 250px" placeholder="商品名称" :suffix-icon="Search" v-model="searchName"></el-input> <br><br>

      <el-select
          placeholder="请选择一级分类"
          v-model="firstGroupState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
        <el-option key="" label="全部" value="全部"></el-option>
        <el-option v-for="option in firstProductList"

                   :key="option.id"
                   :value="option.id"
                   :label="option.name">
        </el-option>

      </el-select>&emsp;

      <el-select
          placeholder="请选择二级分类"
          v-model="secondGroupState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
        <!--        添加一个“全部”选项且值为空-->
        <el-option
            key=""
            label="全部"
            value="全部"></el-option>
        <el-option
            v-for="option in secondProductList"
            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>&emsp;

      <el-select
          placeholder="请选择库房"
          v-model="warehouseState1"

      >
        <el-option
            v-for="option in warehouseList1"
            :key=option
            :value=option
            :label=option>
        </el-option>
      </el-select>

      &emsp;

      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertl-align: middle;"> 筛选结果 </span>
      </el-button>
    </div>

    <div style="padding: 10px 0">
      <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
    </div>


    <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="50px" align="center"></el-table-column>
      <el-table-column prop="id" label="商品id" width="70px" align="center"></el-table-column>
      <el-table-column prop="name" label="商品名称" width="150px" align="center"></el-table-column>
      <el-table-column prop="totalNum" label="总库存" width="120px" align="center"></el-table-column>
      <el-table-column prop="backNum" label="退回数量" width="120px" align="center"></el-table-column>
      <el-table-column prop="unallocatedNum" label="可分配量" width="120px" align="center"></el-table-column>
      <el-table-column prop="allocatedNum" label="已分配量" width="120px" align="center"></el-table-column>
      <el-table-column prop="warningNum" label="预警值" width="100px" align="center"></el-table-column>
      <el-table-column prop="maxNum" label="最大库存量" width="120px" align="center"></el-table-column>
      <el-table-column prop="bufferNum" label="缓冲值" width="100px" align="center"></el-table-column>
      <el-table-column prop="defectiveNum" label="残缺值" width="120px" align="center"></el-table-column>
    </el-table>

    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[8, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>




  </div>
</template>

<script >
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {CirclePlus, DeleteFilled, Edit, Search} from '@element-plus/icons-vue'
import {ElMessageBox, ElMessage } from 'element-plus'
import { shallowRef } from 'vue'

let ipaddress = "/distributionManagement";

let requestData = { // Declare requestData as a global variable
    product: {
      id: '',
      name: "",
      description: "",
      firstProductId: '',
      secondProductId: '',
      unit: "",
      sellingPrice: '',
      discount: '',
      costPrice: '',
      supplierId: '',
      shelfLife: '',
      canReturn: '',
      canExchange: ''
    }
}

export default {
  name: "man-item",
  components:{
    Edit: shallowRef(Edit),
    DeleteFilled: shallowRef(DeleteFilled),
    CirclePlus: shallowRef(CirclePlus),
    Search: shallowRef(Search)
    // Edit,
    // DeleteFilled,
    // CirclePlus,
    // Search,
  },
  data() {
    return {
      tags:[],
      options: ["一级商品分类","二级商品分类","商品名称"],
      Search,
      locale:zhCn,
      tableData: [],

      firstProductList: [],
      secondProductList: [],
      warehouseList1: ["中心库房","福建分站","浙江分站"],

      warehouseState1:"",

      firstGroupState:"",
      secondGroupState:"",

      // returnData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 8, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        firstProductId: [{ required: true, message: '请输入一级商品分类', trigger: 'blur' }],
        secondProductId:[{required: true, message: '请输入二级商品分类', trigger: 'blur'}],
        warehouseId:[{required: true, message: '请输入', trigger: 'blur'}],
        productName:[{required: true, message: '请输入商品名称', trigger: 'blur'}]
      }
    }
  },

  methods:{
    getAllFirstProduct(){
      this.$http.get(ipaddress+`/firstproduct/getAllFirstProduct`).then(fpl_1=>{
        this.firstProductList = fpl_1.data
        console.log("--------firstProductList--------")
        console.log(this.firstProductList)
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    getAllSecondProduct(){
      this.$http.get(ipaddress+`/secondproduct/getAllSecondProduct`).then(fpl_2=>{
        this.secondProductList = fpl_2.data
        console.log("--------secondProductList--------")
        console.log(this.secondProductList)
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    getAllWarehouseList(){
      this.$http.get(ipaddress+`/store/getAllStore`).then(whl_3=>{
        this.warehousetList = []
        console.log("--------warehouseList--------")
        console.log(whl_3)
        whl_3.data.forEach((obj) => {
          // 将当前JSON对象添加到新数组中
          this.warehousetList.push(obj);
          //console.log(obj)
        });

        console.log(this.warehousetList)
        console.log("--------warehouseList--------")
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/product/deleteProduct",{"id":v}).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '删除成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    delOne(id){ //删除
      console.log("----------")
      console.log(id)
      console.log("----------")
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/product/deleteProduct",{"id":id}).then(res=>{
          //console.log(productId)
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    handleClick(row){ //编辑
      this.formMod = JSON.parse(JSON.stringify(row));
      this.dialogModVisible=true
    },
    saveData(resetForm){ //用于数据的添加和更新
      console.log("hello i'm saveData")
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      if(dialogFormVisible){
        console.log("----------adding------------")
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            this.$http.post(ipaddress+"/product/addProduct",this.form).then(res=>{
              console.log("_____formMod_____")
              console.log(this.form)
              console.log("_____formMod_____")

              console.log("_____res_____")
              console.log(res)
              console.log("_____res_____")

              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        console.log("----------editing------------")

        this.$http.post(ipaddress+"/product/updateProductById",this.formMod).then(res=>{

          console.log("_____formMod_____")
          console.log(this.formMod)
          console.log("_____formMod_____")

          console.log("_____res_____")
          console.log(res)
          console.log("_____res_____")

          if(res.code === '666'){
            console.log("____success____")
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }
    },

    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      this.form = {}
    },
    network(){ //分页查询


      console.log("-----search-----")
      console.log(this.searchType,this.searchName)
      console.log("-----search-----")

      if(this.searchName!="")
        requestData.product.name = this.searchName
      else
        requestData.product.name = ""

      if(this.firstGroupState !== "全部"){
        requestData.product.firstProductId = this.firstGroupState
      }else{
        requestData.product.firstProductId = ""
      }

      if(this.secondGroupState !== "全部"){
        requestData.product.secondProductId = this.secondGroupState
      }else{
        requestData.product.secondProductId = ""
      }

      this.$http.post(ipaddress+
          `/store/getItemListByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}&storeId=1`,requestData.product
      ).then(res=>{
        console.log(res)
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.totalItems
          this.tableData = []
          res.data.list.forEach(item =>{
            let obj = {}
            obj.id = item.product.product.id
            obj.name = item.product.product.name
            obj.backNum = item.storeItem.backNum //退回数量
            obj.unallocatedNum = item.storeItem.unallocatedNum //可分配量
            obj.warningNum = item.storeItem.warningNum //预警值
            obj.allocatedNum = item.storeItem.allocatedNum //已分配量
            obj.bufferNum = item.storeItem.bufferNum  //缓冲值
            obj.defectiveNum = item.storeItem.defectiveNum //残缺值
            obj.maxNum = item.storeItem.maxNum //最大库存量
            obj.totalNum = obj.backNum + obj.unallocatedNum + obj.allocatedNum


            this.tableData.push(obj)
          })
          console.log("_____")
          console.log(this.tableData)
          console.log("_____")
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },
  created() {
    this.getAllFirstProduct()
    this.getAllSecondProduct()
    this.getAllWarehouseList()
    this.network()
  }
}
</script>

<style >
.itemShow{
  margin-left: 0px;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}

</style>


