
<template>
  <div class="itemShow">

    <div style="padding: 0px 0">
      <el-input style="width: 250px" placeholder="商品名称" :suffix-icon="Search" v-model="searchName"></el-input> <br><br>

      <el-select
          placeholder="请选择一级分类"
          v-model="firstGroupState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
        <el-option key="" label="全部" value="全部"></el-option>
        <el-option v-for="option in firstProductList"

            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>

      <el-select
          placeholder="请选择二级分类"
          v-model="secondGroupState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
        <!--        添加一个“全部”选项且值为空-->
        <el-option
            key=""
            label="全部"
            value="全部"></el-option>
        <el-option
            v-for="option in secondProductList"
            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>



      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertical-align: middle;"> 添加筛选 </span>
      </el-button>
    </div>

    <div>
      <el-tag v-for="tag in tags" :key="tag" closable @close="removeTag(tag)">
        {{ tag }}
      </el-tag>
    </div>


    <div style="padding: 10px 0">
      <el-button type="primary" @click="addItem">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
      <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
    </div>


    <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="50px" align="center"></el-table-column>
      <el-table-column prop="id" label="商品id" width="100px" align="center"></el-table-column>
      <el-table-column prop="name" label="商品名称" width="100px" align="center"></el-table-column>
      <el-table-column prop="description" label="描述" width="120px" align="center"></el-table-column>
      <el-table-column prop="firstGroup" label="一级分类" width="80px" align="center"></el-table-column>
      <el-table-column prop="secondGroup" label="二级分类" width="80px" align="center"></el-table-column>
      <el-table-column prop="unit" label="单位" width="80px" align="center"></el-table-column>
      <el-table-column prop="sellingPrice" label="售价" width="50px" align="center"></el-table-column>
      <el-table-column prop="discount" label="折扣" width="50px" align="center"></el-table-column>
      <el-table-column prop="costPrice" label="成本" width="50px" align="center"></el-table-column>
      <el-table-column prop="shelfLife" label="保质期" width="90px" align="center"></el-table-column>
      <el-table-column prop="canReturn" label="可退" width="70px" align="center"></el-table-column>
      <el-table-column prop="canExchange" label="可换" width="70px" align="center"></el-table-column>
      <el-table-column fixed="right" label="操作" width="300px"  align="center">
        <template v-slot="scope" #default>
          <!-- 编辑按钮 -->
          <el-button @click="handleClick(scope.row)" type="warning">编辑&thinsp;
            <el-icon> <edit/></el-icon>
          </el-button>
          <!-- 删除按钮 -->
          <el-button @click="delOne(scope.row.id)" type="danger">删除&thinsp;
            <el-icon> <DeleteFilled /></el-icon>
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[8, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>

    <el-dialog title="商品添加" v-model="dialogFormVisible" width="50%">
      <el-form :model="form" :rules="rules" ref="form">
<!--        <el-form-item label="商品id" :label-width="formLabelWidth" prop="id">-->
<!--           无需填写-->
<!--        </el-form-item>-->
        <el-form-item label="商品名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="form.name" autocomplete="off" placeholder="请输入商品名称"></el-input>
        </el-form-item>
        <el-form-item label="商品描述" :label-width="formLabelWidth" prop="description">
          <el-input v-model="form.description" autocomplete="off" placeholder="请输入商品描述"></el-input>
        </el-form-item>
        <el-form-item label="一级分类" :label-width="formLabelWidth" prop="firstProductId">
          <el-select v-model="form.firstProductId" placeholder="请选择一级分类名称"
                     filterable
                     allow-create
                     default-first-option>
            <el-option v-for="item in firstProductList"
                       :key="item.id"
                       :value="item.id"
                       :label="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="二级分类" :label-width="formLabelWidth" prop="secondProductId">
          <el-select v-model="form.secondProductId" placeholder="请选择二级分类名称"
                     filterable
                     allow-create
                     default-first-option>
            <el-option v-for="item in secondProductList"
                       :key="item.id"
                       :value="item.id"
                       :label="item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="商品单位" :label-width="formLabelWidth" prop="unit">
          <el-input v-model="form.unit" autocomplete="off" placeholder="请输入商品单位"></el-input>
        </el-form-item>
        <el-form-item label="商品售价" :label-width="formLabelWidth" prop="sellingPrice">
          <el-input v-model="form.sellingPrice" autocomplete="off" placeholder="请输入原价"></el-input>
        </el-form-item>
        <el-form-item label="商品折扣" :label-width="formLabelWidth" prop="discount">
          <el-input v-model="form.discount" autocomplete="off" placeholder="请输入折扣，范围从0～10"></el-input>
        </el-form-item>
        <el-form-item label="商品成本" :label-width="formLabelWidth" prop="costPrice">
          <el-input v-model="form.costPrice" autocomplete="off" placeholder="请输入商品成本"></el-input>
        </el-form-item>
        <el-form-item label="保质期" :label-width="formLabelWidth" prop="shelfLife">
          <el-input v-model="form.shelfLife" autocomplete="off" placeholder="输入一个整数，代表几个月"></el-input>
        </el-form-item>
        <el-form-item label="是否可退" :label-width="formLabelWidth" prop="canReturn">
          <el-input v-model="form.canReturn" autocomplete="off" placeholder="输入true或者false"></el-input>
        </el-form-item>
        <el-form-item label="是否可换" :label-width="formLabelWidth" prop="canExchange">
          <el-input v-model="form.canExchange" autocomplete="off" placeholder="输入true或者false"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>

    <el-dialog title="商品修改" v-model="dialogModVisible" width="50%">
      <el-form :model="formMod"  :rules="rules" shallowRef="formMod">
        <el-form-item label="商品id" :label-width="formLabelWidth" prop="id">
          {{ formMod.id }}
        </el-form-item>
        <el-form-item label="商品名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="formMod.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="商品描述" :label-width="formLabelWidth" prop="description">
          <el-input v-model="formMod.description" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="一级分类" :label-width="formLabelWidth" prop="firstProductId">
          <el-select v-model="formMod.firstProductId" placeholder="请选择一级分类名称"
                     filterable
                     allow-create
                     default-first-option>
            <el-option v-for="item in firstProductList"
                       :key="item.id"
                       :value="item.id"
                       :label="item.name">
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="二级分类" :label-width="formLabelWidth" prop="secondProductId">
          <el-select v-model="formMod.secondProductId" placeholder="请选择二级分类名称"
                     filterable
                     allow-create
                     default-first-option>
            <el-option v-for="item in secondProductList"
                       :key="item.id"
                       :value="item.id"
                       :label="item.name">
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="商品单位" :label-width="formLabelWidth" prop="unit">
          <el-input v-model="formMod.unit" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="商品售价" :label-width="formLabelWidth" prop="sellingPrice">
          <el-input v-model="formMod.sellingPrice" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="商品折扣" :label-width="formLabelWidth" prop="discount">
          <el-input v-model="formMod.discount" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="商品成本" :label-width="formLabelWidth" prop="costPrice">
          <el-input v-model="formMod.costPrice" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="保质期" :label-width="formLabelWidth" prop="shelfLife">
          <el-input v-model="formMod.shelfLife" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="是否可退" :label-width="formLabelWidth" prop="canReturn">
          <el-input v-model="formMod.canReturn" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="是否可换" :label-width="formLabelWidth" prop="canExchange">
          <el-input v-model="formMod.canExchange" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogModVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('formMod')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>

  </div>
</template>

<script>
import zhCn from 'element-plus/lib/locale/lang/zh-cn'
import {CirclePlus, DeleteFilled, Edit, Search} from '@element-plus/icons-vue'
import {ElMessageBox, ElMessage } from 'element-plus'
import { shallowRef } from 'vue'

let ipaddress = "/distributionManagement";

let requestData = { // Declare requestData as a global variable
  product: {
    id: '',
    name: "",
    description: "",
    firstProductId: '',
    secondProductId: '',
    unit: "",
    sellingPrice: '',
    discount: '',
    costPrice: '',
    supplierId: '',
    shelfLife: '',
    canReturn: "",
    canExchange: ""
  },
  secondProduct: {
    id: '',
    name: "",
    description: "",
    firstProductId: ''
  },
  firstProduct: {
    id: '',
    name: "",
    description: ""
  }
};

export default {
  name: "man-item",
  components:{
    Edit,
    DeleteFilled,
    CirclePlus,
    Search,
  },
  data() {
    return {
      tags:[],
      options: ["一级商品分类","二级商品分类","商品名称"],
      Search,
      locale:zhCn,
      tableData: [],
      firstProductList: [],
      secondProductList: [],
      firstGroupState:"",
      secondGroupState:"",
      // returnData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 8, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        firstProductId: [{ required: true, message: '请输入一级商品分类', trigger: 'blur' }],
        secondProductId:[{required: true, message: '请输入二级商品分类', trigger: 'blur'}],
        productName:[{required: true, message: '请输入商品名称', trigger: 'blur'}]
      }
    }
  },

  methods:{
    getAllFirstProduct(){
      this.$http.get(ipaddress+`/firstproduct/getAllFirstProduct`).then(fpl_1=>{
        this.firstProductList = fpl_1.data
        console.log("--------firstProductList--------")
        console.log(this.firstProductList)
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    getAllSecondProduct(){
      this.$http.get(ipaddress+`/secondproduct/getAllSecondProduct`).then(fpl_2=>{
        this.secondProductList = fpl_2.data
        console.log("--------secondProductList--------")
        console.log(this.secondProductList)
      }).catch(()=>{
        ElMessage.error('列表加载失败,请刷新！')
      })
    },
    removeTag(tag) {
      const index = this.tags.indexOf(tag);

      if (index !== -1) {
        this.tags.splice(index, 1);

        if (tag.type === 'firstProductName') {
          requestData.firstProduct.name = '';
          requestData.firstProduct.id = '';
        } else if (tag.type === 'secondProductName') {
          requestData.secondProduct.name = '';
          requestData.secondProduct.id = '';
        } else if (tag.type === 'productName') {
          requestData.product.name = '';
        }

        this.$http.post(ipaddress+
            `/product/getProductByQuery?PageSize=${this.pageSize}&pageNum=${this.pageNum}`,requestData
        ).then(res=>{
          if(res.code === '666'){
            console.log(res)
            this.total = res.data.totalItems
            this.tableData = []
            res.data.pageItems.forEach(item =>{
              let obj = {}
              obj.firstGroup = (item.firstProduct == null ? "无":item.firstProduct.name)
              obj.secondGroup = (item.secondProduct == null ? "无":item.secondProduct.name)
              obj.id = item.product.id
              obj.name = item.product.name
              obj.description = item.product.description
              obj.unit = item.product.unit
              obj.sellingPrice = item.product.sellingPrice
              obj.discount = item.product.discount
              obj.costPrice = item.product.costPrice
              obj.shelfLife = item.product.shelfLife
              obj.canReturn = item.product.canReturn
              obj.canExchange = item.product.canExchange
              //supplier: item.product.supplier
              this.tableData.push(obj)
            })
            console.log("_____")
            console.log(this.tableData)
            console.log("_____")
          }
        }).catch(()=>{
          ElMessage.error('数据加载失败,请刷新！')
        })
      }
    },
    getOptions() {
      // 发起请求或从其他地方获取选项数据
      // 将获取到的数据赋值给options数组
      this.options = [
        { value: 'firstGroup', label: '一级商品分类' },
        { value: 'secondGroup', label: '二级商品分类' },
        { value: 'name', label: '商品名称' }
      ];
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/product/deleteProduct",{"id":v}).then(res=>{
            if(res.code === '666'){
              ElMessage({
                message: '删除成功！',
                type: 'success',
              })
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    delOne(id){ //删除
      console.log("----------")
      console.log('id',id)
      console.log("----------")
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/product/deleteProduct",{"id":id}).then(res=>{
          //console.log(productId)
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    handleClick(row){ //编辑
      this.formMod = JSON.parse(JSON.stringify(row));
      this.dialogModVisible=true
    },
    saveData(resetForm){ //用于数据的添加和更新
      console.log("hello i'm saveData")
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      console.log('resetForm',resetForm)
      console.log('this.form',this.form)

      if(dialogFormVisible){
        console.log("----------adding------------")
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            console.log('valid')
            this.$http.post(ipaddress+"/product/addProduct",this.form).then(res=>{
              console.log("_____formMod_____")
              console.log(this.form)
              console.log("_____formMod_____")

              console.log("_____res_____")
              console.log(res)
              console.log("_____res_____")

              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
                this.form = {}
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        console.log("----------editing------------")

        this.$http.post(ipaddress+"/product/updateProductById",this.formMod).then(res=>{

          console.log("_____formMod_____")
          console.log(this.formMod)
          console.log("_____formMod_____")

          console.log("_____res_____")
          console.log(res)
          console.log("_____res_____")

          if(res.code === '666'){
            console.log("____success____")
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }
    },

    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      // this.form = {}
    },
    network(){ //分页查询


      console.log("-----search-----")
      console.log(this.searchType,this.searchName)
      console.log("-----search-----")

      if(this.searchName!="")
        requestData.product.name = this.searchName
      else
        requestData.product.name = ""

      if(this.firstGroupState !== "全部"){
        requestData.product.firstProductId = this.firstGroupState
      }else{
        requestData.product.firstProductId = ""
      }

      if(this.secondGroupState !== "全部"){
        requestData.product.secondProductId = this.secondGroupState
      }else{
        requestData.product.secondProductId = ""
      }


      this.$http.post(ipaddress+
          `/product/getProductByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData.product
      ).then(res=>{
        console.log(res)
        if(res.code == '666'){
          console.log(res)
          this.total = res.data.totalItems
          this.tableData = []
          res.data.pageItems.forEach(item =>{
            let obj = {}
            obj.firstGroup = (item.firstProduct == null ? "无":item.firstProduct.name)
            obj.secondGroup = (item.secondProduct == null ? "无":item.secondProduct.name)
            obj.id = item.product.id
            obj.name = item.product.name
            obj.description = item.product.description
            obj.unit = item.product.unit
            obj.sellingPrice = item.product.sellingPrice
            obj.discount = item.product.discount
            obj.costPrice = item.product.costPrice
            obj.shelfLife = item.product.shelfLife
            obj.canReturn = item.product.canReturn
            obj.canExchange = item.product.canExchange
            //supplier: item.product.supplier
            this.tableData.push(obj)
          })
          console.log("_____")
          console.log(this.tableData)
          console.log("_____")
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

      this.searchType="",this.searchName=""
    },
  },
  created() {
    this.getAllFirstProduct()
    this.getAllSecondProduct()
    this.getOptions();
    this.network()
  }
}
</script>

<style >
.itemShow{
  margin-left: 0px;
}
body {
  margin: 0;
  padding: 0;
  border: 0;
}

</style>

