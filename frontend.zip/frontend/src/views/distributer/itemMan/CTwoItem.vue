<script>

import {CirclePlus, Delete, DeleteFilled, Edit, Search} from "@element-plus/icons-vue";
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage, ElMessageBox} from "element-plus";

let ipaddress = "/distributionManagement";

let requestData = { // Declare requestData as a global variable
  "secondProduct": {
    "id": "",
    "name": "",
    "description": "",
    "firstProductId": ""
  },
  "firstProduct": {
    "id": "",
    "name": "",
    "description": ""
  }
};

export default {
  name: "class-two-item",
  components: {
    DeleteFilled,
    Edit,
    Delete,
    CirclePlus,
    Search
  },
  data(){
    return {
      // tags:[],

      Search,
      locale:zhCn,
      tableData: [],
      total: 0, //数据总条数
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      searchName: "", //搜索名称
      searchType: "", //搜索类型
      coneType: [],
      typeState:"",
      dialogFormVisible: false, //增加的弹窗
      dialogModVisible: false, //修改的弹窗
      form: {}, //弹窗中的数据
      formMod: {}, //修改的数据
      multipleSelection: [], //存储批量删除的数据id
      formLabelWidth: '100px',
      rules: {
        name:[{required: true, message: '请输入二级商品名称', trigger: 'blur'}],
        firstProductId:[{required: true, message: '请选择一级商品名称', trigger: 'blur'}],
        description:[{required: false, message: '请输入商品描述', trigger: 'blur'}]
      }
    }
  },

  methods:{
    getCones(){
      this.$http.get(ipaddress+
          `/firstproduct/getAllFirstProduct`
      ).then(res=>{
        // console.log(res)
        if(res.code === '666'){
          this.coneType.unshift({
            id:"",
            name:"全部",
            description:""
          })
          this.coneType = res.data
        }
      }).catch(()=>{
        ElMessage.error('类型加载失败,请刷新！')
      })
    },
    addItem(){ //添加物品
      this.dialogFormVisible = true
      this.form = {}
    },
    delOne(id){ //删除
      console.log(id)
      ElMessageBox.confirm(
          '是否删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        this.$http.post(ipaddress+"/secondproduct/deleteSecondProductById",{"id":id}).then(res=>{
          if(res.code === '666'){
            ElMessage({
              message: '删除成功！',
              type: 'success',
            })
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('删除失败！')
        })
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    Batchdele(){ //批量删除
      let ids = this.multipleSelection.map(v=>v.id)
      console.log(ids)
      ElMessageBox.confirm(
          '是否批量删除选中数据？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
      ).then(() => {
        let flag = true
        ids.forEach(v=>{
          console.log(v)
          this.$http.post(ipaddress+"/secondproduct/deleteSecondProductById",{"id":v}).then(res=>{
            if(res.code === '666'){
              console.log(res)
              this.network()
            }
          }).catch(()=>{
            ElMessage.error('删除失败！')
          })
        })
        if(flag){
          ElMessage.success('批量删除成功！')
          // this.network()
        }
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '已取消！',
        })
      })
    },
    saveData(resetForm){ //用于数据的添加和更新
      let dialogFormVisible = this.dialogFormVisible;
      let dialogModVisible = this.dialogModVisible;
      // console.log(resetForm)
      if(dialogFormVisible){
        this.$refs[resetForm].validate((valid)=>{
          if(valid){
            console.log(this.form)
            this.$http.post(ipaddress+"/secondproduct/addSecondProduct",this.form).then(res=>{
              if(res.code === '666'){
                ElMessage({
                  message: '成功！',
                  type: 'success',
                })
                this.dialogFormVisible=false
                this.network()
              }
            }).catch(()=>{
              ElMessage.error('失败！')
            })
          }else{
            ElMessage({
              message: '已取消！',
              type: 'warning',
            })
            return false;
          }
        })
      }
      if(dialogModVisible){
        this.$http.post(ipaddress+"/secondproduct/updateSecondProductById",this.formMod).then(res=>{
          console.log("_____formMod_____")
          console.log(this.formMod)
          console.log("_____formMod_____")
          if(res.code === '666'){
            ElMessage({
              message: '成功！',
              type: 'success',
            })
            this.dialogModVisible=false
            this.network()
          }
        }).catch(()=>{
          ElMessage.error('失败！')
          this.dialogModVisible=false
          this.network()
        })
      }

    },
    handleClick(row){ //编辑
      this.getCones()
      this.formMod = JSON.parse(JSON.stringify(row));
      // this.formMod.firstProductId =
      console.log(this.formMod)
      this.dialogModVisible=true
    },
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleCurrentChange(val){ //当前页改变
      console.log(val)
      this.pageNum = val
      this.network()
    },
    handleSizeChange(val){ //页大小改变
      console.log(val)
      this.pageSize = val
      this.network()
    },
    network(){ //分页查询
      if(this.searchName !==""){
        requestData.name = this.searchName
      }
      if(this.typeState !== "全部"){
        this.searchType = this.typeState
        requestData.firstProductId = this.searchType
      }else{
        // console.log('typeState',this.typeState,"haole")
        this.searchType = ""
        requestData.firstProductId = this.searchType
      }

      this.$http.post(ipaddress+
          `/secondproduct/getSecondProductByQuery?PageSize=${this.pageSize}
          &pageNum=${this.pageNum}`,requestData
      ).then(res=>{
        console.log(res)
        if(res.code === '666'){
          this.total = res.data.totalItems //need
          this.tableData = [] // Initialize tableData as an empty array
          res.data.pageItems.forEach(item => { // Loop through the list
            let obj = {} // Create an empty object for each element
            obj.firstProductName = (item.firstProduct == null ? "无":item.firstProduct.name); // Determine if the first product is empty
            obj.id = item.secondProduct.id // Assign the second product id
            obj.name = item.secondProduct.name // Assign the second product name
            obj.description = item.secondProduct.description // Assign the second product description
            this.tableData.push(obj)
          })
        }
      }).catch(()=>{
        ElMessage.error('数据加载失败,请刷新！')
      })

    },
  },
  created(){
    this.getCones();
    this.network();
  }
}
</script>

<template>
  <div class="classTwoItemShow">

    <div style="padding: 0px 0">
      <el-input style="width: 250px" placeholder="二级分类名称" :suffix-icon="Search" v-model="searchName"></el-input>&emsp;

<!--      <el-select-->
<!--          v-model="searchType" -->
      <el-select
          placeholder="一级分类名称"
          v-model="typeState"
          filterable
          allow-create
          default-first-option
          :reserve-keyword="false"
      >
<!--        添加一个“全部”选项且值为空-->
        <el-option
            key=""
            label="全部"
            value="全部"></el-option>&emsp;
        <el-option
            v-for="option in coneType"
            :key="option.id"
            :value="option.id"
            :label="option.name">
        </el-option>
      </el-select>&emsp;

      <el-button type="primary" style="margin-left: 0px" @click="network">
        <el-icon style="vertical-align: middle;">
          <search />
        </el-icon>
        <span style="vertical-align: middle;"> 查询 </span>
      </el-button>
    </div>

    <div style="padding: 10px 0">
      <el-button type="primary" @click="addItem">新增 <el-icon style="margin-left: 3px"><circle-plus /></el-icon></el-button>
      <el-button type="danger" @click="Batchdele">批量删除 <el-icon style="margin-left: 3px"><delete /></el-icon></el-button>
    </div>

    <el-table :data="tableData" border style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column fixed type="selection" width="50px" align="center"></el-table-column>
      <el-table-column fixed prop="id" label="二级分类代码" width="150px" sortable align="center"></el-table-column>
      <el-table-column prop="firstProductName" label="一级分类名称" width="150px" align="center"></el-table-column>
      <el-table-column prop="name" label="二级分类名称" width="150px" align="center"></el-table-column>
      <el-table-column prop="description" label="描述" width="270px" align="center"></el-table-column>
      <el-table-column fixed="right" label="操作" width="250px"  align="center">
        <template v-slot="scope" #default>
          <!-- 编辑按钮 -->
          <el-button @click="handleClick(scope.row)" type="warning" size="default">编辑&thinsp;
            <el-icon> <edit/></el-icon>
          </el-button>
          <!-- 删除按钮 -->
          <el-button @click="delOne(scope.row.id)" type="danger" size="default">删除&thinsp;
            <el-icon> <DeleteFilled/></el-icon>
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-config-provider :locale="locale">
      <div style="padding: 10px 0">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            v-model:currentPage="pageNum"
            :page-sizes="[5, 15, 50, 100]"
            v-model:page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
      </div>
    </el-config-provider>

    <el-dialog title="二级商品添加" v-model="dialogFormVisible" width="50%">
      <el-form :model="form" :rules="rules" ref="form" size="default">
        <el-form-item label="二级分类名称" prop="name">
          <el-input v-model="form.name" placeholder="请输入二级分类名称"></el-input>
        </el-form-item>
        <el-form-item label="一级分类名称" required prop="firstProductId">
          <el-select
              v-model="form.firstProductId"
              placeholder="请选择一级分类名称"
              filterable
              allow-create
              default-first-option>
<!--              :reserve-keyword="false"-->
<!--          >-->
            <el-option
                v-for="item in coneType"
                :key="item.id"
                :label="item.name"
                :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="form.description" placeholder="请输入描述"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('form')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>

    <el-dialog title="二级商品修改" v-model="dialogModVisible" width="50%">
      <el-form :model="formMod" size="default" :rules="rules" ref="formMod">
        <el-form-item label="二级分类名称" :label-width="formLabelWidth" prop="name">
          <el-input v-model="formMod.name" autocomplete="off"></el-input>
        </el-form-item>
<!--        一级分类名称-->
        <el-form-item label="一级分类名称" :label-width="formLabelWidth" prop="firstProductName">
          <el-select
              v-model="formMod.firstProductId"

              placeholder="请选择一级分类名称"
              filterable
              allow-create
              default-first-option
              :reserve-keyword="false"
          >
            <el-option
                v-for="item in coneType"
                :key="item.id"
                :label="item.name"
                :value="item.id">
<!--              {{formMod.firstProductName}}-->
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-form-item label="描述" prop="description">
            <el-input v-model="formMod.description" placeholder="请输入描述"></el-input>
          </el-form-item>
        </el-form-item>
      </el-form>

      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogModVisible = false"> 取消</el-button>
        <el-button type="primary" @click="saveData('formMod')"> 确认</el-button>
      </span>
      </template>
    </el-dialog>

  </div>
</template>

<style scoped>

</style>
