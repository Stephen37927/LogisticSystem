<script setup>
let ipaddress = "/distributionManagement";
</script>

<template>
订购排行榜查询
</template>

<style scoped>

</style>
