<script setup>
let ipaddress = "/distributionManagement";
</script>

<template>
客户满意度分析
</template>

<style scoped>

</style>
