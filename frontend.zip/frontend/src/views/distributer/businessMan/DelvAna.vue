<script setup>
let ipaddress = "/distributionManagement";
</script>

<template>
分站配送情况分析
</template>

<style scoped>

</style>
