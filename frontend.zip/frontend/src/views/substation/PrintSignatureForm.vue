<script>
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {ElMessage} from "element-plus";
import { ref, reactive } from 'vue'

let ipaddress = '/dispatchManagement'
let ordIpaddress = '/customerManagement'
let subIpaddress = '/substationManagement'

export default{
  name:'print-signature-form',
  data(){
    return {
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      total: 0, //总记录数
      locale: zhCn,
      typeT: '',
      statusT: '',
      subStation: '',
      startDateR: '',
      finishDateR: '',
      form: '',
      selectedDeliveryman:'',
      formLabelWidth: '120px',
      tableData: [],
      itemInfoTable: [],
      typeTs:[],
      statusTs:[],
      statusSs:['全部签收','部分签收','拒收'],
      subStations:[],
      deliverymen:[],
      response:{},
      // substation:{},
      formDialogVisible: false,
      isEntry: false,
      rules:{
        signDate:[{required:true,message:'请选择签收日期',trigger:'blur'}],
        status:[{required:true,message:'请选择签收状态',trigger:'blur'}],
      }
    }
  },
  methods:{
    handleSelectionChange(row){ //批量删除选择的数据
      this.multipleSelection = row
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    showGoodsInfo(row){
      let request = []
      console.log('item row',row)
      request.push({"id":row.orderId})
      this.itemInfoTable = []
      this.$http.post(ordIpaddress+`/order/getOrderByQuery?pageNum=1&PageSize=5`,request)
          .then(res=>{
            console.log('item res',res)
            if(res.code === '666'){
              res.data.pageItems[0].orderItems.forEach(item=>{
                console.log('item',item)
                let obj = {}
                obj.purchaseAmt = item.num
                obj.goodsName = item.product.name
                obj.goodsPrice = item.product.sellingPrice
                this.itemInfoTable.push(obj)
              })
              console.log('itemInfoTable',this.itemInfoTable)
            }
          }).catch(err=>{
            console.log(err)
            ElMessage.error('获取商品信息错误')
      })
    },
    // getTaskById(id){
    //   this.response.data.pageItems.forEach(item=>{
    //     if(item.task.id === id){
    //       return item
    //     }
    //   })
    //   return null
    // },
    getTypeTs(){
      this.typeTs = [
        // {
        //   value:"",
        //   label:"全部"
        // },
        {
          value:"送货收款",
          label:"送货收款"
        },
        {
          value:"送货",
          label:"送货"
        },
        {
          value:"退货",
          label:"退货"
        },
        {
          value:"换货",
          label:"换货"
        },
        {
          value:"退款",
          label:"退款"
        }
      ]
    },
    getStatusTs(){
      let arr = []
      for(let i = 1; i < 10; i++){
        arr.push(i)
      }
      arr.forEach(item=>{
        let obj = {}
        obj.id = item
        obj.name = this.statusTransfer(item)
        this.statusTs.push(obj)
      })
    },
    statusTransfer(status){
      let result = ''
      switch(status){
        case 1:
          result = '可分配'
          break
        case 2:
          result = '缺货挂起'
          break
        case 3:
          result = '已调度'
          break
        case 4:
          result = '中心库房出库'
          break
        case 5:
          result = '配送站到货'
          break
        case 6:
          result = '已分配'
          break
        case 7:
          result = '已领货'
          break
        case 8:
          result = '已完成'
          break
        case 9:
          result = '取消订单'
          break
          // case '':
          //   result = '全部'
          //   break
        case '可分配':
          result = 1
          break
        case '缺货挂起':
          result = 2
          break
        case '已调度':
          result = 3
          break
        case '中心库房出库':
          result = 4
          break
        case '配送站到货':
          result = 5
          break
        case '已分配':
          result = 6
          break
        case '已领货':
          result = 7
          break
        case '已完成':
          result = 8
          break
        case '取消订单':
          result = 9
          break
          // case '全部':
          //   result = ''
          //   break
        default:
          result = '未知状态'
      }
      return result
    },
    getSubStations(){
      this.subStations = [
        {
          "id": "1",
          "name": "福建分站"
        },
        {
          "id": "2",
          "name": "浙江分站"
        }
      ]
    },
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    getAllDeliverymen(){
      // this.deliverymen.push({"id":"","name":""})
      this.$http.get(subIpaddress+`/deliveryman/getAllDeliveryman`).then(res=>{
        if(res.code === '666'){
          this.deliverymen = res.data
        }
      }).catch(err=>{
        ElMessage.error('配送员查询失败')
      })
    },
    getTaskById(id){
      let result = {}
      this.response.data.pageItems.forEach(item=>{
        console.log('item.task.id',typeof item.task.id)
        console.log('id',typeof id)
        if(item.task.id === id){
          console.log('item',item)
          result = item
          return result
        }
      })
      return result
    },
    getDeliverymanById(id){
      let result = {}
      this.deliverymen.forEach(item=>{
        if(item.id === id){
          result = item
          return result
        }
      })
      return result
    },
    getSubstationById(callback,id){
      let sub = {}
      this.$http.get(subIpaddress+`/substation/getSubstationById/`+id).then(res=>{
        console.log('get sub res',res)
        if(res.code === '666'){
          sub = res.data
          console.log('sub',sub)
          // this.form.substation = sub.name
          // this.form.substationAddress = sub.address
          // console.log('sub result',sub)
          // return sub
          callback(sub)
        }else{
          return null
        }
      }).catch(err=>{
        ElMessage.error('配送站查询失败')
        return null
      })
    },
    printSig(row){
      // this.showGoodsInfo(row)
      console.log('this.response',this.response)
      let task = this.getTaskById(row.taskId)
      let obj = {}
      console.log('task',task)
      obj.taskId = task.task.id
      obj.customer = task.customer.name
      obj.phone = task.customer.cellPhone
      obj.postcode = task.customer.postcode
      obj.address = task.order.deliveryAddress
      obj.requestArrivalDate = task.order.requestArrivalDate
      obj.comment = (task.order.comment === null)?'无':task.order.comment
      obj.substationId = task.order.subStationId
      obj.isReceipt = (task.order.isReceipt === 1)?'是':'否'
      obj.typeT = task.task.type
      this.form = obj
      this.form.orderId = task.order.id
      this.formDialogVisible = true
      // 延迟2秒显示formDialog
      // setTimeout

      // console.log('task',task)
      // let obj = {}
      // let flag = false
      // const substation = reactive({
      //   name: '',
      //   address: ''
      // })
      // substation = this.getSubstationById(task.order.subStationId)
      // this.getSubstationById(sub => {
      //   console.log('sub1',sub.name)
      //   substation.name = sub.name
      //
      //   substation.address = sub.address
      //
      //   flag = true
      //   console.log('substation',substation)
      //
      // },task.order.subStationId)
      // if(flag){
      //   console.log('substation arrived',substation)
      // }else{
      //   console.log('substation not arrived',substation)
      //   console.log('pause for 1s')
      //   setTimeout(() => {
      //     console.log('pausing substation.name',substation.name)
      //     this.form.taskId = task.task.id
      //     this.form.customer = task.customer.name
      //     this.form.phone = task.customer.cellPhone
      //     this.form.postcode = task.customer.postcode
      //     this.form.address = task.order.deliveryAddress
      //     this.form.requestArrivalDate = task.order.requestArrivalDate
      //     this.form.comment = task.order.comment
      //     this.form.substation = substation.name
      //     this.form.substationAddress = substation.address
      //     this.form.isReceipt = (task.order.isReceipt === 1)?'是':'否'
      //     this.form.typeT = task.task.type
      //     // this.form = obj
      //     console.log('form assigned',this.form)
      //
      //     this.formDialogVisible = true
      //   }, 3000);
      // }
      // console.log('substation2',substation)
      // console.log('name',substation.name)
      // console.log('address',substation.address)
      // // console.log('substation',this.substation)
      // this.form.taskId = task.task.id
      // this.form.customer = task.customer.name
      // this.form.phone = task.customer.cellPhone
      // this.form.postcode = task.customer.postcode
      // this.form.address = task.order.deliveryAddress
      // this.form.requestArrivalDate = task.order.requestArrivalDate
      // this.form.comment = task.order.comment
      // this.formobj.substation = substation.name
      // this.formobj.substationAddress = substation.address
      // this.form.isReceipt = (task.order.isReceipt === 1)?'是':'否'
      // this.form.typeT = task.task.type
      // this.form = obj
      // this.formDialogVisible = true
    },
    printInv(row){

    },
    print(resetForm){
      let request = {
        "taskId": this.form.taskId,
        "status":"初始状态"
      }

      this.$refs[resetForm].validate((valid)=>{
        if(valid){
          this.$http.post(subIpaddress+`/signatureForm/addSignatureForm`,request).then(res=>{
            if(res.code === '666'){
              ElMessage.success('签收单生成成功,开始打印')
              this.formDialogVisible = false
              this.network()
            }
          }).catch(err=>{
            ElMessage.error('签收单生成失败，无法打印')
          })
        }
      })
    },
    entry(resetForm){
      let request = {
        "taskId": this.form.taskId,
        "status":this.form.signStatus,
        "comment":this.form.remark,
        "feedback":this.form.feedback,
        "signDate":this.filterTime(this.form.signDate),
        "sign":this.form.signature
      }
      this.$refs[resetForm].validate((valid)=>{
        if(valid){
          console.log('valid')
          this.$http.post(subIpaddress+`/signatureForm/updateSignatureFormById`,request).then(res=>{
            console.log('update res',res)
            if(res.code === '666'){
              ElMessage.success('签收单录入成功')
              this.formDialogVisible = false
              this.network()
            }else{
              ElMessage.error(res.message)
            }
          }).catch(err=>{
            console.log(err)
            ElMessage.error('签收单录入失败')
          })
        }
      })
    },
    network(){
      let request = {
        "startDateR": this.startDateR===''?'':this.filterTime(this.startDateR),
        "finishDateR": this.finishDateR===''?'':this.filterTime(this.finishDateR),
        "typeT": this.typeT,
        "deliverymanId":this.selectedDeliveryman,
        "status": '已领货',
      }
      this.tableData = []
      this.$http.post(ipaddress+`task/getTaskByQuery?PageSize=${this.pageSize}
      &pageNum=${this.pageNum}`,request).then(res=>{
        if(res.code === '666'){
          // ElMessage.success('任务单信息查询成功')
          this.total = res.data.totalItems
          this.response = res
          let obj = {}
          res.data.pageItems.forEach(item=>{
            obj.taskId = item.task.id
            obj.orderId = item.order.id
            obj.customer = item.customer.name
            obj.phone = item.customer.cellPhone
            obj.address = item.order.deliveryAddress
            obj.deliveryman = this.getDeliverymanById(item.task.deliverymanId).name
            obj.generationDate = item.order.generationDate
            obj.requestArrivalDate = item.order.requestArrivalDate
            obj.typeT = item.task.type
            this.tableData.push(obj)
          })
        }
      }).catch(err=>{
        ElMessage.error('任务单信息查询失败')
      })
    }
  },
  created(){
    this.getTypeTs()
    this.getAllDeliverymen()
    this.network()
    // this.tableData.push({
    //   "taskId":1,
    //   "customer":"徐璟涛",
    //   "address":"福建省福州市闽侯县上街镇上街村",
    //   "requestArrivalDate":"2023-07-21 00:00:00",
    //   "typeT":"送货",
    //   "deliveryman":"szy",
    //   "generationDate":"2023-07-18 00:00:00",
    // })
  }
}
</script>

<template>
  <!--打印配送单-->
  <div class="printSigForm">
    <div class="header">
      <div>
        <span style="margin-left: 15px">类型</span>
        <el-select v-model="typeT" placeholder="请选择任务单类型">
          <el-option
              v-for="item in typeTs"
              :label="item.label"
              :value="item.value">
          </el-option>
        </el-select>
        <span style="margin-left: 15px">配送员</span>
        <el-select v-model="selectedDeliveryman" placeholder="请选择配送员">
          <el-option
              v-for="item in deliverymen"
              :key="item.id"
              :label="item.name"
              :value="item.id">
          </el-option>
        </el-select>
      </div>
      <br/>
      <div>
        <span style="margin-left: 15px;margin-right: 10px;">要求完成日期</span>
        <el-date-picker
            label="订单日期"
            v-model="startDateR"
            type="datetime"
            placeholder="开始日期"
            format="YYYY/MM/DD HH:mm:ss"
        ></el-date-picker>
        <span style="margin-left: 15px;margin-right: 10px;">至</span>
        <el-date-picker
            label="订单日期"
            v-model="finishDateR"
            type="datetime"
            placeholder="结束日期"
            format="YYYY/MM/DD HH:mm:ss"
        ></el-date-picker>
        <span style="margin-left: 15px;margin-right: 10px;"></span>
        <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
      </div>
    </div>
    <br/>
    <div class="taskInfo">
      <el-table :data="tableData" border style="width: min-content">
        <el-table-column fixed type="index" label="序号" width="50" align="center"/>
        <el-table-column prop="taskId" label="任务单号" width="100" align="center"/>
        <el-table-column prop="orderId" label="订单号" width="100" align="center"/>
        <el-table-column prop="customer" label="客户" width="100" align="center"/>
        <el-table-column prop="phone" label="客户电话" width="100" align="center"/>
        <el-table-column prop="address" label="投递地址" width="100" align="center"/>
        <el-table-column prop="deliveryman" label="投递员" width="100" align="center"/>
        <el-table-column prop="generationDate" label="任务生成日期" width="100" align="center"/>
        <el-table-column prop="requestArrivalDate" label="要求完成日期" width="100" align="center"/>
        <el-table-column prop="typeT" label="任务类型" width="100" align="center"/>
        <el-table-column fixed="right" label="操作" width="220" align="center">
          <template v-slot="scope" #default>
            <el-button size="default" type="success" @click="showGoodsInfo(scope.row);isEntry=false;printSig(scope.row)">添加&thinsp;</el-button>
            <el-button size="default" type="primary" @click="showGoodsInfo(scope.row);isEntry=true;printSig(scope.row)">录入&thinsp;</el-button>
<!--            <el-button size="default" type="warning" @click="printInv(scope.row)">发票</el-button>-->
          </template></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
      <el-dialog v-model="formDialogVisible" title="配送单信息" width="60%">
        <el-form :model="form" ref="form" :inline="true" :rules="rules">
          <el-form-item label="任务单号" :label-width="formLabelWidth">
            <el-input v-model="form.taskId" disabled></el-input></el-form-item>
<!--          客户、电话、邮编、送货地址、送货日期、送货要求、送货分站、分站地址、是否要发票、任务类型、备注、客户反馈、客户签名-->
          <el-form-item label="客户" :label-width="formLabelWidth">
            <el-input v-model="form.customer" disabled></el-input></el-form-item>
          <el-form-item label="电话" :label-width="formLabelWidth">
            <el-input v-model="form.phone" disabled></el-input></el-form-item>
          <el-form-item label="邮编" :label-width="formLabelWidth">
            <el-input v-model="form.postcode" disabled></el-input></el-form-item>
          <el-form-item label="送货地址" :label-width="formLabelWidth">
            <el-input v-model="form.address" disabled></el-input></el-form-item>
          <el-form-item label="送货日期" :label-width="formLabelWidth">
            <el-input v-model="form.requestArrivalDate" disabled></el-input></el-form-item>
          <el-form-item label="送货要求" :label-width="formLabelWidth">
            <el-input v-model="form.comment" disabled></el-input></el-form-item>
          <el-form-item label="送货分站" :label-width="formLabelWidth">
            <el-input v-model="form.substationId" disabled></el-input></el-form-item>
<!--          <el-form-item label="分站地址" :label-width="formLabelWidth">-->
<!--            <el-input v-model="form.substationAddress" disabled></el-input></el-form-item>-->
          <el-form-item label="是否要发票" :label-width="formLabelWidth">
            <el-input v-model="form.isReceipt" disabled></el-input></el-form-item>
          <el-form-item label="任务类型" :label-width="formLabelWidth">
            <el-input v-model="form.typeT" disabled></el-input></el-form-item>
          <el-form-item label="商品信息" :label-width="formLabelWidth">
            <el-table :data="itemInfoTable" style="padding-left: 10px;width:min-content;">
              <el-table-column fixed type="index" width="40" align="center"></el-table-column>
              <el-table-column prop="goodsName" label="商品名称" align="center" width="100"></el-table-column>
              <el-table-column prop="purchaseAmt" label="购买数量" align="center" width="100"></el-table-column>
              <el-table-column prop="goodsPrice" label="单价" align="center" width="100"></el-table-column>
            </el-table></el-form-item>
          <div v-if="isEntry">
            <el-form-item label="备注" :label-width="formLabelWidth">
              <el-input v-model="form.remark"></el-input></el-form-item>
            <el-form-item label="客户反馈" :label-width="formLabelWidth">
              <el-input v-model="form.feedback"></el-input></el-form-item>
            <el-form-item label="客户签名" :label-width="formLabelWidth">
              <el-input v-model="form.signature"></el-input></el-form-item>
            <el-form-item label="签收日期" :label-width="formLabelWidth">
              <el-date-picker
                  v-model="form.signDate"
                  type="datetime"
                  placeholder="选择日期"
                  format="YYYY/MM/DD HH:mm:ss"></el-date-picker></el-form-item>
            <el-form-item label="签收单状态" :label-width="formLabelWidth">
              <el-select v-model="form.signStatus" placeholder="请选择">
                <el-option
                  v-for="status in statusSs"
                  :label="status"
                  :value="status"
                />
              </el-select></el-form-item>
          </div>
        </el-form>
        <template #footer>
      <span class="dialog-footer">
        <el-button @click="formDialogVisible=false"> 取消</el-button>
<!--        <el-button type="primary" @click="entry('form')">录入</el-button>-->
        <el-button v-if="isEntry===false" type="primary" @click="print('form')">打印</el-button>
        <el-button v-if="isEntry" type="primary" @click="entry('form')">录入</el-button>
      </span>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<style scoped>
.el-select{
  padding: 10px;
}

.el-form-item{
  width: 300px;
}
</style>
