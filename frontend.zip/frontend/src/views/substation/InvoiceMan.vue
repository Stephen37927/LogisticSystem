<script>
import zhCn from "element-plus/lib/locale/lang/zh-cn";
import {ElMessage} from "element-plus";

let ipaddress = '/financeManagement'

export default {
  data(){
    return {
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      total: 1, //总记录数
      locale: zhCn,
      invoiceInfoTableData:[],
      selectedStatus:'',
      statusIs:['初始状态','领用','退回','作废'],
      dialogVisible: false,
      isRegister:false,
      isFetch:false,
      isReturn:false,
      isCancel:false,
      form:{},

    }
  },
  methods:{
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    register(row){
      this.form.substationId = row.substation
      this.form.invoiceNum = row.invoiceId
    },
    confirm(){
      let status = ''
      if(this.isFetch){status = '领用'}else if(this.isReturn){status = '退回'}else if(this.isCancel){status = '作废'}
      console.log('enter confirm')
      let request = {
        'id':this.form.invoiceNum,
        'startNum':this.form.startNum,
        'finishNum':this.form.finishNum,
        'piCi':this.form.piCi,
        'name':this.form.name===null?'':this.form.name,
        "date":this.form.date===null?'':this.filterTime(this.form.date),
        "status":status
      }
      console.log('request',request)
      this.$http.post(ipaddress+`/receipt/updateReceiptById`,request).then(res=>{
        if(res.code === '666'){
          if(this.isRegister){
            ElMessage.success('登记成功')
          }else if(this.isFetch){
            ElMessage.success('领用成功')
          }else if(this.isReturn){
            ElMessage.success('退回成功')
          }else{
            ElMessage.success('作废成功')
          }
          this.dialogVisible = false
          this.network()
          this.isRegister = false
          this.isFetch = false
          this.isReturn = false
          this.isCancel = false
          this.form = {}
        }
      }).catch(err=>{
        console.log(err)
        ElMessage.error('网络错误')
      })
    },
    fetch(row){
      console.log('enter fetch')
      this.form.invoiceNum = row.invoiceId
      this.form.substationId = row.substation
      this.form.startNum = row.startNum
      this.form.finishNum = row.finishNum
      this.form.piCi = row.piCi
    },
    back(row){
      this.form.invoiceNum = row.invoiceId
      this.form.substationId = row.substation
      this.form.startNum = row.startNum
      this.form.finishNum = row.finishNum
      this.form.piCi = row.piCi
    },
    cancel(row){
      this.form.invoiceNum = row.invoiceId
      this.form.substationId = row.substation
      this.form.startNum = row.startNum
      this.form.finishNum = row.finishNum
      this.form.piCi = row.piCi
    },
    network(){
      this.invoiceInfoTableData = []
      let request = {
        'status':this.selectedStatus
      }
      this.$http.post(ipaddress+`/receipt/getReceiptByQuery?pageNum=${this.pageNum}&PageSize=${this.pageSize}`,request).then(res=>{
        console.log('res',res)
        if(res.code === '666'){
          console.log(res.data)

          res.data.list.forEach(item=>{
            let obj = {}
            obj.invoiceId = item.id
            obj.orderId = item.orderId
            obj.price = item.price
            obj.name = item.name
            obj.date = item.date
            obj.substation = item.substationId
            obj.startNum = item.startNum
            obj.finishNum = item.finishNum
            obj.piCi = item.piCi
            this.invoiceInfoTableData.push(obj)
          })
          this.total = res.data.total
        }
      }).catch(err=>{
        console.log(err)
        ElMessage.error('网络错误')
      })
    },
  },
  created(){
    this.network()
  }
}
</script>

<template>
  <div class="invoiceMan">
    <div class="header">
      <!--      <el-input placeholder="请输入开始号码" v-model="startNum" style="width: 150px;padding-left:10px;"></el-input>-->
      <!--      <el-input placeholder="请输入结束号码" v-model="finishNum" style="width: 150px;padding-left:10px;"></el-input>-->
      <!--      <el-input placeholder="请输入批次" v-model="piCi" style="width: 150px;padding-left:10px;"></el-input>-->
      <!--      选择发票状态-->
      <el-select v-model="selectedStatus" placeholder="请选择发票状态" style="width: 150px;padding-left:10px;">
        <el-option
            v-for="item in statusIs"
            :key="item"
            :label="item"
            :value="item">
        </el-option></el-select>
      <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
    </div>
    <br/>
    <div class="invoiceInfo">
      <el-table :data="invoiceInfoTableData" border style="width: fit-content">
        <el-table-column fixed type="index" label="序号" width="50" align="center"></el-table-column>
        <!--        发票号、订单号、金额、姓名、日期-->
        <el-table-column prop="invoiceId" label="发票号" width="100" align="center"></el-table-column>
        <el-table-column prop="orderId" label="订单号" width="100" align="center"></el-table-column>
        <el-table-column prop="price" label="金额" width="100" align="center"></el-table-column>
        <el-table-column prop="name" label="姓名" width="100" align="center"></el-table-column>
        <el-table-column prop="date" label="日期" width="100" align="center"></el-table-column>
        <el-table-column prop="substation" label="分站代码" width="100" align="center"></el-table-column>
        <!--        开始号码、结束号码-->
        <el-table-column prop="startNum" label="开始号码" width="100" align="center"></el-table-column>
        <el-table-column prop="finishNum" label="结束号码" width="100" align="center"></el-table-column>
        <el-table-column prop="piCi" label="批次" width="100" align="center"></el-table-column>

        <el-table-column fixed="right" label="操作" width="300" align="center">
          <template #default="scope">
            <el-button type="warning" size="mini" @click="isFetch=true;dialogVisible=true;fetch(scope.row)">领用</el-button>
            <el-button type="danger" size="mini" @click="isReturn=true;dialogVisible=true;back(scope.row)">退回</el-button>
            <el-button type="primary" size="mini" @click="isCancel=true;dialogVisible=true;cancel(scope.row)">作废</el-button>
          </template></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>

      <el-dialog v-model="dialogVisible">
        <el-form :model="form" label-width="90px">
          <!--          开始号码、结束号码、批次、姓名-->
          <el-form-item label="发票号"><el-input v-model="form.invoiceNum" disabled/></el-form-item>
          <el-form-item label="开始号码">
            <el-input v-model="form.startNum" v-if="isRegister"></el-input>
            <el-input v-model="form.startNum" v-else disabled></el-input>
          </el-form-item>
          <el-form-item label="结束号码">
            <el-input v-model="form.finishNum" v-if="isRegister"></el-input>
            <el-input v-model="form.finishNum" v-else disabled></el-input>
          </el-form-item>
          <el-form-item label="批次">
            <el-input v-model="form.piCi" v-if="isRegister"></el-input>
            <el-input v-model="form.piCi" v-else disabled></el-input>
          </el-form-item>
          <el-form-item label="分站id">
            <el-input v-model="form.substationId" disabled></el-input>
          </el-form-item>
          <el-form-item label="领用人姓名" v-if="isFetch">
            <el-input v-model="form.name" v-if="isFetch"></el-input>
          </el-form-item>
          <el-form-item label="退回人姓名" v-if="isReturn">
            <el-input v-model="form.name" v-if="isReturn"></el-input>
          </el-form-item>
          <el-form-item label="作废人姓名" v-if="isCancel">
            <el-input v-model="form.name" v-if="isCancel"></el-input>
          </el-form-item>
          <el-form-item label="时间">
            <el-date-picker
                label="订单日期"
                v-model="form.date"
                type="datetime"
                placeholder="请选择时间"
                format="YYYY/MM/DD HH:mm:ss"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="confirm()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<style scoped>

</style>
