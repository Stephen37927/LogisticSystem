<script>
import zhCn from "element-plus/lib/locale/lang/zh-cn";
import {ElMessage} from "element-plus";

let subIpaddress = '/substationManagement'
let ordIpaddress = '/customerManagement'

export default {
  data(){
    return {
      pageNum: 1, //当前页
      pageSize: 5, //页大小
      total:0, //总记录数
      locale: zhCn,
      startDate: '',
      finishDate: '',
      pmtInfoTableData:[],
      itemInfoTable:[],
      obtainedItemList:[],
      substations:[],
      dialogItemVisible: false,
      totalPrice:0,
      backPrice:0,
    }
  },
  methods:{
    filterTime(time) {
      var date = new Date(time);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? "0" + m : m;
      var d = date.getDate();
      d = d < 10 ? "0" + d : d;
      var h = date.getHours();
      h = h < 10 ? "0" + h : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? "0" + minute : minute;
      var s = date.getSeconds();
      s = s < 10 ? "0" + s : s;
      return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + s;
    },
    handleSizeChange(val){ //页大小改变
      this.pageSize = val
      this.network()
    },
    handleCurrentChange(val){ //当前页改变
      this.pageNum = val
      this.network()
    },
    // getSubstations(){
    //   this.$http.get(subIpaddress+`/substation/getAllSubstation`).then(res=>{
    //     if(res.data === '666'){
    //       res.data.forEach(item=>{
    //         this.substations.push({
    //           value:item.id,
    //           label:item.name
    //         })
    //       })
    //     }
    //   })
    // },
    // getSubstationNameById(id){
    //   console.log('id',id)
    //   let result = ''
    //   this.substations.forEach(item=>{
    //     if(item.value === id){
    //       result = item.label
    //     }
    //   })
    //   console.log('result',result)
    //   return result
    // },
    showGoodsInfo(row){
      console.log('row',row)
      let request = []
      request.push({"id":row.orderId})
      this.itemInfoTable = []
      this.$http.post(ordIpaddress+`/order/getOrderByQuery?pageNum=1&PageSize=5`,request)
          .then(res=>{
            if(res.code === '666'){
              res.data.pageItems[0].orderItems.forEach(item=>{
                if(item.product!==null){
                  let obj = {}
                  obj.goodsName = item.product.name
                  obj.purchaseAmt = item.num
                  obj.goodsPrice = item.product.sellingPrice
                  console.log('obj',obj)
                  this.itemInfoTable.push(obj)
                }else{
                  console.log('循环到某商品信息为空')
                  console.log('item',item)
                }
              })
              // this.dialogItemVisible = true
            }
          }).catch(err=>{
        ElMessage.error('商品信息加载失败')
      })
    },
    network(){
      let request = {
        'startDate':(this.startDate==='')?'':this.filterTime(this.startDate),
        'finishDate':(this.finishDate==='')?'':this.filterTime(this.finishDate),
      }
      this.$http.post(subIpaddress+`/huizhi/getHuiZhiByQuery?pageNum=${this.pageNum}&PageSize=${this.pageSize}`,request).then(res=>{
        if(res.code === '666'){
          console.log('res',res)
          this.total = res.data.totalItems
          res.data.pageItems.forEach(item=>{
            console.log('item',item)
            console.log('item.huiZhi',item.huiZhi)
            let obj = {
              "id":item.huiZhi.id,
              "taskId":item.huiZhi.taskId,
              "customerSatisfaction":item.huiZhi.customerSatisfaction,
              "remark":item.huiZhi.comment,
              "paymentDate":item.huiZhi.collectionDate,
              "total":item.huiZhi.sumOriginalPrice,
              "returnAmount":item.huiZhi.backPrice,
              "status":item.huiZhi.type,
              "subStation":item.huiZhi.subStationId,//this.getSubstationNameById(),
              // "obtainedItemList":item.huiZhiItemsMap
            }
            // obj.obtainedItemList = item.huiZhiItemsMap
            console.log('obj',obj)
            this.totalPrice += obj.total
            this.backPrice += obj.returnAmount
            this.pmtInfoTableData.push(obj)
          })
        }
      }).catch(err=>{
        console.log(err)
        ElMessage.error('网络错误，请稍后重试！')
      })
    }
  },
  created(){
    // this.getSubstations()
    this.network()
    // this.pmtInfoTableData.push({
    //   id:1,
    //   taskId:1,
    //   customerSatisfaction:'hihihi',
    //   remark:'ji',
    //   paymentDate:'2023-07-17 11:04:59',
    //   total:179.10,
    //   returnAmount:1432.80,
    //   type:'完成',
    //   subStation:'浙江分站',
    // })


  }
}
</script>

<template>
  <div class="paymentQuery">
    <div class="header">
      <div>
        <span style="margin-left: 15px;margin-right: 10px;">日期</span>
        <el-date-picker
            label="订单日期"
            v-model="startDate"
            type="datetime"
            placeholder="开始日期"
            format="YYYY/MM/DD HH:mm:ss"
        ></el-date-picker>
        <span style="margin-left: 15px;margin-right: 10px;">至</span>
        <el-date-picker
            label="订单日期"
            v-model="finishDate"
            type="datetime"
            placeholder="结束日期"
            format="YYYY/MM/DD HH:mm:ss"
        ></el-date-picker>
        <span style="margin-left: 15px;margin-right: 10px;"></span>
        <el-button type="primary" style="margin-left: 15px;" @click="network">查询</el-button>
      </div>
    </div>
    <br/>
    <div class="paymentInfo">
      <el-table :data="pmtInfoTableData" border style="width: fit-content">
        <el-table-column fixed type="index" label="序号" width="50" align="center"/>
<!--        任务单号、客户满意度、备注、收款日期、总额、退货金额、状态、分站-->
        <el-table-column prop="id" label="回执单号" width="100" align="center"/>
        <el-table-column prop="taskId" label="任务单号" width="100" align="center"/>
        <el-table-column prop="customerSatisfaction" label="客户满意度" width="100" align="center"/>
        <el-table-column prop="remark" label="备注" width="100" align="center"/>
        <el-table-column prop="paymentDate" label="收款日期" width="100" align="center"/>
        <el-table-column prop="total" label="总额" width="100" align="center"/>
        <el-table-column prop="returnAmount" label="退货金额" width="100" align="center"/>
        <el-table-column prop="status" label="状态" width="100" align="center"/>
        <el-table-column prop="subStation" label="分站id" width="100" align="center"/>
        <el-table-column fixed="right" label="操作" width="150" align="center">
          <template v-slot="scope" #default>
            <el-button size="default" type="success" @click="showGoodsInfo(scope.row);this.dialogItemVisible=true;">商品详情&thinsp;</el-button>
          </template></el-table-column>
      </el-table>
      <el-config-provider :locale="locale">
        <div style="padding: 10px 0">
          <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              v-model:currentPage="pageNum"
              :page-sizes="[5, 15, 50, 100]"
              v-model:page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
          </el-pagination>
        </div>
      </el-config-provider>
      实收额：<span style="color: green">{{totalPrice}}</span>
      退款额：<span style="color: red">{{backPrice}}</span>
      应缴额：<span style="color: cornflowerblue">{{totalPrice-backPrice}}</span>
      <el-dialog v-model="dialogItemVisible" title="商品信息" width="30%">
        <el-table :data="itemInfoTable" style="padding-left: 10px;width:min-content;">
          <el-table-column fixed type="index" width="40" align="center"></el-table-column>
          <el-table-column prop="goodsName" label="商品名称" align="center" width="100"></el-table-column>
          <el-table-column prop="purchaseAmt" label="购买数量" align="center" width="100"></el-table-column>
          <el-table-column prop="goodsPrice" label="单价" align="center" width="100"></el-table-column>
        </el-table>
      </el-dialog>
    </div>
  </div>
</template>

<style scoped>

</style>
