import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

export default defineConfig({
  // ...
  plugins: [
    vue(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
    }),
    Components({
      resolvers: [ElementPlusResolver()],
    }),
  ],
  devServer: {
    port: 8085,     // 端口号
  },
  server: {
    port:8081,
    proxy: {
      '/distributionManagement':{
        target: 'http://localhost:8095',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/distributionManagement/,'')
      },
      '/customerManagement':{
        target: 'http://localhost:8091',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/customerManagement/,'')
      },
      '/substationManagement':{
        target: 'http://localhost:8094',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/substationManagement/,'')
      },
      '/dispatchManagement':{
        target: 'http://localhost:8095',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/dispatchManagement/,'')
      },
      '/warehouseManagement':{
        target: 'http://localhost:8093',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/warehouseManagement/,'')
      },
      '/financeManagement':{
        target: 'http://localhost:8097',
        changeOrigin: true,
        ws: true,
        rewrite: (path) => path.replace(/^\/financeManagement/,'')
      }
    }
  },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  }
})

