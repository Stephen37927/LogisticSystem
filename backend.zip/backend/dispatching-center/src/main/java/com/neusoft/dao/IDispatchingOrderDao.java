package com.neusoft.dao;

import com.neusoft.entity.DispatchingOrder;
import com.neusoft.entity.Task;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IDispatchingOrderDao {
    void addDispatchingOrder(DispatchingOrder dispatchingOrder);

    int getMaxId();

    DispatchingOrder getDispatchingOrderById(int id);

    List<DispatchingOrder> getDispatchingOrderByQuery(DispatchingOrder dispatchingOrder);
    void deleteDispatchingOrderById(int id);
    void updateDispatchingOrderById(DispatchingOrder dispatchingOrder);
}
