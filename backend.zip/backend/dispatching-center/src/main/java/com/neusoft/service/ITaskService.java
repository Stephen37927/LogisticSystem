package com.neusoft.service;

import com.neusoft.entity.Task;

import java.util.List;
import java.util.Map;

public interface ITaskService {
    void addTask(Task task);
    Task getTaskById(int id);
    void deleteTaskById(int id);
    void updateTaskById(Task task);

    List<Map<String, Object>> getTaskByQuery(Task task);

    void addTaskPlus(Task task);
}
