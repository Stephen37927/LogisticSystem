package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.PageResult;
import com.neusoft.entity.Task;
import com.neusoft.service.ITaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("task")
public class TaskController {
    private final Logger logger = LoggerFactory.getLogger(TaskController.class);
    @Autowired
    private ITaskService iTaskService;
    @RequestMapping(value = "/addTask")
    @ResponseBody
    public HttpResponseEntity addTask(@RequestBody Task task){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            iTaskService.addTaskPlus(task);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addTask 添加任务>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping (value="/getTaskById/{id}")
    @ResponseBody
    public HttpResponseEntity getTaskById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if(iTaskService.getTaskById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                Task task1 = iTaskService.getTaskById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(task1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getTaskById 按 ID 获取任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "/deleteTask")
    @ResponseBody
    public HttpResponseEntity deleteTaskById(@RequestBody Task task){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iTaskService.getTaskById(task.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iTaskService.deleteTaskById(task.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteTaskById 按 ID 删除任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "/updateTaskById")
    @ResponseBody
    public HttpResponseEntity updateTaskById(@RequestBody Task task){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iTaskService.getTaskById(task.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iTaskService.updateTaskById(task);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateTaskById 按 ID 更新任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getTaskByQuery")
    @ResponseBody
    public HttpResponseEntity getTaskByQuery(@RequestBody Task task, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iTaskService.getTaskByQuery(task)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                List<Map<String, Object>> taskList = iTaskService.getTaskByQuery(task);
                int totalItems = taskList.size();
                if (totalItems > pageSize) {
                    int toIndex = pageSize * pageNum;
                    if (toIndex > totalItems) {
                        toIndex = totalItems;
                    }
                    taskList = taskList.subList(pageSize * (pageNum - 1), toIndex);
                }
                PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,taskList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageResult);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getTaskByQuery 按 查询条件 查询任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

}
