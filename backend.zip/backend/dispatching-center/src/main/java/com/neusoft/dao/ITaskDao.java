package com.neusoft.dao;

import com.neusoft.entity.Task;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ITaskDao {
    void addTask(Task task);

    int getMaxId();

    List<Task> getTaskList();

    void deleteTaskById(int id);

    Task getTaskById(int id);

    void updateTaskById(Task task);

    List<Task> getTaskByQuery(Task task);
}
