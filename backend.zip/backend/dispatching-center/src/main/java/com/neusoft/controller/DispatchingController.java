package com.neusoft.controller;



import com.alibaba.fastjson.JSON;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.utils.DateUtil;
import com.neusoft.dao.IOrderDao;

import com.neusoft.dao.IReceiptDao;
import com.neusoft.entity.*;
import com.neusoft.service.IDispatchingOrderService;
import com.neusoft.service.IOrderService;
import com.neusoft.service.IReceiptService;
import com.neusoft.service.ITaskService;
import org.aspectj.weaver.ast.Or;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("dispatch")
public class DispatchingController {
    private final Logger logger = LoggerFactory.getLogger(DispatchingController.class);

    @Autowired
    private ITaskService iTaskService;

    @Autowired
    private IDispatchingOrderService iDispatchingOrderService;

    @Autowired
    private IOrderService iOrderService;

    @Autowired
    private  IOrderDao iOrderDao;

    @Autowired
    private IReceiptService iReceiptService;

    @Autowired
    private  IReceiptDao iReceiptDao;



    @RequestMapping(value = "/dispatching")
    @ResponseBody
    public HttpResponseEntity addTaskAndDispatchingOrder(@RequestBody HashMap<String, Object> map){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            //生成任务单
            Task task = new Task();
            task.setOrderId((Integer) map.get("orderId"));
            Order order = iOrderDao.getOrderById((int) map.get("orderId"));
            Date date1 = DateUtil.stringToDate((String) map.get("deliveryDate"),"yyyy-MM-dd HH:mm:ss");
            task.setDeliveryDate(date1);
            task.setType((String) map.get("typeT"));
            if(task.getType().equals("退货")){
                task.setStatus("可分配");
            }else{
                task.setStatus("已调度");
            }
            task.setDeliveryAddress(order.getDeliveryAddress());
            task.setRequestFinishDate(order.getRequestArrivalDate());
            iTaskService.addTaskPlus(task);

            //生成发票
            if(task.getType().equals("送货收款")||task.getType().equals("换货")){
                if(order.getIsReceipt()==2){
                    Receipt receipt = new Receipt();
                    receipt.setOrderId(order.getId());
                    receipt.setPrice(order.getSumPrice());
                    receipt.setSubstationId(order.getSubStationId());
                    receipt.setStatus("初始状态");
                    iReceiptService.addReceipt(receipt);

                }
            }
            if(task.getType().equals("退货")){
                  Order oriOrder = iOrderDao.getOrderById(order.getOriginalOrderId());
                  if(oriOrder.getType()==1 && oriOrder.getIsReceipt()==2){
                      Receipt receipt = iReceiptService.getReceiptByOrderId(oriOrder.getId());
                      receipt.setStatus("作废");
                      iReceiptService.updateReceiptById(receipt);
                  }
            }

            //生成调度单
            List<Map<String, Object>> orderItem = iOrderService.getOrderItemsByQuery(order);
            System.out.println(orderItem);
            for (Map<String, Object> oi:orderItem){
                DispatchingOrder dispatchingOrder = new DispatchingOrder();
                dispatchingOrder.setTaskId(task.getId());
                Product product = JSON.parseObject(JSON.toJSONString(oi.get("product")), Product.class);
                int num = (int) oi.get("num");
                dispatchingOrder.setProductId(product.getId());
                dispatchingOrder.setUnit(product.getUnit());
                dispatchingOrder.setProductNum(num);
                System.out.println(order.getSubStationId());
                dispatchingOrder.setStatus("初始状态");
                if(task.getType().equals("送货收款") || task.getType().equals("换货")){
                    dispatchingOrder.setOutId(1);
                    dispatchingOrder.setType("出库调拨单");
                    dispatchingOrder.setInId(order.getSubStationId());
                }
                if(task.getType().equals("退货")){
                    dispatchingOrder.setType("入库调拨单");
                    dispatchingOrder.setOrderId(0);
                    dispatchingOrder.setInId(order.getSubStationId());
                }
                dispatchingOrder.setOrderId((Integer) map.get("orderId"));
                Date date2 = DateUtil.stringToDate((String) map.get("planOutDate"),"yyyy-MM-dd HH:mm:ss");
                dispatchingOrder.setPlanOutDate(date2);
                iDispatchingOrderService.addDispatchingOrder(dispatchingOrder);
            }

            //修改订单的状态
            order.setStatus(3);
            iOrderService.updateOrderById(order);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addTaskAndDispatchingOrder 添加任务单和调度单>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "/checkIfArrivalByOrderId")
    @ResponseBody
    public HttpResponseEntity checkIfArrivalByOrderId(@RequestParam("orderId") Integer orderId){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{

            String msg = null;
            DispatchingOrder dispatchingOrder = new DispatchingOrder();
            dispatchingOrder.setOrderId(orderId);
            dispatchingOrder.setType("购货入库");
            List<DispatchingOrder> dispatchingOrderList = iDispatchingOrderService.getDispatchingOrderByQuery(dispatchingOrder);
            System.out.println(dispatchingOrderList);
            if(dispatchingOrderList.size()==0){
                msg = "您还没购货呢，请尽快购货";
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(msg);
            }else {
                for (DispatchingOrder dor : dispatchingOrderList){
                    if (dor.getStatus().equals("初始状态")){
                        msg = "有货物没到";
                        break;
                    }else {
                        msg = "你的商品到货了";
                    }
                }

                if(msg.equals("有货物没到")){
                    httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                    httpResponseEntity.setData(null);
                    httpResponseEntity.setMessage(msg);
                }else{
                    System.out.println(msg);
                    Order order = new Order();
                    order.setId(orderId);
                    order.setStatus(1);
                    iOrderService.updateOrderById(order);
                    httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                    httpResponseEntity.setData(null);
                    httpResponseEntity.setMessage(msg+"！订单状态已被修改，请尽快对订单进行调度。");
                }
            }

        }catch (Exception e){
            logger.info("checkIfArrivalByOrderId 根据订单号检查是否到货（根据购货调度单状态），如果到货直接修改订单状态，如果没到货返回缺货信息>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
