package com.neusoft.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class DispatchingOrder {
    private int id;
    private int outId;
    private int inId;
    private String status;
    private String type;
    private int productId;
    private int productNum;
    private int actualNum;
    private String unit;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date planOutDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date startDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date finishDate;

    private int orderId;
    private int taskId;
}
