package com.neusoft.controller;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.entity.DispatchingOrder;
import com.neusoft.entity.Task;
import com.neusoft.service.IDispatchingOrderService;
import com.neusoft.service.IStoreService;
import com.neusoft.service.ITaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("dispatchingOrder")
public class DispatchingOrderController {
    private final Logger logger = LoggerFactory.getLogger(DispatchingOrderController.class);

    @Autowired
    private ITaskService iTaskService;

    @Autowired
    private IDispatchingOrderService iDispatchingOrderService;

    @Autowired
    private IStoreService iStoreService;


    @RequestMapping(value = "/addDispatchingOrder")
    @ResponseBody
    public HttpResponseEntity addDispatchingOrder(@RequestBody DispatchingOrder dispatchingOrder){
        System.out.println("==============================="+dispatchingOrder);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            iDispatchingOrderService.addDispatchingOrder(dispatchingOrder);
            if (dispatchingOrder.getInId()==1&&dispatchingOrder.getOutId()==0&&dispatchingOrder.getStatus().equals("初始状态")&&dispatchingOrder.getType().equals("入库调拨单")){
                StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(1, dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
                storeItem.setBufferNum(storeItem.getBufferNum()+dispatchingOrder.getProductNum());
                iStoreService.updateItemByProductId(1,dispatchingOrder.getProductId(),storeItem);
            }
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addDispatchingOrder 添加调度单>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping (value="/getDispatchingOrderById/{id}")
    @ResponseBody
    public HttpResponseEntity getDispatchingOrderById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if(iDispatchingOrderService.getDispatchingOrderById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                DispatchingOrder dispatchingOrder1 = iDispatchingOrderService.getDispatchingOrderById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(dispatchingOrder1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getDispatchingOrderById 按 ID 获取调度单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getDispatchingOrderByQuery")
    @ResponseBody
    public HttpResponseEntity getDispatchingOrderByQuery(@RequestBody DispatchingOrder dispatchingOrder, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        System.out.println(dispatchingOrder);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDispatchingOrderService.getDispatchingOrderByQuery(dispatchingOrder)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                PageHelper.startPage(pageNum,pageSize);
                List<DispatchingOrder> dispatchingOrderList = iDispatchingOrderService.getDispatchingOrderByQuery(dispatchingOrder);
                PageInfo<DispatchingOrder> pageInfo = new PageInfo<>(dispatchingOrderList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getDispatchingOrderByQuery 按 查询条件 查询调拨单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "/deleteDispatchingOrder")
    @ResponseBody
    public HttpResponseEntity deleteDispatchingOrderById(@RequestBody DispatchingOrder dispatchingOrder){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDispatchingOrderService.getDispatchingOrderById(dispatchingOrder.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iDispatchingOrderService.deleteDispatchingOrderById(dispatchingOrder.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteTaskById 按 ID 删除任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "updateDispatchingOrderById")
    @ResponseBody
    public HttpResponseEntity updateDispatchingOrderById(@RequestBody DispatchingOrder dispatchingOrder){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDispatchingOrderService.getDispatchingOrderById(dispatchingOrder.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateTaskById 按 ID 更新任务>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
