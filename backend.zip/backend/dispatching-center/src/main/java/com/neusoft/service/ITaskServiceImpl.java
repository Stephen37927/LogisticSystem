package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ITaskDao;
import com.neusoft.entity.Customer;
import com.neusoft.entity.Order;
import com.neusoft.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ITaskServiceImpl implements ITaskService {
    private static final String Cache_Key_Id = "taskid:";
    private static final String Cache_Key_List = "tasklist";
    @Autowired
    private ITaskDao iTaskDao;

    @Autowired
    private IOrderService iOrderService;

    @Autowired
    private ICustomerService iCustomerService;
    @Autowired
    private RedisUtil redisUtil;
    @Override
    public void addTask(Task task) {

        iTaskDao.addTask(task);
        int maxid = iTaskDao.getMaxId();
        task.setId(maxid);

        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,task,100);
        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Task getTaskById(int id) {

        String key = Cache_Key_Id + id;
        Task taskRedis =(Task)redisUtil.get(key);
        if(taskRedis != null){
            System.out.println("idexist>>>id存在redis");
            return taskRedis;
        }
        System.out.println("idDoes'tExist>>>>id不存在redis");
        Task task = iTaskDao.getTaskById(id);
        redisUtil.setex(key,task,100);
        return task;

    }

    @Override
    public void deleteTaskById(int id) {
        Task task = getTaskById(id);
        iTaskDao.deleteTaskById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public void updateTaskById(Task task) {
        iTaskDao.updateTaskById(task);

        Task task1 = iTaskDao.getTaskById(task.getId());
        String key =Cache_Key_Id + task.getId();
        redisUtil.setex(key,task1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Map<String, Object>> getTaskByQuery(Task task) {
        List<Task>taskList = iTaskDao.getTaskByQuery(task);
        List<Map<String,Object>> returnMap = new ArrayList<>();
        for(Task taskSub : taskList){
            Map<String,Object> mapSub = new HashMap<>();
            int orderId = taskSub.getOrderId();
            Order order = iOrderService.getOrderById(orderId);
            int customerId = order.getCustomerId();
            Customer customer = iCustomerService.getCustomerById(customerId);

            mapSub.put("order",order);
            mapSub.put("customer",customer);
            mapSub.put("task",taskSub);

            returnMap.add(mapSub);

        }
        return returnMap;
    }

    @Override
    public void addTaskPlus(Task task) {
        if(task.getType().equals("送货收款")){
            addTask(task);
        }else if(task.getType().equals("送货")){
            addTask(task);
        }else if(task.getType().equals("退货")){
            returnTask(task);
        }else if(task.getType().equals("退款")){
            returnTask(task);
        }else if (task.getType().equals("换货")){
            addTask(task);
        }
    }

    private void returnTask(Task task) {
        Order order = iOrderService.getOrderById(task.getOrderId());
        Order originalOrder = iOrderService.getOrderById(order.getOriginalOrderId());
        if(originalOrder.getType()==1){
            Task task1 = new Task();
            task1.setOrderId(originalOrder.getId());
            List<Task> originalTaskList = iTaskDao.getTaskByQuery(task1);
            Task originalTask = originalTaskList.get(0);
            originalTask.setStatus("失败");
            iTaskDao.updateTaskById(originalTask);
        }else{
            Task task1 = new Task();
            task1.setOrderId(originalOrder.getOriginalOrderId());
            List<Task> originalTaskList = iTaskDao.getTaskByQuery(task1);
            Task originalTask = originalTaskList.get(0);
            originalTask.setStatus("失败");
            iTaskDao.updateTaskById(originalTask);
        }
        addTask(task);
    }


}

