package com.neusoft.service;


import com.neusoft.entity.DispatchingOrder;
import com.neusoft.entity.Task;

import java.util.List;
import java.util.Map;

public interface IDispatchingOrderService {
    void addDispatchingOrder(DispatchingOrder dispatchingOrder);

    DispatchingOrder getDispatchingOrderById(int id);

    List<DispatchingOrder> getDispatchingOrderByQuery(DispatchingOrder dispatchingOrder);
    void deleteDispatchingOrderById(int id);
    void updateDispatchingOrderById(DispatchingOrder dispatchingOrder);

}
