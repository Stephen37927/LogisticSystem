package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IDispatchingOrderDao;
import com.neusoft.entity.DispatchingOrder;
import com.neusoft.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Service
public class DispatchingOrderServiceImpl implements IDispatchingOrderService{

    private static final String Cache_Key_Id = "dispatchingorderid:";
    private static final String Cache_Key_List = "dispatchingorderlist";

    @Autowired
    private IDispatchingOrderDao iDispatchingOrderDao;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public void addDispatchingOrder(DispatchingOrder dispatchingOrder) {
        System.out.println(dispatchingOrder.getPlanOutDate());
        iDispatchingOrderDao.addDispatchingOrder(dispatchingOrder);
        int maxid = iDispatchingOrderDao.getMaxId();
        dispatchingOrder.setId(maxid);

        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,dispatchingOrder,100);
        redisUtil.del(Cache_Key_List);
    }

    @Override
    public DispatchingOrder getDispatchingOrderById(int id) {
        String key = Cache_Key_Id + id;
        DispatchingOrder dispatchingOrderRedis =(DispatchingOrder) redisUtil.get(key);
        if(dispatchingOrderRedis != null){
            System.out.println("idexist>>>id存在redis");
            return dispatchingOrderRedis;
        }
        System.out.println("idDoes'tExist>>>>id不存在redis");
        DispatchingOrder dispatchingOrder = iDispatchingOrderDao.getDispatchingOrderById(id);
        redisUtil.setex(key,dispatchingOrder,100);
        return dispatchingOrder;
    }

    @Override
    public List<DispatchingOrder> getDispatchingOrderByQuery(DispatchingOrder dispatchingOrder) {
        System.out.println(dispatchingOrder.getPlanOutDate());
      //  System.out.println("22222222222"+dispatchingOrder);
        DispatchingOrder condition = new DispatchingOrder();
        condition.setOutId(dispatchingOrder.getOutId());
        condition.setInId(dispatchingOrder.getInId());
        condition.setProductId(dispatchingOrder.getProductId());
        condition.setProductNum(dispatchingOrder.getProductNum());
        condition.setUnit(dispatchingOrder.getUnit());
        condition.setPlanOutDate(dispatchingOrder.getPlanOutDate());
        condition.setOrderId(dispatchingOrder.getOrderId());
        condition.setTaskId(dispatchingOrder.getTaskId());
        condition.setStatus(dispatchingOrder.getStatus());
       // System.out.println("333333333333333"+dispatchingOrder);
        String type = "";
        if (dispatchingOrder.getType()!=null)
            type = dispatchingOrder.getType();
        if (type.equals("购货入库")){
            condition.setType("入库调拨单");
            condition.setInId(1);
            condition.setOutId(0);
        }else if (type.equals("调拨出库")){
            condition.setType("出库调拨单");
            condition.setOutId(1);
        }else if (type.equals("调拨入库")){
            condition.setType("入库调拨单");
            condition.setOutId(1);
        }else if (type.equals("领货出库")){
            condition.setType("出库调拨单");
            condition.setInId(0);
        }else if (type.equals("退货分站")){
            condition.setType("入库调拨单");
            condition.setOutId(0);
        }else if (type.equals("退货出库")){
            condition.setType("出库调拨单");
            condition.setInId(1);
        }else if (type.equals("退货入库")){
            condition.setType("入库调拨单");
            condition.setInId(1);
        }else if (type.equals("中心出库")){
            condition.setType("出库调拨单");
            condition.setInId(0);
            condition.setOutId(1);
        }else{
            condition.setType("");
        }
        System.out.println("----------"+condition);
        List<DispatchingOrder> dispatchingOrderList = iDispatchingOrderDao.getDispatchingOrderByQuery(condition);
        List<DispatchingOrder> returnList = new ArrayList<DispatchingOrder>();
        for (DispatchingOrder d:dispatchingOrderList){
            if (type.equals("购货入库")){
                returnList.add(d);
            }else if (type.equals("调拨出库")){
                if (d.getInId()!=0&&d.getInId()!=1)
                    returnList.add(d);
            }else if (type.equals("调拨入库")){
                if (d.getInId()!=0&&d.getInId()!=1)
                    returnList.add(d);
            }else if (type.equals("领货出库")){
                if (d.getOutId()!=0&&d.getOutId()!=1)
                    returnList.add(d);
            }else if (type.equals("退货分站")){
                if (d.getInId()!=0&&d.getInId()!=1)
                    returnList.add(d);
            }else if (type.equals("退货出库")){
                if (d.getOutId()!=0&&d.getOutId()!=1)
                    returnList.add(d);
            }else if (type.equals("退货入库")){
                if (d.getOutId()!=0&&d.getOutId()!=1)
                    returnList.add(d);
            }else if (type.equals("中心出库")){
                returnList.add(d);
            }else{
                returnList.add(d);
            }
        }
        System.out.println("11111111111111111"+dispatchingOrderList);
        return returnList;
    }

    @Override
    public void deleteDispatchingOrderById(int id) {
        DispatchingOrder dispatchingOrder = getDispatchingOrderById(id);
        iDispatchingOrderDao.deleteDispatchingOrderById(id);

        String key =Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateDispatchingOrderById(DispatchingOrder dispatchingOrder) {
        iDispatchingOrderDao.updateDispatchingOrderById(dispatchingOrder);

        DispatchingOrder dispatchingOrder1 = iDispatchingOrderDao.getDispatchingOrderById(dispatchingOrder.getId());
        String key =Cache_Key_Id + dispatchingOrder.getId();
        redisUtil.setex(key,dispatchingOrder1,100);

        redisUtil.del(Cache_Key_List);
    }
}
