package com.neusoft.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Receipt;
import com.neusoft.service.IReceiptService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/receipt")
public class ReceiptController {
    private final Logger logger = LoggerFactory.getLogger(ReceiptController.class);
    @Autowired
    private IReceiptService iReceiptService;

    @RequestMapping(value = "/addReceipt")
    @ResponseBody
    public HttpResponseEntity addReceipt(@RequestBody Receipt Receipt){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iReceiptService.addReceipt(Receipt);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addReceipt 添加配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllReceipt")
    @ResponseBody
    public HttpResponseEntity getAllReceipt(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Receipt> ReceiptList = iReceiptService.getReceiptList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(ReceiptList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllReceipt 查询所有配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteReceipt")
    @ResponseBody
    public HttpResponseEntity deleteReceiptById(@RequestBody Receipt Receipt){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iReceiptService.getReceiptById(Receipt.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iReceiptService.deleteReceiptById(Receipt.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteReceiptById 根据id删除配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getReceiptById/{id}")
    @ResponseBody
    public HttpResponseEntity getReceiptById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iReceiptService.getReceiptById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Receipt Receipt1 = iReceiptService.getReceiptById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(Receipt1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getReceiptById 根据id查询配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateReceiptById")
    @ResponseBody
    public HttpResponseEntity updateReceiptById(@RequestBody Receipt Receipt){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iReceiptService.getReceiptById(Receipt.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iReceiptService.updateReceiptById(Receipt);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateReceiptById 根据id修改配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getReceiptByQuery")
    @ResponseBody
    public HttpResponseEntity getReceiptByQuery(@RequestBody Receipt Receipt, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize ){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iReceiptService.getReceiptByQuery(Receipt)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Receipt> ReceiptList = iReceiptService.getReceiptByQuery(Receipt);
                PageInfo<Receipt> pageInfo =new PageInfo<>(ReceiptList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getReceiptByQuery 根据query查询配送员（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
