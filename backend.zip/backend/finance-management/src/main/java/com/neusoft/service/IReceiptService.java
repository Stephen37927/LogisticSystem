package com.neusoft.service;

import com.neusoft.entity.Receipt;

import java.util.List;

public interface IReceiptService {
    void addReceipt(Receipt receipt);

    List<Receipt> getReceiptList();

    Receipt getReceiptById(int id);

    void deleteReceiptById(int id);

    void updateReceiptById(Receipt receipt);

    List<Receipt> getReceiptByQuery(Receipt receipt);

    Receipt getReceiptByOrderId(int id);
}
