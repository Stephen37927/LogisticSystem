package com.neusoft.service;


import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IReceiptDao;
import com.neusoft.entity.Receipt;
import com.neusoft.entity.Receipt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReceiptServiceImpl implements IReceiptService{

    private static final String Cache_Key_Id = "receiptid:";
    private static final String Cache_Key_List = "receiptlist";

    @Autowired
    private IReceiptDao iReceiptDao;
    @Autowired
    private RedisUtil redisUtil;
    @Override
    public void addReceipt(Receipt receipt) {
        iReceiptDao.addReceipt(receipt);

        int maxid = iReceiptDao.getMaxId();
        receipt.setId(maxid);

        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,receipt,100);
        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Receipt> getReceiptList() {
        List<Receipt> ReceiptListRedis = (List<Receipt>)redisUtil.get(Cache_Key_List);
        if (ReceiptListRedis != null){
            System.out.println("list存在redis");
            return ReceiptListRedis;
        }

        System.out.println("list不存在redis");
        List<Receipt> ReceiptList = iReceiptDao.getAllReceipt();
        redisUtil.setex(Cache_Key_List, ReceiptList,100);
        return ReceiptList;
    }

    @Override
    public Receipt getReceiptById(int id) {
        String key = Cache_Key_Id + id;
        Receipt ReceiptRedis = (Receipt) redisUtil.get(key);
        if (ReceiptRedis != null){
            System.out.println("id存在redis");
            return ReceiptRedis;
        }

        System.out.println("id不存在redis");
        Receipt Receipt = iReceiptDao.getReceiptById(id);
        redisUtil.setex(key, Receipt,100);
        return Receipt;
    }

    @Override
    public void deleteReceiptById(int id) {
        iReceiptDao.deleteReceiptById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateReceiptById(Receipt receipt) {
        iReceiptDao.updateReceiptById(receipt);

        Receipt Receipt1 = iReceiptDao.getReceiptById(receipt.getId());
        String key = Cache_Key_Id + receipt.getId();
        redisUtil.setex(key, Receipt1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Receipt> getReceiptByQuery(Receipt receipt) {
        List<Receipt> ReceiptList = iReceiptDao.getReceiptByQuery(receipt);

        return ReceiptList;
    }

    @Override
    public Receipt getReceiptByOrderId(int id) {
        String key = Cache_Key_Id + "orderId" + id;
        Receipt ReceiptRedis = (Receipt) redisUtil.get(key);
        if (ReceiptRedis != null){
            System.out.println("id存在redis");
            return ReceiptRedis;
        }

        System.out.println("id不存在redis");
        Receipt Receipt = iReceiptDao.getReceiptByOrderId(id);
        redisUtil.setex(key, Receipt,100);
        return Receipt;
    }
}
