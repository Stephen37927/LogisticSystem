package com.neusoft.dao;

import com.neusoft.entity.Receipt;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IReceiptDao {
    void addReceipt(Receipt receipt);

    int getMaxId();

    List<Receipt> getAllReceipt();

    Receipt getReceiptById(int id);

    void deleteReceiptById(int id);

    void updateReceiptById(Receipt receipt);

    List<Receipt> getReceiptByQuery(Receipt receipt);

    Receipt getReceiptByOrderId(int id);
}
