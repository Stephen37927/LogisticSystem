package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Customer;
import com.neusoft.entity.Order;
import com.neusoft.service.ICustomerService;
import com.neusoft.service.IOrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/customer")
public class CustomerController {

    private final Logger logger = LoggerFactory.getLogger(CustomerController.class);
    @Autowired
    private ICustomerService iCustomerService;

    @Autowired
    private IOrderService iOrderService;

    @RequestMapping(value = "/addCustomer")
    @ResponseBody
    public HttpResponseEntity addCustomer(@RequestBody Customer customer){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iCustomerService.addCustomer(customer);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addCustomer 添加客户>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllCustomer")
    @ResponseBody
    public HttpResponseEntity getAllCustomer(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Customer> customerList = iCustomerService.getCustomerList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(customerList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllCustomer 查询所有客户>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteCustomer")
    @ResponseBody
    public HttpResponseEntity deleteCustomerById(@RequestBody Customer customer){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iCustomerService.getCustomerById(customer.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Order order = new Order();
                order.setCustomerId(customer.getId());
                List<Order> list = iOrderService.getOrderByQuery(order);
                for (Order o : list){
                    if (o.getStatus()>0){
                        httpResponseEntity.setCode(Constans.EXIST_CODE);
                        httpResponseEntity.setData(null);
                        httpResponseEntity.setMessage(Constans.MESSAGE_DELETEFAIL);
                        return httpResponseEntity;
                    }
                }
                iCustomerService.deleteCustomerById(customer.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteCustomerById 根据id删除客户>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getCustomerById/{id}")
    @ResponseBody
    public HttpResponseEntity getCustomerById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iCustomerService.getCustomerById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Customer customer1 = iCustomerService.getCustomerById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(customer1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getCustomerById 根据id查询客户>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateCustomerById")
    @ResponseBody
    public HttpResponseEntity updateCustomerById(@RequestBody Customer customer){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iCustomerService.getCustomerById(customer.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iCustomerService.updateCustomerById(customer);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateCustomerById 根据id修改客户>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getCustomerByQuery")
    @ResponseBody
    public HttpResponseEntity getCustomerByQuery(@RequestBody Customer customer, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize ){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iCustomerService.getCustomerByQuery(customer)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Customer> customerList = iCustomerService.getCustomerByQuery(customer);
                PageInfo<Customer> pageInfo =new PageInfo<>(customerList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getCustomerByQuery 根据query查询客户（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

}
