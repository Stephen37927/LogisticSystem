package com.neusoft.dao;

import com.neusoft.entity.Order;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IOrderDao {
    void addOrder(Order order);

    int getMaxId();

    List<Order> getOrderList();

    void deleteOrderById(int id);

    Order getOrderById(int id);

    void updateOrderById(Order order);

    List<Order> getOrderByQuery(Order order);
}
