package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.bean.OrderItem;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ICustomerDao;
import com.neusoft.dao.IOrderDao;
import com.neusoft.dao.IProductDao;
import com.neusoft.entity.Customer;
import com.neusoft.entity.Order;
import com.neusoft.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class OrderServiceImpl implements IOrderService{

    private static final String Cache_Key_Id = "orederid:";
    private static final String Cache_Key_List = "orderlist";

    @Autowired
    private IOrderDao iOrderDao;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private IProductDao iProductDao;

    @Autowired
    private IStoreService iStoreService;

    @Autowired
    private ICustomerDao iCustomerDao;


    @Override
    public void addOrder(Order order) {

        if(order.getType()==3){
            order.setStatus(1);
        }else if(order.getType()==2){
            order.setStatus(12);
        }else {
            order = checkProduct(order);
        }
        order.setIsReceipt(order.getIsReceipt()+1);
        List<OrderItem>orderItemList = order.getOrderItemList();
        double sumPrice = 0;
            for (OrderItem o: orderItemList){
                int productId = o.getProductId();
                Map<String, Object> map = iStoreService.getItemByProductId(1,productId);
                StoreItem storeItem = JSON.parseObject(JSON.toJSONString(map.get("storeItem")),StoreItem.class);
                if (storeItem.getUnallocatedNum()<o.getNum()){
                    continue;
                }else {
                    storeItem.setAllocatedNum(storeItem.getAllocatedNum()+o.getNum());
                    storeItem.setUnallocatedNum(storeItem.getUnallocatedNum()-o.getNum());
                    iStoreService.updateItemByProductId(1,productId,storeItem);
                }
            }
        for (OrderItem o: orderItemList){
            int productId = o.getProductId();
            int num = o.getNum();
            Product product = iProductDao.getProductById(productId);
            double price = product.getSellingPrice();
            double discount = product.getDiscount();
            double multiPrice = price*num*discount*0.1;
            sumPrice = sumPrice + multiPrice;
        }
        if(order.getOrderItemList() != null){
            order.setOrderItems(JSON.toJSONString(order.getOrderItemList()));
        }
        order.setSumPrice(sumPrice);

        iOrderDao.addOrder(order);


        int maxid = iOrderDao.getMaxId();
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,order,100);

        redisUtil.del(Cache_Key_List);
    }

    private Order checkProduct(Order order) {
        List<OrderItem> list = order.getOrderItemList();
        //去中心库房看一下有没有缺货
        for (OrderItem o : list){
            Map<String,Object> map = iStoreService.getItemByProductId(1,o.getProductId());
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(map.get("storeItem")),StoreItem.class);
            if (storeItem.getUnallocatedNum()<o.getNum()){
                order.setStatus(2);
                break;
            }else {
                order.setStatus(1);
            }
        }
        return order;
    }

    @Override
    public List<Order> getAllOrder() {
        List<Order> orderListRedis = (List<Order>)redisUtil.get(Cache_Key_List);
        if (orderListRedis != null){
            for (Order o:orderListRedis){
                List<OrderItem> orderItemsList = JSON.parseArray(o.getOrderItems(),OrderItem.class);
                o.setOrderItemList(orderItemsList);
            }
            System.out.println("list存在redis");
            return orderListRedis;
        }

        System.out.println("list不存在redis");
        List<Order> orderList = iOrderDao.getOrderList();
        for (Order o:orderList){
            List<OrderItem> orderItemsList = JSON.parseArray(o.getOrderItems(),OrderItem.class);
            o.setOrderItemList(orderItemsList);
        }
        redisUtil.setex(Cache_Key_List,orderList,100);
        return orderList;
    }

    @Override
    public Order getOrderById(int id) {
        String key = Cache_Key_Id + id;
        Order orderRedis = (Order) redisUtil.get(key);
        if (orderRedis != null){
            System.out.println("id存在redis");
            List<OrderItem> orderItemsList = JSON.parseArray(orderRedis.getOrderItems(),OrderItem.class);
            orderRedis.setOrderItemList(orderItemsList);
            return orderRedis;
        }

        System.out.println("id不存在redis");
        Order order = iOrderDao.getOrderById(id);
        List<OrderItem> orderItemsList = JSON.parseArray(order.getOrderItems(),OrderItem.class);
        order.setOrderItemList(orderItemsList);
        redisUtil.setex(key,order,100);
        return order;
    }

    @Override
    public void deleteOrderById(int id) {
        iOrderDao.deleteOrderById(id);


        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateOrderById(Order order) {
        if(order.getType()==4){
            //新订：改库存，修改原来的订单的状态和货物数量，新增一个推定的订单状态设为已完成
            order = getOrderById(order.getId());
            order.setStatus(9);
        }
        if(order.getOrderItemList() != null){
            order.setOrderItems(JSON.toJSONString(order.getOrderItemList()));
        }

        System.out.println(order);
        iOrderDao.updateOrderById(order);
        System.out.println("___"+order);

        Order order1 = iOrderDao.getOrderById(order.getId());
        String key = Cache_Key_Id + order.getId();
        redisUtil.setex(key,order1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Order> getOrderByQuery(Order order) {
        List<Order> orderList = iOrderDao.getOrderByQuery(order);
        System.out.println(orderList);
        for (Order o:orderList){
            if (o.getStatus()>0) {
                List<OrderItem> orderItemsList = JSON.parseArray(o.getOrderItems(), OrderItem.class);
                o.setOrderItemList(orderItemsList);
            }
        }
        return orderList;
    }

    @Override
    public List<Map<String, Object>> getOrderItemsByQuery(Order order) {
        Order order1 = getOrderById(order.getId());
        List<OrderItem> orderItems = order1.getOrderItemList();
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        for (OrderItem oi: orderItems){
            Map<String, Object> oimap = new HashMap<String, Object>();
            Product product = iProductDao.getProductById(oi.getProductId());
            oimap.put("product",product);
            oimap.put("num",oi.getNum());
            mapList.add(oimap);
        }
        System.out.println(mapList);
        return mapList;
    }

    @Override
    public List<Map<String, Object>> getOrderByQueryPlus(List<Order> orderList) {
        List<Map<String,Object>> mapFinalList= new ArrayList<>();

        List<Order> orderListAll = new ArrayList<>();
        for (Order order:orderList){
            List<Order> orderList1 = iOrderDao.getOrderByQuery(order);
            orderListAll.addAll(orderList1);
        }
        Set<Order> itemSet = new HashSet<>(orderListAll);

// 将 Set 转换为新的列表（如果需要保持原有的顺序，可以使用 LinkedHashSet）
        List<Order> uniqueList = new ArrayList<>(itemSet);
        for (Order o:uniqueList){
            if (o.getStatus()>0) {
                List<OrderItem> orderItemsList = JSON.parseArray(o.getOrderItems(), OrderItem.class);
                o.setOrderItemList(orderItemsList);
            }
        }
        for (Order order:uniqueList){
            List<Map<String, Object>> oderItemMap = getOrderItemsByQuery(order);
            Customer customer = iCustomerDao.getCustomerById(order.getCustomerId());
            Map<String,Object> mapSub = new HashMap<>();
            mapSub.put("order",order);
            mapSub.put("orderItems",oderItemMap);
            mapSub.put("customer",customer);
            mapFinalList.add(mapSub);
        }
        return mapFinalList;
    }

    @Override
    public void addOrderPlus(Order order) {
        if(order.getType()==1 || order.getType()==4){
            addOrder(order);
        }
        if (order.getType()==2){
            int oriId = order.getOriginalOrderId();
            if (order.getOrderItemList()==null){
                order.setOrderItemList(getOrderById(oriId).getOrderItemList());
            }
            addOrder(order);
            int id = iOrderDao.getMaxId();
            Order order1 = order;
            order1.setOriginalOrderId(id);
            returnProductOrder(order1,oriId);
        }else if(order.getType()==3){
            System.out.println(order);
            returnProductOrder(order,order.getOriginalOrderId());
        }
    }

    private void returnProductOrder(Order order, int oriId) {
        if(order.getType()==3){
            Order order1 = getOrderById(order.getOriginalOrderId());
            order1.setStatus(11);
            if (order.getOrderItemList()==null){
                order.setOrderItemList(order1.getOrderItemList());
            }
            updateOrderById(order1);
            order.setType(3);
            addOrder(order);
        }
        if (order.getType()==2){
            Order order1 = getOrderById(oriId);
            order1.setStatus(11);
            updateOrderById(order1);
            order.setType(3);
            addOrder(order);
        }

    }
}
