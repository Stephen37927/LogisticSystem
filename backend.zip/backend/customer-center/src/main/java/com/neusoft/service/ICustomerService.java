package com.neusoft.service;

import com.neusoft.entity.Customer;

import java.util.List;

public interface ICustomerService {

    void addCustomer(Customer customer);
    List<Customer> getCustomerList();

    void deleteCustomerById(int id);

    Customer getCustomerById(int id);

    void updateCustomerById(Customer customer);

    List<Customer> getCustomerByQuery(Customer customer);
}
