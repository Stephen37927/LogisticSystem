package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ICustomerDao;
import com.neusoft.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements ICustomerService {

    private static final String Cache_Key_Id = "customerid:";
    private static final String Cache_Key_List = "customerlist";

    @Autowired
    private ICustomerDao iCustomerDao;
    @Autowired
    private RedisUtil redisUtil;



    @Override
    public void addCustomer(Customer customer) {
        iCustomerDao.addCustomer(customer);

        int maxid = iCustomerDao.getMaxId();
        customer.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key, customer,100);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public List<Customer> getCustomerList() {
        List<Customer> customerListRedis = (List<Customer>)redisUtil.get(Cache_Key_List);
        if (customerListRedis != null){
            System.out.println("list存在redis");
            return customerListRedis;
        }

        System.out.println("list不存在redis");
        List<Customer> customerList = iCustomerDao.getCustomerList();
        redisUtil.setex(Cache_Key_List, customerList,100);
        return customerList;
    }

    @Override
    public void deleteCustomerById(int id) {
        Customer customer = getCustomerById(id);
        iCustomerDao.deleteCustomerById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Customer getCustomerById(int id) {
        String key = Cache_Key_Id + id;
        Customer customerRedis = (Customer)redisUtil.get(key);
        if (customerRedis != null){
            System.out.println("id存在redis");
            return customerRedis;
        }

        System.out.println("id不存在redis");
        Customer customer = iCustomerDao.getCustomerById(id);
        redisUtil.setex(key, customer,100);
        return customer;
    }

    @Override
    public void updateCustomerById(Customer customer) {
        iCustomerDao.updateCustomerById(customer);

        Customer customer1 = iCustomerDao.getCustomerById(customer.getId());
        String key = Cache_Key_Id + customer.getId();
        redisUtil.setex(key, customer1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Customer> getCustomerByQuery(Customer customer) {

        List<Customer> list = iCustomerDao.getCustomerByQuery(customer);
        return list;
    }

}
