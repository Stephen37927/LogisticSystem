package com.neusoft.dao;

import com.neusoft.entity.Customer;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ICustomerDao {
    Customer getCustomerById(int id);//根据id获取供应商

    void addCustomer(Customer customer);//增加供应商

    List<Customer> getCustomerList();//获取供应商列表

    void deleteCustomerById(int id);//根据id删除供应商

    void updateCustomerById(Customer customer);

    List<Customer> getCustomerByQuery(Customer customer);

    int getMaxId();
}
