package com.neusoft.controller;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.OrderItem;
import com.neusoft.common.bean.PageResult;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.entity.Order;
import com.neusoft.service.IOrderService;
import com.neusoft.service.IStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/order")
public class OrderController {
    private final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private IOrderService iOrderService;

    @RequestMapping(value = "/addOrder")
    @ResponseBody
    public HttpResponseEntity addOrder(@RequestBody Order order){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(order.getType()==2 && order.getStatus() != 8){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage("此订单还没送达，不可换货");
            }else {
                iOrderService.addOrderPlus(order);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
            }
        }catch (Exception e){
            logger.info("addOrder 添加订单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getAllOrder")
    @ResponseBody
    public HttpResponseEntity getAllOrder(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Order> orderList = iOrderService.getAllOrder();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(orderList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllOrder 查询所有订单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/deleteOrder")
    @ResponseBody
    public HttpResponseEntity deleteOrderById(@RequestBody Order order){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iOrderService.getOrderById(order.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iOrderService.deleteOrderById(order.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteOrderById 根据id删除订单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getOrderById/{id}")
    @ResponseBody
    public HttpResponseEntity getOrderById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iOrderService.getOrderById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Order order = iOrderService.getOrderById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(order);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getOrderById 根据id查询订单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateOrderById")
    @ResponseBody
    public HttpResponseEntity updateOrderById(@RequestBody Order order){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(order.getType()==4 && order.getStatus() != 1){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage("此订单不是挂起或者可分配订单，不可退订");
            }
            if(iOrderService.getOrderById(order.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iOrderService.updateOrderById(order);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateOrderById 根据id修改订单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getOrderByQuery")
    @ResponseBody
    public HttpResponseEntity getOrderByQuery(@RequestBody List<Order> orderList, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        System.out.println("+++++++++++++++++++++++++++++++++"+orderList);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iOrderService.getOrderByQueryPlus(orderList)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{

                List<Map<String,Object>> orderListAll = iOrderService.getOrderByQueryPlus(orderList);
                int totalItems = orderListAll.size();
                if (totalItems > pageSize) {
                    int toIndex = pageSize * pageNum;
                    if (toIndex > totalItems) {
                        toIndex = totalItems;
                    }
                    orderListAll = orderListAll.subList(pageSize * (pageNum - 1), toIndex);
                }
                PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,orderListAll);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageResult);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getOrderByQuery 根据query查询订单（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getOrderItemsByQuery")
    @ResponseBody
    public HttpResponseEntity getOrderItemsByQuery(@RequestBody Order order, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iOrderService.getOrderByQuery(order)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Map<String, Object>> list = iOrderService.getOrderItemsByQuery(order);
                PageInfo<Map<String, Object>> pageInfo =new PageInfo<>(list);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getOrderItemsByQuery 根据商品query和库房id查询库存条目（支持商品名模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }




}
