package com.neusoft.entity;

import lombok.Data;

@Data
public class Customer {
    private int id;
    private String name;
    private String idCardNum;
    private String company;
    private String officePhone;
    private String cellPhone;
    private String postcode;
    private String email;
    private String deliveryAddress;
    private String region;
}
