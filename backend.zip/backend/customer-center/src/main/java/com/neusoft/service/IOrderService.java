package com.neusoft.service;

import com.neusoft.entity.Order;

import java.util.List;
import java.util.Map;

public interface IOrderService {

    void addOrder(Order order);

    List<Order> getAllOrder();

    Order getOrderById(int id);

    void deleteOrderById(int id);

    void updateOrderById(Order order);

    List<Order> getOrderByQuery(Order order);

    List<Map<String, Object>> getOrderItemsByQuery(Order order);

    List<Map<String, Object>> getOrderByQueryPlus(List<Order> orderList);

    void addOrderPlus(Order order);

}
