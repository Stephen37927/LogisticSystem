package com.neusoft.common.bean;

import lombok.Data;

@Data
public class OrderItem {
    private int productId;
    private int num;
}
