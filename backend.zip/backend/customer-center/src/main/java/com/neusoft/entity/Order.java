package com.neusoft.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.neusoft.common.bean.OrderItem;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
public class Order {
    private int id;
    private int type;
    private int customerId;
    private String receiver;
    private String receiverPhone;
    private String receiverPostCode;


    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date generationDate;


    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date requestArrivalDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date startDateR;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date finishDateR;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date startDateG;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date finishDateG;

    private int isReceipt;
    private String orderItems;
    private List<OrderItem> orderItemList;
    private String comment;
    private int subStationId;
    private String deliveryAddress;
    private int status;
    private int originalOrderId;
    private String reason;
    private  double sumPrice;

}
