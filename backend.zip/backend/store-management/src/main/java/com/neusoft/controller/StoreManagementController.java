package com.neusoft.controller;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.OrderItem;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.common.utils.DateUtil;
import com.neusoft.entity.*;
import com.neusoft.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@CrossOrigin
@RequestMapping("/storeManagement")

public class
StoreManagementController {

    private final Logger logger = LoggerFactory.getLogger(StoreManagementController.class);

    @Autowired
    private IDispatchingOrderService iDispatchingOrderService;
    @Autowired
    private IStoreService iStoreService;

    @Autowired
    private IOrderService iOrderService;

    @Autowired
    private ITaskService iTaskService;

    @Autowired
    private IProductService iProductService;

    @Autowired
    private ISecondProductService iSecondProductService;

    @Autowired
    private IFirstProductService iFirstProductService;

    @Autowired
    private ISupplierService iSupplierService;

    @RequestMapping(value = "/takeGoodsByTask")
    @ResponseBody
    public HttpResponseEntity takeGoodsByTask(@RequestBody Task task) {
        System.out.println(task);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            //查询此任务单对应的领货出库单
            DispatchingOrder condition = new DispatchingOrder();
            condition.setTaskId(task.getId());
            condition.setStatus("初始状态");
            condition.setType("领货出库");
            List<DispatchingOrder> list = iDispatchingOrderService.getDispatchingOrderByQuery(condition);
            //修改领货出库单状态为已完成状态，并修改分站库房库存
            for (DispatchingOrder d : list){
                d.setStatus("已完成状态");
                iDispatchingOrderService.updateDispatchingOrderById(d);
                StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(d.getOutId(),d.getProductId()).get("storeItem")),StoreItem.class);
                storeItem.setAllocatedNum(storeItem.getAllocatedNum()-d.getProductNum());
                iStoreService.updateItemByProductId(d.getOutId(),d.getProductId(),storeItem);
            }
            Order order = new Order();
            order.setId(task.getOrderId());
            order.setStatus(7);
            iOrderService.updateOrderById(order);
            task.setStatus("已领货");
            iTaskService.updateTaskById(task);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("takeGoodsByTask 根据任务单领货>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/inCenterStore")
    @ResponseBody
    public HttpResponseEntity inCenterStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            //如果有残缺值，那么暂时保留初始状态；如果全部入库，改调拨单状态为已完成状态
            if (dispatchingOrder.getProductNum() == dispatchingOrder.getActualNum()){
                dispatchingOrder.setStatus("已完成状态");
                iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);
            }
            //修改中心库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(1,dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setUnallocatedNum(storeItem.getUnallocatedNum()+dispatchingOrder.getActualNum());
            storeItem.setDefectiveNum(storeItem.getDefectiveNum()+dispatchingOrder.getProductNum()- dispatchingOrder.getActualNum());
            storeItem.setBufferNum(storeItem.getBufferNum()- dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(1,dispatchingOrder.getProductId(),storeItem);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("takeGoodsByTask 根据任务单领货>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/outCenterStore")
    @ResponseBody
    public HttpResponseEntity outCenterStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

            //找到订单对应的所有出库调拨单是否都已完成
            DispatchingOrder condition = new DispatchingOrder();
            condition.setOrderId(dispatchingOrder.getOrderId());
            condition.setStatus("初始状态");
            condition.setType("调拨出库");
            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
                order.setStatus(4);
                iOrderService.updateOrderById(order);
            }

            //减少中心库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(1,dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setUnallocatedNum(storeItem.getUnallocatedNum()-dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(1,dispatchingOrder.getProductId(),storeItem);

            //生成分站库房调拨入库单
            DispatchingOrder dpo = new DispatchingOrder();
            dpo.setOutId(1);
            dpo.setInId(dispatchingOrder.getInId());
            dpo.setStatus("初始状态");
            dpo.setType("入库调拨单");
            dpo.setProductId(dispatchingOrder.getProductId());
            dpo.setProductNum(dispatchingOrder.getProductNum());
            dpo.setUnit(dispatchingOrder.getUnit());
            dpo.setPlanOutDate(DateUtil.getCurrentDate());
            dpo.setOrderId(dispatchingOrder.getOrderId());
            dpo.setTaskId(dispatchingOrder.getTaskId());
            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("takeGoodsByTask 根据任务单领货>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/printOutStoreOrder")
    @ResponseBody
    public HttpResponseEntity printOutStoreOrder(@RequestParam String date, @RequestParam String productName,@RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize) {
        Date date1 = DateUtil.stringToDate(date,"yyyy-MM-dd");
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            //1、根据日期查找已完成的调拨出库单
            DispatchingOrder condition = new DispatchingOrder();
            condition.setPlanOutDate(date1);
            condition.setStatus("已完成状态");
            condition.setType("调拨出库");
            List<DispatchingOrder> list = iDispatchingOrderService.getDispatchingOrderByQuery(condition);
            System.out.println("finish1");
            //2、根据商品名筛选并查重
            Map<Integer,Integer> map = new HashMap<Integer,Integer>();
            for (DispatchingOrder d : list){
                Product product = (Product) iProductService.getProductById(d.getProductId()).get("product");
                if (!productName.equals("")&&productName!=null&&!product.getName().equals(productName)){
                    continue;
                }
                //System.out.println(product);
                if (map.get(product.getId())==null){
                    map.put(product.getId(),d.getProductNum());
                }else {
                    map.put(product.getId(), map.get(product.getId()) + d.getProductNum());
                }
            }
            System.out.println("finish2");
            //3、将map整合到list中并返回
            List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
            Set<Integer> keySet = map.keySet();
            for (Integer key: keySet){
                Product product = (Product) iProductService.getProductById(key).get("product");
                System.out.println(product);
                Map<String,Object> m = new HashMap<String,Object>();
                m.put("productId",key);
                m.put("productName",product.getName());
                m.put("sellingPrice",product.getSellingPrice());
                m.put("discount",product.getDiscount());
                m.put("productNum",map.get(key));
                m.put("supplier",iSupplierService.getSupplierById(product.getSupplierId()).getName());
                m.put("date",date);
                m.put("totalPrice",product.getSellingPrice()*product.getDiscount()/10*map.get(key));
                returnList.add(m);
            }
            System.out.println("finish3");
            PageHelper.startPage(pageNum,pageSize);
            PageInfo<Map<String, Object>> pageInfo =new PageInfo<>(returnList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(pageInfo);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("printOutStoreOrder 打印出库单>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/printLaunchOrder")
    @ResponseBody
    public HttpResponseEntity printLaunchOrder(@RequestParam String date, @RequestParam String productName,@RequestParam String storeName,@RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize) {
        Date date1 = DateUtil.stringToDate(date,"yyyy-MM-dd");
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            //1、根据日期查找已完成的调拨出库单
            DispatchingOrder condition = new DispatchingOrder();
            condition.setPlanOutDate(date1);
            condition.setStatus("已完成状态");
            condition.setType("调拨出库");
            Store storeCondition = new Store();
            storeCondition.setName(storeName);
            List<Store> storeList = iStoreService.getStoreByQuery(storeCondition);
            condition.setInId(storeList.get(0).getId());
            List<DispatchingOrder> list = iDispatchingOrderService.getDispatchingOrderByQuery(condition);
            //2、根据商品名筛选并查重
            Map<Integer,Integer> map = new HashMap<Integer,Integer>();
            for (DispatchingOrder d : list){
                Product product = (Product) iProductService.getProductById(d.getProductId()).get("product");
                if (!productName.equals("")&&productName!=null&&!product.getName().equals(productName)){
                    continue;
                }
                if (map.get(product.getId())==null){
                    map.put(product.getId(),d.getProductNum());
                }else {
                    map.put(product.getId(), map.get(product.getId()) + d.getProductNum());
                }
            }
            //将map整合到list中并返回
            List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
            Set<Integer> keySet = map.keySet();
            for (Integer key: keySet){
                Product product = (Product) iProductService.getProductById(key).get("product");
                Map<String,Object> m = new HashMap<String,Object>();
                m.put("storeName",storeName);
                m.put("operator","admin");
                m.put("productId",key);
                m.put("productName",product.getName());
                m.put("sellingPrice",product.getSellingPrice());
                m.put("discount",product.getDiscount());
                m.put("productNum",map.get(key));
                m.put("supplier",iSupplierService.getSupplierById(product.getSupplierId()).getName());
                m.put("date",date);
                m.put("launchPerson",iStoreService.getStoreById(1).getManager());
                m.put("signPerson",storeList.get(0).getManager());
                m.put("totalPrice",product.getSellingPrice()*product.getDiscount()/10*map.get(key));
                returnList.add(m);
            }
            PageHelper.startPage(pageNum,pageSize);
            PageInfo<Map<String, Object>> pageInfo =new PageInfo<>(returnList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(pageInfo);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("printLaunchOrder 打印分发单>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/inSubstationStore")
    @ResponseBody
    public HttpResponseEntity inSubstationStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

            //找到订单对应的所有入库调拨单是否都已完成
            DispatchingOrder condition = new DispatchingOrder();
            condition.setOrderId(dispatchingOrder.getOrderId());
            condition.setStatus("初始状态");
            condition.setType("调拨入库");
            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
                order.setStatus(5);
                iOrderService.updateOrderById(order);
                Task task = iTaskService.getTaskById(dispatchingOrder.getTaskId());
                task.setStatus("可分配");
                iTaskService.updateTaskById(task);
            }

            //增加分站库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(dispatchingOrder.getInId(),dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setAllocatedNum(storeItem.getAllocatedNum()+dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(dispatchingOrder.getInId(),dispatchingOrder.getProductId(),storeItem);

            //生成分站库房领货出库库单
            DispatchingOrder dpo = new DispatchingOrder();
            dpo.setOutId(dispatchingOrder.getInId());
            dpo.setInId(0);
            dpo.setStatus("初始状态");
            dpo.setType("出库调拨单");
            dpo.setProductId(dispatchingOrder.getProductId());
            dpo.setProductNum(dispatchingOrder.getProductNum());
            dpo.setUnit(dispatchingOrder.getUnit());
            dpo.setPlanOutDate(DateUtil.getCurrentDate());
            dpo.setOrderId(dispatchingOrder.getOrderId());
            dpo.setTaskId(dispatchingOrder.getTaskId());
            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("takeGoodsByTask 根据任务单领货>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/returnInSubstationStore")
    @ResponseBody
    public HttpResponseEntity returnInSubstationStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

//            //找到订单对应的所有入库调拨单是否都已完成
//            DispatchingOrder condition = new DispatchingOrder();
//            condition.setOrderId(dispatchingOrder.getOrderId());
//            condition.setStatus("初始状态");
//            condition.setType("退货分站");
//            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
//                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
//                order.setStatus(5);
//                iOrderService.updateOrderById(order);
//                Task task = iTaskService.getTaskById(dispatchingOrder.getTaskId());
//                task.setStatus("可分配");
//                iTaskService.updateTaskById(task);
//            }

            //增加分站库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(dispatchingOrder.getInId(),dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setBackNum(storeItem.getBackNum()+dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(dispatchingOrder.getInId(),dispatchingOrder.getProductId(),storeItem);
            //生成退货分站库房出库单
            DispatchingOrder dpo = new DispatchingOrder();
            dpo.setOutId(dispatchingOrder.getInId());
            dpo.setInId(1);
            dpo.setStatus("初始状态");
            dpo.setType("出库调拨单");
            dpo.setProductId(dispatchingOrder.getProductId());
            dpo.setProductNum(dispatchingOrder.getProductNum());
            dpo.setUnit(dispatchingOrder.getUnit());
            dpo.setPlanOutDate(DateUtil.getCurrentDate());
            dpo.setOrderId(dispatchingOrder.getOrderId());
            dpo.setTaskId(dispatchingOrder.getTaskId());
            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("returnInSubstationStore 退货分站库房入库>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/returnOutSubstationStore")
    @ResponseBody
    public HttpResponseEntity returnOutSubstationStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

//            //找到订单对应的所有出库调拨单是否都已完成
//            DispatchingOrder condition = new DispatchingOrder();
//            condition.setOrderId(dispatchingOrder.getOrderId());
//            condition.setStatus("初始状态");
//            condition.setType("调拨出库");
//            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
//                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
//                order.setStatus(4);
//                iOrderService.updateOrderById(order);
//            }

            //减少分站库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(dispatchingOrder.getOutId(), dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setBackNum(storeItem.getBackNum()-dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(dispatchingOrder.getOutId(), dispatchingOrder.getProductId(),storeItem);

            //生成退货中心库房入库单
            DispatchingOrder dpo = new DispatchingOrder();
            dpo.setOutId(dispatchingOrder.getOutId());
            dpo.setInId(1);
            dpo.setStatus("初始状态");
            dpo.setType("入库调拨单");
            dpo.setProductId(dispatchingOrder.getProductId());
            dpo.setProductNum(dispatchingOrder.getProductNum());
            dpo.setUnit(dispatchingOrder.getUnit());
            dpo.setPlanOutDate(DateUtil.getCurrentDate());
            dpo.setOrderId(dispatchingOrder.getOrderId());
            dpo.setTaskId(dispatchingOrder.getTaskId());
            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("returnOutSubstationStore 退货分站库房出库>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/returnInCenterStore")
    @ResponseBody
    public HttpResponseEntity returnInCenterStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

//            //找到订单对应的所有入库调拨单是否都已完成
//            DispatchingOrder condition = new DispatchingOrder();
//            condition.setOrderId(dispatchingOrder.getOrderId());
//            condition.setStatus("初始状态");
//            condition.setType("退货分站");
//            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
//                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
//                order.setStatus(5);
//                iOrderService.updateOrderById(order);
//                Task task = iTaskService.getTaskById(dispatchingOrder.getTaskId());
//                task.setStatus("可分配");
//                iTaskService.updateTaskById(task);
//            }

            //增加中心库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(1,dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setBackNum(storeItem.getBackNum()+dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(1,dispatchingOrder.getProductId(),storeItem);
            //生成退货中心库房出库单
            DispatchingOrder dpo = new DispatchingOrder();
            dpo.setOutId(1);
            dpo.setInId(0);
            dpo.setStatus("初始状态");
            dpo.setType("出库调拨单");
            dpo.setProductId(dispatchingOrder.getProductId());
            dpo.setProductNum(dispatchingOrder.getProductNum());
            dpo.setUnit(dispatchingOrder.getUnit());
            dpo.setPlanOutDate(DateUtil.getCurrentDate());
            dpo.setOrderId(dispatchingOrder.getOrderId());
            dpo.setTaskId(dispatchingOrder.getTaskId());
            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("returnInCenterStore 退货中心库房入库>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/returnOutCenterStore")
    @ResponseBody
    public HttpResponseEntity returnOutCenterStore(@RequestBody DispatchingOrder dispatchingOrder) {
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            dispatchingOrder.setStatus("已完成状态");
            iDispatchingOrderService.updateDispatchingOrderById(dispatchingOrder);

            //找到订单对应的所有出库调拨单是否都已完成
            DispatchingOrder condition = new DispatchingOrder();
            condition.setOrderId(dispatchingOrder.getOrderId());
            condition.setStatus("初始状态");
            condition.setType("中心出库");
            if (iDispatchingOrderService.getDispatchingOrderByQuery(condition).size()==0){
                Order order = iOrderService.getOrderById(dispatchingOrder.getOrderId());
                order.setStatus(4);
                iOrderService.updateOrderById(order);
                Task task = iTaskService.getTaskById(dispatchingOrder.getTaskId());
                task.setStatus("待回执");
                iTaskService.updateTaskById(task);
            }

            //减少中心库房库存
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(iStoreService.getItemByProductId(1, dispatchingOrder.getProductId()).get("storeItem")),StoreItem.class);
            storeItem.setBackNum(storeItem.getBackNum()-dispatchingOrder.getProductNum());
            iStoreService.updateItemByProductId(1, dispatchingOrder.getProductId(),storeItem);

            //生成退货中心库房入库单
//            DispatchingOrder dpo = new DispatchingOrder();
//            dpo.setOutId(dispatchingOrder.getOutId());
//            dpo.setInId(1);
//            dpo.setStatus("初始状态");
//            dpo.setType("入库调拨单");
//            dpo.setProductId(dispatchingOrder.getProductId());
//            dpo.setProductNum(dispatchingOrder.getProductNum());
//            dpo.setUnit(dispatchingOrder.getUnit());
//            dpo.setPlanOutDate(DateUtil.getCurrentDate());
//            dpo.setOrderId(dispatchingOrder.getOrderId());
//            dpo.setTaskId(dispatchingOrder.getTaskId());
//            iDispatchingOrderService.addDispatchingOrder(dpo);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("returnOutCenterStore 退货中心库房出库>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getLackItemByOrder")
    @ResponseBody
    public HttpResponseEntity getLackItemByOrder(@RequestParam("pageNum") Integer pageNum,@RequestParam("PageSize") Integer pageSize ){
        List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            //1、找到缺货订单
            Order orderCondition = new Order();
            orderCondition.setStatus(2);
            List<Order> orderList = iOrderService.getOrderByQuery(orderCondition);
            //2、找到对应调拨入库单
            //3、若无或有且调拨单数量等于条目数量但初始有actual，则记入返回list(map())中
            for (Order o:orderList) {
                DispatchingOrder dpoCondition = new DispatchingOrder();
                dpoCondition.setOrderId(o.getId());
                dpoCondition.setType("购货入库");
                List<DispatchingOrder> dispatchingOrderList = iDispatchingOrderService.getDispatchingOrderByQuery(dpoCondition);
                if (dispatchingOrderList.size()<o.getOrderItemList().size()){
                    List<OrderItem> orderItemList = o.getOrderItemList();
                    for (OrderItem orderItem:orderItemList){
                        int bj=0;
                        for (DispatchingOrder d: dispatchingOrderList) {
                            if (orderItem.getProductId() == d.getProductId()){
                                bj=1;
                            }
                        }
                        if (bj==1)
                            continue;
                        int key = orderItem.getProductId();
                        int value = orderItem.getNum();
                        Map<String, Object> m = new HashMap<String, Object>();
                        Product p = (Product) iProductService.getProductById(key).get("product");
                        SecondProduct sp = (SecondProduct) iSecondProductService.getSecondProductById(p.getSecondProductId()).get("secondProduct");
                        FirstProduct fp = iFirstProductService.getFirstProductById(sp.getFirstProductId());
                        m.put("productId", key);
                        m.put("productNum", value);
                        m.put("productName", p.getName());
                        m.put("unit", p.getUnit());
                        m.put("firstProductName", fp.getName());
                        m.put("secondProductName", sp.getName());
                        m.put("date", DateUtil.getCurrentDateToString("yyyy-MM-dd HH:mm:ss"));
                        m.put("orderId", o.getId());
                        returnList.add(m);
                    }
                }else{
                    for (DispatchingOrder dpo:dispatchingOrderList){
                        if (dpo.getActualNum()!=0&&dpo.getStatus().equals("初始状态")){
                            int key = dpo.getProductId();
                            int value = dpo.getProductNum()-dpo.getActualNum();
                            Map<String,Object> m = new HashMap<String,Object>();
                            Product p = (Product)iProductService.getProductById(key).get("product");
                            SecondProduct sp = (SecondProduct) iSecondProductService.getSecondProductById(p.getSecondProductId()).get("secondProduct");
                            FirstProduct fp = iFirstProductService.getFirstProductById(sp.getFirstProductId());
                            m.put("productId",key);
                            m.put("productNum",value);
                            m.put("productName",p.getName());
                            m.put("unit",p.getUnit());
                            m.put("firstProductName",fp.getName());
                            m.put("secondProductName",sp.getName());
                            m.put("date",DateUtil.getCurrentDateToString("yyyy-MM-dd HH:mm:ss"));
                            m.put("orderId",o.getId());
                            returnList.add(m);
                            dpo.setStatus("已完成状态");
                            iDispatchingOrderService.updateDispatchingOrderById(dpo);
                        }
                    }
                }
            }
            PageHelper.startPage(pageNum,pageSize);
            PageInfo<Map<String,Object>> pageInfo =new PageInfo<>(returnList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(pageInfo);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getLackItemByOrder 缺货进货>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getLackItemByWarning")
    @ResponseBody
    public HttpResponseEntity getLackItemByWarning(@RequestParam("pageNum") Integer pageNum,@RequestParam("PageSize") Integer pageSize ){
        //1、遍历中心库房库存，找unallocated+buffer《warning的
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            Map<Integer,Integer> map = new HashMap<Integer,Integer>();
            Store centerStore = iStoreService.getStoreById(1);
            Map<Integer,StoreItem> itemMap = centerStore.getItemMap();
            Set<Integer> itemkeySet = itemMap.keySet();
            for (Integer itemKey:itemkeySet){
                StoreItem storeItem = JSON.parseObject(JSON.toJSONString(itemMap.get(itemKey)),StoreItem.class);
                if (storeItem.getUnallocatedNum()+storeItem.getBufferNum()<storeItem.getWarningNum()){
                    map.put(itemKey,storeItem.getWarningNum()-storeItem.getUnallocatedNum()-storeItem.getBufferNum());
                }
            }
            List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
            Set<Integer> keySet = map.keySet();
            for (Integer key: keySet){
                Map<String,Object> m = new HashMap<String,Object>();
                Product p = (Product)iProductService.getProductById(key).get("product");
                SecondProduct sp = (SecondProduct) iSecondProductService.getSecondProductById(p.getSecondProductId()).get("secondProduct");
                FirstProduct fp = iFirstProductService.getFirstProductById(sp.getFirstProductId());
                m.put("productId",key);
                m.put("productNum",map.get(key));
                m.put("productName",p.getName());
                m.put("unit",p.getUnit());
                m.put("firstProductName",fp.getName());
                m.put("secondProductName",sp.getName());
                m.put("date",DateUtil.getCurrentDateToString("yyyy-MM-dd HH:mm:ss"));
                returnList.add(m);
            }
            System.out.println("............................"+returnList);
            PageHelper.startPage(pageNum,pageSize);
            PageInfo<Map<String,Object>> pageInfo =new PageInfo<>(returnList);

            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(pageInfo);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getLackItemByWarning 预警进货>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
