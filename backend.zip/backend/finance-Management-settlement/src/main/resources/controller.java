package com.neusoft;

import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Receipt;
import com.neusoft.service.IDispatchingOrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

public class controller {
    @Controller
    @CrossOrigin
    @RequestMapping("/settlement")
    public static class settlementController {
        private final Logger logger = LoggerFactory.getLogger(settlementController.class);

        @Autowired
        private IDispatchingOrderService iDispatchingOrderService;

        @RequestMapping(value = "/settlementWithSupplier")
        @ResponseBody
        public HttpResponseEntity settlementWithSupplier(@RequestBody Receipt Receipt){
            HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
            try {

                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
            }catch (Exception e){
                logger.info("addReceipt 添加配送员>>>>>>>>>>>" + e.getLocalizedMessage());
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
            }
            return httpResponseEntity;
        }
    }
}
