package com.neusoft.common;

public class Constans {

    public static final String SUCCESS_CODE = "666"; //成功状态码
    public static final String EXIST_CODE = "20001"; //失败状态码

    public static final String EXIST_MESSAGE="系统异常";
    public static final String DELETE_MESSAGE="删除成功";

    public static final String SUSPEND_MESSAGE="状态修改成功";
    public static final String UPDATE_MESSAGE="修改成功";

    public static final String GROUP_MESSAGE="有数据关联，无法进行操作";

    public static final String PHONE_MESSAGE="手机号未注册";
    public static final String ADD_MESSAGE="添加成功";

    public  static final String REGISTER_MESSAGE="注册成功";

    public static  final String SENDCODE_MESSAGE="发送成功";
    public static final String STATUS_MESSAGE="查询成功";
    public static final String MAKE_MESSAGE="设置成功";
    public static final String MAKE_ERROR="设置成功";

    /**
     * Descriptions:供应商状态码
     */

    public static final String MESSAGE_NULL="此供应商不存在";


    /**
     * Descriptions:定时任务状态码
     */
    public static final String SCHEDULE_NAME_NO_FOUND = "没有找到接口名";

    /**
     * Descriptions:参数状态码
     */
    public static final String PARAMETER_NO_DELETE= "系统配置不可删除";

    /**
     * Descriptions:模块状态码
     */
    public static final String MODEL_EXIST_CODE = "222";
    public static final String MODEL_SORT_EXIT= "此模块已存在此排序值";
    public static final String MODEL_SORT_NULL="模块的排序不能为空";
    public static final String MODEL_PARENTID_FALSE="父id不符合模块设计规范";
    public static final String MODEL_DELETE_FAIL="删除失败";
    public static final String MODEL_NO_PATH_PERMISSION="权限管理找不到模块的路径";
    public static final String MODEL_NO_PATH="找不到模块信息";

    public static final String GROUPNAME_CODE = "60001";
    public static final String GROUPNAME_MESSAGE = "群组名已存在";

}
