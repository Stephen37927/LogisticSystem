package com.neusoft.controller;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.Items;
import com.neusoft.common.utils.DateUtil;
import com.neusoft.dao.IProductDao;
import com.neusoft.entity.DispatchingOrder;
import com.neusoft.entity.Product;
import com.neusoft.service.IDispatchingOrderService;
import org.apache.commons.collections.IterableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

public class settlementcontroller {

    /**
     * 传参数：supplierId，两个时间段
     * @author Sq
     * @date 2023/7/19
     */

    @Controller
    @CrossOrigin
    @RequestMapping("/settlement")
    public static class settlementController {
        private final Logger logger = LoggerFactory.getLogger(settlementController.class);

        @Autowired
        private IDispatchingOrderService iDispatchingOrderService;

        @Autowired
        private IProductDao iProductDao;

        @RequestMapping(value = "/settlementWithSupplier")
        @ResponseBody
        public HttpResponseEntity settlementWithSupplier(@RequestBody HashMap<String,Object>map){
            HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
            try {
                int supplierId = JSON.parseObject(JSON.toJSONString(map.get("supplierId")),Integer.class);
                Date startDate = DateUtil.stringToDate((String) map.get("startDate"),"yyyy-MM-dd HH:mm:ss");
                Date finishDate = DateUtil.stringToDate((String) map.get("finishDate"),"yyyy-MM-dd HH:mm:ss");
                List<Map<String,Object>> returnMap = new ArrayList<>();//每一个map里面有一个product，map：productid，tuihui，供货数量

                DispatchingOrder dispatchingOrder = new DispatchingOrder();
                dispatchingOrder.setType("购货入库");
                dispatchingOrder.setStartDate(startDate);
                dispatchingOrder.setFinishDate(finishDate);
                List<DispatchingOrder> dispatchingSellingOrderList = iDispatchingOrderService.getDispatchingOrderByQuery(dispatchingOrder);
                List<DispatchingOrder> dispatchingSellingOrderListSelected = new ArrayList<>();

                dispatchingOrder.setType("中心出库");
                dispatchingOrder.setStartDate(startDate);
                dispatchingOrder.setFinishDate(finishDate);
                List<DispatchingOrder> dispatchingBackingOrderList = iDispatchingOrderService.getDispatchingOrderByQuery(dispatchingOrder);
                List<DispatchingOrder> dispatchingBackingOrderListSelected = new ArrayList<>();

                //筛选出供应商的条件
                for (DispatchingOrder dors: dispatchingBackingOrderList){
                    Product product = iProductDao.getProductById(dors.getProductId());
                    int supplierId2 = product.getSupplierId();
                    if(supplierId2 == supplierId){
                        dispatchingBackingOrderListSelected.add(dors);
                    }
                }
                //筛选出供应商的条件
                for (DispatchingOrder dors: dispatchingSellingOrderList){
                    Product product = iProductDao.getProductById(dors.getProductId());
                    int supplierId2 = product.getSupplierId();
                    if(supplierId2 == supplierId){
                        dispatchingSellingOrderListSelected.add(dors);
                    }
                }

                //用map<int,Items>承接
                Map<Integer, Items> map1 =  new HashMap<>();

                for (DispatchingOrder dors : dispatchingSellingOrderListSelected){
                    Product product = iProductDao.getProductById(dors.getProductId());
                    Items items = JSON.parseObject(JSON.toJSONString(map1.get(product.getId())),Items.class);
                    System.out.println(items);
                    if(items != null){
                        items.setInNum(items.getInNum()+dors.getActualNum());
                        items.setInPrice(items.getInPrice()+(dors.getActualNum()*product.getCostPrice()));
                        map1.put(product.getId(),items);
                    }else{
                        System.out.println(items);
                        int num = dors.getActualNum();
                        if (items == null)
                            items = new Items();
                        items.setInNum(num);
                        items.setInPrice(dors.getActualNum()*product.getCostPrice());
                        map1.put(product.getId(),items);
                    }
                }

                for (DispatchingOrder dors : dispatchingBackingOrderListSelected){
                    Product product = iProductDao.getProductById(dors.getProductId());
                    Items items = JSON.parseObject(JSON.toJSONString(map1.get(product.getId())),Items.class);
                    if(items.getOutNum() != 0){
                        items.setOutNum(items.getOutNum()+dors.getProductNum());
                        items.setOutPrice(items.getOutPrice()+(dors.getProductNum()*product.getCostPrice()));
                        map1.put(product.getId(),items);
                    }else{
                        if (items == null)
                            items = new Items();
                        items.setOutNum(dors.getProductNum());
                        items.setOutPrice(dors.getProductNum()*product.getCostPrice());
                        map1.put(product.getId(),items);
                    }
                }

                Set<Integer> keySet = map1.keySet();
                for (Integer key: keySet){
                    Product product = iProductDao.getProductById(key);
                    System.out.println(product);
                    Map<String,Object> m = new HashMap<String,Object>();
                    Items items = map1.get(key);
                    items.setSNum(items.getInNum()-items.getOutNum());
                    items.setSPrice(items.getInPrice()-items.getOutPrice());
                    m.put("product", product);
                    m.put("details", items);
                    returnMap.add(m);
                }
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(returnMap);
                httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
            }catch (Exception e){
                logger.info("addReceipt 添加配送员>>>>>>>>>>>" + e.getLocalizedMessage());
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
            }
            return httpResponseEntity;
        }
    }
}
