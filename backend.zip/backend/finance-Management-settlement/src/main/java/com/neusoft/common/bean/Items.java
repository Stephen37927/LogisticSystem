package com.neusoft.common.bean;


import lombok.Data;

@Data
public class Items {
    private int inNum;
    private int outNum;
    private int sNum;
    private double inPrice;
    private double outPrice;
    private double sPrice;
}
