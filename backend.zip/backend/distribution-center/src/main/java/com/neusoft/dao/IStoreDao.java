package com.neusoft.dao;

import com.neusoft.entity.Store;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IStoreDao {
    Store getStoreById(int id);//根据id获取库房

    void addStore(Store store);//增加库房

    List<Store> getStoreList();//获取库房列表

    void deleteStoreById(int id);//根据id删除库房

    void updateStoreById(Store store);//根据id更新库房

    List<Store> getStoreByQuery(Store store);//库房综合查询

    int getMaxId();
}
