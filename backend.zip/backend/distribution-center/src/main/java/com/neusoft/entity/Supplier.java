package com.neusoft.entity;

import lombok.Data;

@Data
public class Supplier {
    private int id;
    private String name;
    private String address;
    private String linkman;
    private String phone;
    private String bank;
    private String bankAccount;
    private String legalPerson;
    private String fax;
    private String postcode;
    private String comment;
}
