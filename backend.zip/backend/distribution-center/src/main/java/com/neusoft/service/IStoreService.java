package com.neusoft.service;

import com.neusoft.common.bean.StoreItem;
import com.neusoft.entity.Product;
import com.neusoft.entity.Store;

import java.util.List;
import java.util.Map;

public interface IStoreService {

    void addStore(Store store);
    List<Store> getStoreList();

    void deleteStoreById(int id);

    Store getStoreById(int id);

    void updateStoreById(Store store);

    List<Store> getStoreByQuery(Store store);

    List<Map<String,Object>> getItemListByQuery(int storeId, Product product);

    Map<String,Object> getItemByProductId(int storeId,int productId);

    void updateItemByProductId(int storeId, int productId, StoreItem storeItem);
}
