package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IStoreDao;
import com.neusoft.entity.Product;
import com.neusoft.entity.Store;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class StoreServiceImpl implements IStoreService {

    private static final String Cache_Key_Id = "storeid:";
    private static final String Cache_Key_List = "storelist";

    @Autowired
    private IProductService iProductService;

    @Autowired
    private IStoreDao iStoreDao;
    @Autowired
    private RedisUtil redisUtil;



    @Override
    public void addStore(Store store) {
        store.setItemMapString(JSON.toJSONString(store.getItemMap()));
        System.out.println("______"+store);
        iStoreDao.addStore(store);

        int maxid = iStoreDao.getMaxId();
        store.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,store,100);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public List<Store> getStoreList() {
        List<Store> storeListRedis = (List<Store>)redisUtil.get(Cache_Key_List);
        if (storeListRedis != null){
            for (Store s:storeListRedis){
                Map m = JSON.parseObject(s.getItemMapString(),Map.class);
                s.setItemMap(m);
            }
            System.out.println("list存在redis");
            return storeListRedis;
        }

        System.out.println("list不存在redis");
        List<Store> storeList = iStoreDao.getStoreList();
        redisUtil.setex(Cache_Key_List,storeList,100);
        for (Store s:storeList){
            s.setItemMap(JSON.parseObject(s.getItemMapString(),Map.class));
        }
        return storeList;
    }

    @Override
    public void deleteStoreById(int id) {
        iStoreDao.deleteStoreById(id);


        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Store getStoreById(int id) {
        String key = Cache_Key_Id + id;
        Store storeRedis = (Store) redisUtil.get(key);
        if (storeRedis != null){
            System.out.println("id存在redis");
            storeRedis.setItemMap(JSON.parseObject(storeRedis.getItemMapString(),Map.class));
            return storeRedis;
        }

        System.out.println("id不存在redis");
        Store store = iStoreDao.getStoreById(id);
        redisUtil.setex(key,store,100);
        store.setItemMap(JSON.parseObject(store.getItemMapString(),Map.class));
        return store;
    }

    @Override
    public void updateStoreById(Store store) {
        store.setItemMapString(JSON.toJSONString(store.getItemMap()));
        System.out.println(store);
        iStoreDao.updateStoreById(store);
        System.out.println("___"+store);

        Store store1 = iStoreDao.getStoreById(store.getId());
        String key = Cache_Key_Id + store.getId();
        redisUtil.setex(key,store1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Store> getStoreByQuery(Store store) {
        List<Store> storeList = iStoreDao.getStoreByQuery(store);
        for (Store s:storeList){
            s.setItemMap(JSON.parseObject(s.getItemMapString(),Map.class));
        }
        return storeList;
    }

    @Override
    public List<Map<String, Object>> getItemListByQuery(int storeId, Product product) {
        Store store = getStoreById(storeId);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        List<Map<String,Object>> productList = iProductService.getProductByQuery(product);
        Map<Integer,StoreItem> map = store.getItemMap();
        for (Map<String,Object> p : productList){
            Map<String, Object> pmap = new HashMap<String, Object>();
            if (map.get(((Product)p.get("product")).getId())==null){
                pmap.put("product",p);
                StoreItem storeItem = new StoreItem();
                pmap.put("storeItem",storeItem);
            }else{
                pmap.put("product",p);
                pmap.put("storeItem",map.get(((Product)p.get("product")).getId()));
            }
            list.add(pmap);
        }
        return list;
    }

    @Override
    public Map<String, Object> getItemByProductId(int storeId, int productId) {
        Store store = getStoreById(storeId);
        Map<String, Object> returnMap = new HashMap<String, Object>();
        Product product = (Product)iProductService.getProductById(productId).get("product");
        Map<Integer,StoreItem> map = store.getItemMap();
        if (map.get(productId)==null){
            returnMap.put("product",product);
            StoreItem storeItem = new StoreItem();
            returnMap.put("storeItem",storeItem);
        }else{
            returnMap.put("product",product);
            returnMap.put("storeItem",map.get(productId));
        }
        return returnMap;
    }

    @Override
    public void updateItemByProductId(int storeId, int productId, StoreItem storeItem) {
        Store store = getStoreById(storeId);
        Map<Integer,StoreItem> map = store.getItemMap();
        map.put(productId,storeItem);
        store.setItemMap(map);
        updateStoreById(store);
    }

}
