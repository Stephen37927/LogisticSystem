package com.neusoft.service;

import com.neusoft.entity.FirstProduct;

import java.util.List;

public interface IFirstProductService {
    void addFirstProduct(FirstProduct firstProduct);
    FirstProduct getFirstProductById(int id);
    void deleteFirstProductById(int id);
    void updateFirstProductById(FirstProduct firstProduct);

    List<FirstProduct> getAllFirstProduct();

    List<FirstProduct> getFirstProductByQuery(FirstProduct firstProduct);
}
