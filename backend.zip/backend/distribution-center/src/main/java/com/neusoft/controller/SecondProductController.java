package com.neusoft.controller;

import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.PageResult;
import com.neusoft.entity.SecondProduct;
import com.neusoft.service.ISecondProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("secondproduct")
public class SecondProductController {
    private final Logger logger = LoggerFactory.getLogger(ProductController.class);
    @Autowired
    private ISecondProductService iSecondProductService;

    @RequestMapping(value = "addSecondProduct")
    @ResponseBody
    public HttpResponseEntity addSecondProduct(@RequestBody SecondProduct secondProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            iSecondProductService.addSecondProduct(secondProduct);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addSecondProduct 添加产品>>>>>>>" + e.getLocalizedMessage()) ;
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setCode(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "getSecondProductById/{id}")
    @ResponseBody
    public HttpResponseEntity getSecondProductById(@PathVariable("id") int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            Map<String,Object> secondProduct = iSecondProductService.getSecondProductById(id);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(secondProduct);
        }catch (Exception e){
            logger.info("getSecondProductById 根据id获取二级类>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "deleteSecondProductById")
    @ResponseBody
    public HttpResponseEntity deleteSecondProductById(@RequestBody SecondProduct secondProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if(iSecondProductService.getSecondProductById(secondProduct.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSecondProductService.deleteSecondProductById(secondProduct.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteProductById 依法删除产品>>>>>>");
        }

        return httpResponseEntity;
    }

    @RequestMapping(value = "updateSecondProductById")
    @ResponseBody
    public HttpResponseEntity updateSecondProductById(@RequestBody SecondProduct secondProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if (iSecondProductService.getSecondProductById(secondProduct.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSecondProductService.updateSecondProductById(secondProduct);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateFirstProductById 按 ID 更新产品>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "getAllSecondProduct")
    @ResponseBody
    public HttpResponseEntity getAllSecondProduct(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            List<SecondProduct> secondProductList = iSecondProductService.getAllSecondProduct();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(secondProductList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllFirstProduct 查询所有一级类>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "getSecondProductByQuery")
    @ResponseBody
    public HttpResponseEntity getSecondProductByQuery(@RequestBody SecondProduct secondProduct, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {

            List<Map<String,Object>> secondProductList = iSecondProductService.getSecondProductByQuery(secondProduct);
            int totalItems = secondProductList.size();
            if (totalItems > pageSize) {
                int toIndex = pageSize * pageNum;
                if (toIndex > totalItems) {
                    toIndex = totalItems;
                }
                secondProductList = secondProductList.subList(pageSize * (pageNum - 1), toIndex);
            }
            PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,secondProductList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(pageResult);
        }catch (Exception e){
            logger.info("getSecondProductByQuery 根据查询条件获取二级类>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
