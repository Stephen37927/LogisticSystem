package com.neusoft.common.bean;

import lombok.Data;

@Data
public class StoreItem {
    private int backNum;
    private int unallocatedNum;
    private int allocatedNum;
    private int warningNum;
    private int maxNum;
    private int defectiveNum;
    private int bufferNum;
}
