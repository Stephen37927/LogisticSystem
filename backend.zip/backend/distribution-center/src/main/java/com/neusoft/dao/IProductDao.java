package com.neusoft.dao;

import com.neusoft.entity.Product;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper

public interface IProductDao {
    void addProduct(Product product);
    Product getProductById(int id);
    void deleteProductById(int id);
    void updateProductById(Product product);

    List<Product> getAllProduct();

    List<Product> getProductByQuery(Product product);

    int getMaxId();
}
