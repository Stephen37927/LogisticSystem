package com.neusoft.entity;

import lombok.Data;

@Data
public class SecondProduct {
    private int id;
    private String name;
    private String description;
    private int firstProductId;
}
