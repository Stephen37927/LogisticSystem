package com.neusoft.service;

import com.neusoft.entity.Supplier;

import java.util.List;
import java.util.Map;

public interface ISupplierService {

    void addSupplier(Supplier supplier);
    List<Supplier> getSupplierList();

    void deleteSupplierById(int id);

    Supplier getSupplierById(int id);

    void updateSupplierById(Supplier supplier);

    List<Supplier> getSupplierByQuery(Supplier supplier);
}
