package com.neusoft.service;

import com.neusoft.entity.Product;

import java.util.List;
import java.util.Map;

public interface IProductService {

    void addProduct(Product product);
    Map<String,Object> getProductById(int id);
    void deleteProductById(int id);
    void updateProductById(Product product);

    List<Product> getAllProduct();

    List<Map<String,Object>> getProductByQuery(Product product);

    void deleteProductBySecondId(int id);
}
