package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.FirstProduct;
import com.neusoft.service.IFirstProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("firstproduct")
public class FirstProductController {

    private final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IFirstProductService iFirstProductService;

    @RequestMapping(value = "addFirstProduct")
    @ResponseBody
    public HttpResponseEntity addFirstProduct(@RequestBody FirstProduct firstProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            iFirstProductService.addFirstProduct(firstProduct);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addfirstProduct 添加产品>>>>>>>" + e.getLocalizedMessage()) ;
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setCode(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "getFirstProductById/{id}")
    @ResponseBody
    public HttpResponseEntity getFirstProductById(@PathVariable("id") int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            FirstProduct firstProduct = iFirstProductService.getFirstProductById(id);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(firstProduct);
        }catch (Exception e){
            logger.info("getFirstProductById 根据id获取一级类>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "deleteFirstProductById")
    @ResponseBody
    public HttpResponseEntity deleteFirstProductById(@RequestBody FirstProduct firstProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if(iFirstProductService.getFirstProductById(firstProduct.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iFirstProductService.deleteFirstProductById(firstProduct.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteProductById 依法删除产品>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }

        return httpResponseEntity;
    }
    @RequestMapping(value = "updateFirstProductById")
    @ResponseBody
    public HttpResponseEntity updateFirstProductById(@RequestBody FirstProduct firstProduct){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            if (iFirstProductService.getFirstProductById(firstProduct.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iFirstProductService.updateFirstProductById(firstProduct);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateFirstProductById 按 ID 更新一级产品>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "getAllFirstProduct")
    @ResponseBody
    public HttpResponseEntity getAllFirstProduct(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
                List<FirstProduct> firstProductList = iFirstProductService.getAllFirstProduct();
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(firstProductList);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllFirstProduct 查询所有一级类>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "getFirstProductByQuery")
    @ResponseBody
    public HttpResponseEntity getFirstProductByQuery(@RequestBody FirstProduct firstProduct,@RequestParam("pageNum") Integer pageNum,@RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            PageHelper.startPage(pageNum,pageSize);
            List<FirstProduct> firstProductList = iFirstProductService.getFirstProductByQuery(firstProduct);
            PageInfo<FirstProduct> pageInfo = new PageInfo<>(firstProductList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(pageInfo);
        }catch (Exception e){
            logger.info("getFirstProductByQuery 根据查询条件获取一级类>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
