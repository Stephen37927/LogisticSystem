package com.neusoft.dao;


import com.neusoft.entity.FirstProduct;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper

public interface IFirstProductDao {
    void addFirstProduct(FirstProduct firstProduct);
    FirstProduct getFirstProductById(int id);
    void deleteFirstProductById(int id);

    void updateFirstProductById(FirstProduct firstProduct);

    List<FirstProduct> getAllFirstProduct();

    List<FirstProduct> getFirstProductByQuery(FirstProduct firstProduct);
    int getMaxId();
}
