package com.neusoft.entity;

import lombok.Data;

@Data
public class FirstProduct {
    private int id;
    private String name;
    private String description;
}
