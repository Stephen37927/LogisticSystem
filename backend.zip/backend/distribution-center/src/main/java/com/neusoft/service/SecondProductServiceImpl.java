package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ISecondProductDao;
import com.neusoft.entity.Product;
import com.neusoft.entity.SecondProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SecondProductServiceImpl implements ISecondProductService{

    private static final String Cache_Key_Id = "secondproductid:";
    private static final String Cache_Key_List = "secondproductlist";

    @Autowired
    private IFirstProductService iFirstProductService;
    @Autowired
    private ISecondProductDao iSecondProductDao;

    @Autowired
    private  IProductService iProductService;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public void addSecondProduct(SecondProduct secondProduct) {
        iSecondProductDao.addSecondProduct(secondProduct);

        int maxid = iSecondProductDao.getMaxId();
        secondProduct.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,secondProduct,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Map<String,Object> getSecondProductById(int id) {
        String key = Cache_Key_Id + id;
        SecondProduct secondProductRedis = (SecondProduct)redisUtil.get(key);
        if(secondProductRedis != null){
            System.out.println("id exist redis>>>>id存在redis");
            Map<String,Object> m = new HashMap<>();
            m.put("firstProduct",iFirstProductService.getFirstProductById(secondProductRedis.getFirstProductId()));
            m.put("secondProduct",secondProductRedis);
            return m;
        }
        System.out.println("id doesnot exist redis>>>>id不存在redis ");
        SecondProduct secondProduct = iSecondProductDao.getSecondProductById(id);
        redisUtil.setex(key,secondProduct,100);
        Map<String,Object> m = new HashMap<>();
        m.put("firstProduct",iFirstProductService.getFirstProductById(secondProduct.getFirstProductId()));
        m.put("secondProduct",secondProduct);
        return m;
//        return iSecondProductDao.getSecondProductById(id);
    }

    @Override
    public void deleteSecondProductById(int id) {
        SecondProduct secondProduct = (SecondProduct) getSecondProductById(id).get("secondProduct");
        iSecondProductDao.deleteSecondProductById(id);
        iProductService.deleteProductBySecondId(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateSecondProductById(SecondProduct secondProduct) {
        iSecondProductDao.updateSecondProductById(secondProduct);

        SecondProduct secondProduct1 = iSecondProductDao.getSecondProductById(secondProduct.getId());
        String key = Cache_Key_Id + secondProduct.getId();
        redisUtil.setex(key,secondProduct1,100);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public List<SecondProduct> getAllSecondProduct() {
        List<SecondProduct> secondProductList = (List<SecondProduct>) redisUtil.get(Cache_Key_List);
        if (secondProductList != null){
            System.out.println("The list exists redis>>>list存在redis");
            return secondProductList;
        }
        System.out.println("The list doesn't exist redis>>>list不存在redis");
        List<SecondProduct> secondProductlist = iSecondProductDao.getAllSecondProduct();
        redisUtil.setex(Cache_Key_List,secondProductlist,100);
        return secondProductlist;
    }

    @Override
    public List<Map<String,Object>> getSecondProductByQuery(SecondProduct secondProduct) {
        List<SecondProduct> secondProductList = iSecondProductDao.getSecondProductByQuery(secondProduct);
        List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
        for (SecondProduct s:secondProductList){
            Map<String,Object> m = new HashMap<>();
            m.put("firstProduct",iFirstProductService.getFirstProductById(s.getFirstProductId()));
            m.put("secondProduct",s);
            returnList.add(m);
        }
        return returnList;
    }

    @Override
    public void deleteSecondProductByFirstId(int id) {

        SecondProduct secondProduct = new SecondProduct();
        secondProduct.setFirstProductId(id);
        List<Map<String, Object>> secondProductList = getSecondProductByQuery(secondProduct);
        for (Map<String,Object> map:secondProductList){
            SecondProduct secondProduct1 = JSON.parseObject(JSON.toJSONString(map.get("secondProduct")), SecondProduct.class);
            int id2 = secondProduct1.getId();
            deleteSecondProductById(id2);
        }

    }
}
