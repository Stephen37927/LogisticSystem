package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ISupplierDao;
import com.neusoft.entity.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SupplierServiceImpl implements ISupplierService{

    private static final String Cache_Key_Id = "supplierid:";
    private static final String Cache_Key_List = "supplierlist";

    @Autowired
    private ISupplierDao iSupplierDao;
    @Autowired
    private RedisUtil redisUtil;



    @Override
    public void addSupplier(Supplier supplier) {
        iSupplierDao.addSupplier(supplier);

        int maxid = iSupplierDao.getMaxId();
        supplier.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,supplier,100);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public List<Supplier> getSupplierList() {
        List<Supplier> supplierListRedis = (List<Supplier>)redisUtil.get(Cache_Key_List);
        if (supplierListRedis != null){
            System.out.println("list存在redis");
            return supplierListRedis;
        }

        System.out.println("list不存在redis");
        List<Supplier> supplierList = iSupplierDao.getSupplierList();
        redisUtil.setex(Cache_Key_List,supplierList,100);
        return supplierList;
    }

    @Override
    public void deleteSupplierById(int id) {
        Supplier supplier = getSupplierById(id);
        iSupplierDao.deleteSupplierById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Supplier getSupplierById(int id) {
        String key = Cache_Key_Id + id;
        Supplier supplierRedis = (Supplier)redisUtil.get(key);
        if (supplierRedis != null){
            System.out.println("id存在redis");

        }

        System.out.println("id不存在redis");
        Supplier supplier = iSupplierDao.getSupplierById(id);
        redisUtil.setex(key,supplier,100);
        return supplier;
    }

    @Override
    public void updateSupplierById(Supplier supplier) {
        iSupplierDao.updateSupplierById(supplier);

        Supplier supplier1 = iSupplierDao.getSupplierById(supplier.getId());
        String key = Cache_Key_Id + supplier.getId();
        redisUtil.setex(key,supplier1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Supplier> getSupplierByQuery(Supplier supplier) {

        List<Supplier> list = iSupplierDao.getSupplierByQuery(supplier);
        return list;
    }


}
