package com.neusoft.entity;

import lombok.Data;

@Data
public class Product {
    private int id;
    private String name;
    private String description;
    private int firstProductId;
    private int secondProductId;
    private String unit;
    private double sellingPrice;
    private double discount;
    private double costPrice;
    private int supplierId;
    private int shelfLife;
    private boolean canReturn;
    private boolean canExchange;
}
