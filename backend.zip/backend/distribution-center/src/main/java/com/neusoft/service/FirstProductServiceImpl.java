package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IFirstProductDao;
import com.neusoft.entity.FirstProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FirstProductServiceImpl implements IFirstProductService{

    private static final String Cache_Key_Id = "firstproductid:";
    private static final String Cache_Key_List = "firstproductlist";

    @Autowired
    private IFirstProductDao iFirstProductDao;

    @Autowired
    private ISecondProductService iSecondProductService;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public void addFirstProduct(FirstProduct firstProduct) {
        iFirstProductDao.addFirstProduct(firstProduct);

        int maxid = iFirstProductDao.getMaxId();
        firstProduct.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,firstProduct,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public FirstProduct getFirstProductById(int id) {
        String key = Cache_Key_Id + id;
        FirstProduct firstProductRedis = (FirstProduct)redisUtil.get(key);
        if(firstProductRedis != null){
            System.out.println("id exist redis>>>>id存在redis");
            return firstProductRedis;
        }
        System.out.println("id doesnot exist redis>>>>id不存在redis ");
        FirstProduct firstProduct = iFirstProductDao.getFirstProductById(id);
        redisUtil.setex(key,firstProduct,100);
        return firstProduct;

//        return iFirstProductDao.getFirstProductById(id);
    }

    @Override
    public void deleteFirstProductById(int id) {
        FirstProduct firstProduct = getFirstProductById(id);
        iFirstProductDao.deleteFirstProductById(id);
        iSecondProductService.deleteSecondProductByFirstId(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateFirstProductById(FirstProduct firstProduct) {
        iFirstProductDao.updateFirstProductById(firstProduct);

        FirstProduct firstProduct1 = iFirstProductDao.getFirstProductById(firstProduct.getId());
        String key = Cache_Key_Id + firstProduct.getId();
        redisUtil.setex(key,firstProduct1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<FirstProduct> getAllFirstProduct() {
        List<FirstProduct> firstProductList = (List<FirstProduct>) redisUtil.get(Cache_Key_List);
        if(firstProductList != null){
            System.out.println("The list exists redis>>>list存在redis");
            return firstProductList;
        }
        System.out.println("The list doesn't exist redis>>>list不存在redis");
        List<FirstProduct> firstProductlist = iFirstProductDao.getAllFirstProduct();
        redisUtil.setex(Cache_Key_List,firstProductlist,100);
        return firstProductlist;
    }

    @Override
    public List<FirstProduct> getFirstProductByQuery(FirstProduct firstProduct) {
        List <FirstProduct> firstProductList = iFirstProductDao.getFirstProductByQuery(firstProduct);
        return firstProductList;
    }
}
