package com.neusoft.dao;

import com.neusoft.entity.Supplier;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ISupplierDao {
    Supplier getSupplierById(int id);//根据id获取供应商

    void addSupplier(Supplier supplier);//增加供应商

    List<Supplier> getSupplierList();//获取供应商列表

    void deleteSupplierById(int id);//根据id删除供应商

    void updateSupplierById(Supplier supplier);

    List<Supplier> getSupplierByQuery(Supplier supplier);

    int getMaxId();
}
