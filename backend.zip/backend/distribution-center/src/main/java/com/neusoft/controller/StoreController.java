package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.entity.Product;
import com.neusoft.entity.Store;
import com.neusoft.service.IStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/store")
public class
StoreController {

    private final Logger logger = LoggerFactory.getLogger(StoreController.class);
    @Autowired
    private IStoreService iStoreService;

    @RequestMapping(value = "/addStore")
    @ResponseBody
    public HttpResponseEntity addStore(@RequestBody Store store){
        System.out.println(store);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iStoreService.addStore(store);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addStore 添加库房>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllStore")
    @ResponseBody
    public HttpResponseEntity getAllStore(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Store> storeList = iStoreService.getStoreList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(storeList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllStore 查询所有库房>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteStore")
    @ResponseBody
    public HttpResponseEntity deleteStoreById(@RequestBody Store store){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreById(store.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iStoreService.deleteStoreById(store.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteStoreById 根据id删除库房>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getStoreById/{id}")
    @ResponseBody
    public HttpResponseEntity getStoreById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Store store1 = iStoreService.getStoreById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(store1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getStoreById 根据id查询库房>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getItemByProductId")
    @ResponseBody
    public HttpResponseEntity getItemByProductId(int storeId,int productId){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getItemByProductId(storeId,productId)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Map<String,Object> map = iStoreService.getItemByProductId(storeId,productId);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(map);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getItemByProductId 根据库房id和商品id查询条目>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateStoreById")
    @ResponseBody
    public HttpResponseEntity updateStoreById(@RequestBody Store store){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreById(store.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iStoreService.updateStoreById(store);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateStoreById 根据id修改库房>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getStoreByQuery")
    @ResponseBody
    public HttpResponseEntity getStoreByQuery(@RequestBody Store store, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreByQuery(store)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Store> storeList = iStoreService.getStoreByQuery(store);
                PageInfo<Store> pageInfo =new PageInfo<>(storeList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getStoreByQuery 根据query查询库房（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getItemListByQuery")
    @ResponseBody
    public HttpResponseEntity getItemListByQuery(@RequestBody Product product, @RequestParam int storeId, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreById(storeId)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Map<String, Object>> list = iStoreService.getItemListByQuery(storeId,product);
                PageInfo<Map<String, Object>> pageInfo =new PageInfo<>(list);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getItemListByQuery 根据商品query和库房id查询库存条目（支持商品名模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateItemByProductId")
    @ResponseBody
    public HttpResponseEntity updateItemByProductId(@RequestParam int storeId, @RequestParam int productId, @RequestBody StoreItem storeItem){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iStoreService.getStoreById(storeId)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iStoreService.updateItemByProductId(storeId,productId,storeItem);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateItemByProductId 根据库房和商品id修改添加条目>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

}
