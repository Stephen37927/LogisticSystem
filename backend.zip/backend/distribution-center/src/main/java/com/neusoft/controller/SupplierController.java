package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Supplier;
import com.neusoft.service.ISupplierService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/supplier")
public class SupplierController {

    private final Logger logger = LoggerFactory.getLogger(SupplierController.class);
    @Autowired
    private ISupplierService iSupplierService;

    @RequestMapping(value = "/addSupplier")
    @ResponseBody
    public HttpResponseEntity addSupplier(@RequestBody Supplier supplier){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iSupplierService.addSupplier(supplier);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addSupplier 添加供应商>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllSupplier")
    @ResponseBody
    public HttpResponseEntity getAllSupplier(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Supplier> supplierList = iSupplierService.getSupplierList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(supplierList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllSupplier 查询所有供应商>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteSupplier")
    @ResponseBody
    public HttpResponseEntity deleteSupplierById(@RequestBody Supplier supplier){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSupplierService.getSupplierById(supplier.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSupplierService.deleteSupplierById(supplier.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteSupplierById 根据id删除供应商>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getSupplierById/{id}")
    @ResponseBody
    public HttpResponseEntity getSupplierById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSupplierService.getSupplierById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Supplier supplier1 = iSupplierService.getSupplierById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(supplier1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSupplierById 根据id查询供应商>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateSupplierById")
    @ResponseBody
    public HttpResponseEntity updateSupplierById(@RequestBody Supplier supplier){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSupplierService.getSupplierById(supplier.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSupplierService.updateSupplierById(supplier);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
                logger.info("updateSupplierById 根据id修改供应商>>>>>>>>>>>" + e.getLocalizedMessage());
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getSupplierByQuery")
    @ResponseBody
    public HttpResponseEntity getSupplierByQuery(@RequestBody Supplier supplier,@RequestParam("pageNum") Integer pageNum,@RequestParam("PageSize") Integer pageSize ){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSupplierService.getSupplierByQuery(supplier)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Supplier> supplierList = iSupplierService.getSupplierByQuery(supplier);
                PageInfo<Supplier> pageInfo =new PageInfo<>(supplierList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSupplierByQuery 根据query查询供应商（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }



}
