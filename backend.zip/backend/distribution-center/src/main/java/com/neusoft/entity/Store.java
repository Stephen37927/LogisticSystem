package com.neusoft.entity;

import com.neusoft.common.bean.StoreItem;
import lombok.Data;

import java.util.Map;

@Data
public class Store {
    private int id;
    private String name;
    private String storeAddress;
    private String manager;
    private String stage;
    private Map<Integer,StoreItem> itemMap;//商品条目id的map
    private String itemMapString;
}
