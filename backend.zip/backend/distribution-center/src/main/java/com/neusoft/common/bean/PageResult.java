package com.neusoft.common.bean;

import lombok.Data;

import java.util.List;

@Data
public class PageResult<T> {
    private int pageNum;
    private int pageSize;
    private int totalPages;
    private int totalItems;
    private List<T> pageItems;

    public PageResult(int pageNum, int pageSize, int totalPages, int totalItems, List<T> pageItems) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.totalPages = totalPages;
        this.totalItems = totalItems;
        this.pageItems = pageItems;
    }
}
