package com.neusoft.service;

import com.neusoft.entity.SecondProduct;

import java.util.List;
import java.util.Map;


public interface ISecondProductService {
    void addSecondProduct(SecondProduct secondProduct);
    Map<String,Object> getSecondProductById(int id);
    void deleteSecondProductById(int id);
    void updateSecondProductById(SecondProduct secondProduct);

    List<SecondProduct> getAllSecondProduct();

    List<Map<String,Object>> getSecondProductByQuery(SecondProduct secondProduct);

    void deleteSecondProductByFirstId(int id);
}
