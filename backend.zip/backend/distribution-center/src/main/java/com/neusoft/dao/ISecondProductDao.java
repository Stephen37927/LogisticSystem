package com.neusoft.dao;

import com.neusoft.entity.SecondProduct;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface ISecondProductDao {
    void addSecondProduct(SecondProduct secondProduct);
    SecondProduct getSecondProductById(int id);
    void deleteSecondProductById(int id);
    void updateSecondProductById(SecondProduct secondProduct);

    List<SecondProduct> getAllSecondProduct();

    List<SecondProduct> getSecondProductByQuery(SecondProduct secondProduct);

    int getMaxId();
}
