package com.neusoft.controller;

import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.PageResult;
import com.neusoft.entity.Product;
import com.neusoft.service.IProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@Controller
@CrossOrigin
@RequestMapping("product")
public class ProductController {

    private final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductService iProductService;

    @RequestMapping(value = "addProduct")
    @ResponseBody
    public HttpResponseEntity addProduct(@RequestBody Product product){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try{
            iProductService.addProduct(product);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }
        catch (Exception e){
            logger.info("addProduct 添加产品>>>>>>>" + e.getLocalizedMessage()) ;
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setCode(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "deleteProduct")
    @ResponseBody
    public HttpResponseEntity deleteProductById(@RequestBody Product product){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iProductService.getProductById(product.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iProductService.deleteProductById(product.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }
        catch (Exception e){
            logger.info("deleteProductById 依法删除产品>>>>>>");
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "getProductById/{id}")
    @ResponseBody
    public HttpResponseEntity getProductById(@PathVariable("id") int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            Map<String,Object> product = iProductService.getProductById(id);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(product);
        }catch (Exception e){
            logger.info("getProductById 根据id获取商品>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "updateProductById")
    @ResponseBody
    public HttpResponseEntity updateProductById(@RequestBody Product product){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iProductService.getProductById(product.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else {
                iProductService.updateProductById(product);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateProductById 按 ID 更新产品>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }

        return httpResponseEntity;
    }
    @RequestMapping(value = "getAllProduct")
    @ResponseBody
    public HttpResponseEntity getAllProduct(){
        HttpResponseEntity httpResponseEntity =new HttpResponseEntity();
        try{
            List<Product> productList = iProductService.getAllProduct();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(productList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllProduct 查询所有一级类>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
    @RequestMapping(value = "getProductByQuery")
    @ResponseBody
    public HttpResponseEntity getProductByQuery(@RequestBody Product product, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Map<String, Object>> productList = iProductService.getProductByQuery(product);
            int totalItems = productList.size();
            if (totalItems > pageSize) {
                int toIndex = pageSize * pageNum;
                if (toIndex > totalItems) {
                    toIndex = totalItems;
                }
                productList = productList.subList(pageSize * (pageNum - 1), toIndex);
            }
            PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,productList);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            httpResponseEntity.setData(pageResult);
        }catch (Exception e){
            logger.info("getProductByQuery 根据查询条件获取商品>>>>>>");
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
