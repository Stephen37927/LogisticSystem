package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IProductDao;
import com.neusoft.entity.Product;
import com.neusoft.entity.SecondProduct;
import com.neusoft.entity.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements IProductService{

    private static final String Cache_Key_Id = "productid:";
    private static final String Cache_Key_List = "productlist";

    @Autowired
    private IFirstProductService iFirstProductService;

    @Autowired
    private ISecondProductService iSecondProductService;

    @Autowired
    private ISupplierService iSupplierService;
    @Autowired
    private IProductDao iProductDao;

    @Autowired
    private IStoreService iStoreService;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public void addProduct(Product product) {
        iProductDao.addProduct(product);
        int maxid = iProductDao.getMaxId();
        product.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,product,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Map<String,Object> getProductById(int id) {
        String key = Cache_Key_Id + id;
        Product productRedis = (Product)redisUtil.get(key);
        if(productRedis != null){
            System.out.println("id exist redis>>>>id存在redis");
            Map<String,Object> m = new HashMap<>();
            m.put("secondProduct",iSecondProductService.getSecondProductById(productRedis.getSecondProductId()));
            m.put("product",productRedis);
            return m;
        }
        System.out.println("id doesnot exist redis>>>>id不存在redis ");
        Product product = iProductDao.getProductById(id);
        redisUtil.setex(key,product,100);
        Map<String,Object> m = new HashMap<>();
        m.put("secondProduct",iSecondProductService.getSecondProductById(product.getSecondProductId()));
        m.put("product",product);
        return m;
    }

    @Override
    public void deleteProductById(int id) {
        Product product = (Product) getProductById(id).get("product");
        iProductDao.deleteProductById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateProductById(Product product) {
        iProductDao.updateProductById(product);

        Product product1 = iProductDao.getProductById(product.getId());
        String key = Cache_Key_Id + product.getId();
        redisUtil.setex(key,product1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Product> getAllProduct() {
        List<Product> productList = (List<Product>) redisUtil.get(Cache_Key_List);
        if (productList != null){
            System.out.println("The list exists redis>>>list存在redis");
            return productList;
        }
        System.out.println("The list doesn't exist redis>>>list不存在redis");
        List<Product> productList1 = iProductDao.getAllProduct();
        redisUtil.setex(Cache_Key_List,productList1,100);
        return productList1;
    }


    @Override
    public List<Map<String,Object>> getProductByQuery(Product product) {
        List<Product> productList = iProductDao.getProductByQuery(product);
        List<Map<String,Object>> returnList = new ArrayList<Map<String,Object>>();
        for (Product p:productList){
            Map<String,Object> m = new HashMap<>();
            Map<String,Object> m2 = iStoreService.getItemByProductId(1,p.getId());
            StoreItem storeItem =  JSON.parseObject(JSON.toJSONString(m2.get("storeItem")),StoreItem.class);
            Supplier supplier = iSupplierService.getSupplierById(p.getSupplierId());
            m.put("supplier",supplier);
            m.put("firstProduct",iFirstProductService.getFirstProductById(p.getFirstProductId()));
            m.put("secondProduct",(SecondProduct)iSecondProductService.getSecondProductById(p.getSecondProductId()).get("secondProduct"));
            m.put("product",p);
            m.put("supplier",iSupplierService.getSupplierById(p.getSupplierId()));
            m.put("storeItem",storeItem);
            returnList.add(m);
        }
        return returnList;
    }

    @Override
    public void deleteProductBySecondId(int id) {
        Product product = new Product();
        product.setSecondProductId(id);
        List<Map<String, Object>> productList = getProductByQuery(product);
        for (Map<String,Object> map:productList){
            Product product1 = JSON.parseObject(JSON.toJSONString(map.get("product")),Product.class);
            int id2 = product1.getId();
            deleteProductById(id2);
        }
    }


}
