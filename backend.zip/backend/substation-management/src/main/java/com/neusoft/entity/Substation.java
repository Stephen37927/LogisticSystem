package com.neusoft.entity;

import lombok.Data;

@Data
public class Substation {
    private int id;
    private String name;
    private String address;
    private String manager;
}
