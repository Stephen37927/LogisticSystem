package com.neusoft.dao;

import com.neusoft.entity.SignatureForm;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ISignatureFormDao {
    void addSignatureForm(SignatureForm signatureForm);

    int getMaxId();

    List<SignatureForm> getAllSignatureForm();

    SignatureForm getSignatureFormById(int id);

    void deleteSignatureFormById(int id);

    void updateSignatureFormById(SignatureForm signatureForm);

    List<SignatureForm> getSignatureFormByQuery(SignatureForm signatureForm);

    SignatureForm getSignatureFormByTaskId(int taskId);
}
