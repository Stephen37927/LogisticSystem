package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Substation;
import com.neusoft.service.ISubstationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/substation")
public class SubstationController {
    private final Logger logger = LoggerFactory.getLogger(SubstationController.class);
    @Autowired
    private ISubstationService iSubstationService;

    @RequestMapping(value = "/addSubstation")
    @ResponseBody
    public HttpResponseEntity addSubstation(@RequestBody Substation substation){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iSubstationService.addSubstation(substation);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addSubstation 添加分站>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllSubstation")
    @ResponseBody
    public HttpResponseEntity getAllSubstation(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Substation> substationList = iSubstationService.getSubstationList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(substationList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllSubstation 查询所有分站>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteSubstation")
    @ResponseBody
    public HttpResponseEntity deleteSubstationById(@RequestBody Substation substation){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSubstationService.getSubstationById(substation.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSubstationService.deleteSubstationById(substation.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteSubstationById 根据id删除分站>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getSubstationById/{id}")
    @ResponseBody
    public HttpResponseEntity getSubstationById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSubstationService.getSubstationById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Substation substation1 = iSubstationService.getSubstationById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(substation1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSubstationById 根据id查询分站>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateSubstationById")
    @ResponseBody
    public HttpResponseEntity updateSubstationById(@RequestBody Substation substation){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSubstationService.getSubstationById(substation.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSubstationService.updateSubstationById(substation);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateSubstationById 根据id修改分站>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getSubstationByQuery")
    @ResponseBody
    public HttpResponseEntity getSubstationByQuery(@RequestBody Substation substation, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize ){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSubstationService.getSubstationByQuery(substation)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Substation> substationList = iSubstationService.getSubstationByQuery(substation);
                PageInfo<Substation> pageInfo =new PageInfo<>(substationList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSubstationByQuery 根据query查询分站（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


}
