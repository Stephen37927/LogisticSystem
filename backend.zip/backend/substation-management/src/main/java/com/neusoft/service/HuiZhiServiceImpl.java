package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.bean.OrderItem;
import com.neusoft.common.bean.StoreItem;
import com.neusoft.common.utils.DateUtil;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.*;
import com.neusoft.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class HuiZhiServiceImpl implements IHuiZhiService {
    private static final String Cache_Key_Id = "huizhiid:";
    private static final String Cache_Key_List = "huizhilist";
    @Autowired
    private ISignatureFormService iSignatureFormService;

    @Autowired
    private ITaskService iTaskService;

    @Autowired
    private IOrderService iOrderService;

    @Autowired
    private IProductDao iProductDao;

    @Autowired
    private IHuiZhiDao iHuiZhiDao;

    @Autowired
    private  ISubstationService iSubstationService;

    @Autowired
    private ITaskDao iTaskDao;

    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private ISignatureFormDao iSignatureFormDao;
    @Autowired
    private IOrderDao iOrderDao;
    @Autowired
    private IStoreService iStoreService;
    @Override
    public void addHuiZhi(HuiZhi huiZhi) {
        List<OrderItem> huizhiItemList = huiZhi.getHuiZhiItemList();
        String huizhiItems = JSON.toJSONString(huizhiItemList);
        huiZhi.setHuiZhiItems(huizhiItems);

        int taskId = huiZhi.getTaskId();

        Task task = iTaskService.getTaskById(taskId);

        Order order = iOrderService.getOrderById(task.getOrderId());
        List<OrderItem> orderItemList = order.getOrderItemList();
        Substation substation = iSubstationService.getSubstationById(order.getSubStationId());
        double sumOriginalPrice = order.getSumPrice();

        if(task.getType().equals("送货收款")|| task.getType().equals("换货")){
            SignatureForm signatureForm = iSignatureFormService.getSignatureFormByTaskId(taskId);
            if(signatureForm.getStatus().equals("部分签收")){
                task.setStatus("部分完成");
                iTaskService.updateTaskById(task);

                //修改原订单的状态
                order.setStatus(9);
                iOrderService.updateOrderById(order);

                //产生一个退货订单

                //计算出退货的list
                List<OrderItem> orderItemsBackList = new ArrayList<>();
                for(OrderItem oi : huizhiItemList){
                    for (OrderItem oi2 : orderItemList){
                        OrderItem oiBack = new OrderItem();
                        if(oi.getProductId()== oi2.getProductId()){
                            oiBack.setProductId(oi.getProductId());
                            oiBack.setNum(oi2.getNum()-oi.getNum());
                            orderItemsBackList.add(oiBack);
                        }
                    }
                }
                double sumPrice = 0;
                for (OrderItem o: huizhiItemList){
                    int productId = o.getProductId();
                    int num = o.getNum();
                    Product product = iProductDao.getProductById(productId);
                    double price = product.getSellingPrice();
                    double discount = product.getDiscount();
                    double multiPrice = price*num*discount*0.1;
                    sumPrice = sumPrice + multiPrice;
                }

                Order orderBack = new Order();
                orderBack.setType(3);
                orderBack.setCustomerId(order.getCustomerId());
                orderBack.setOriginalOrderId(order.getId());
                orderBack.setReceiver(substation.getManager());
                orderBack.setDeliveryAddress(substation.getName());
                orderBack.setReceiverPhone("0");
                orderBack.setReason(huiZhi.getReason());
                orderBack.setSumPrice(sumPrice);
                orderBack.setReceiverPostCode(order.getReceiverPostCode());
                orderBack.setGenerationDate(DateUtil.getCurrentDate());
                orderBack.setStatus(1);
                orderBack.setId(0);
                orderBack.setIsReceipt(1);
                orderBack.setReason(huiZhi.getReason());
                orderBack.setSubStationId(order.getSubStationId());
                orderBack.setRequestArrivalDate(order.getRequestArrivalDate());
                orderBack.setOrderItemList(orderItemsBackList);
                iOrderService.addOrderPlus(orderBack);

                //签收的商品的价格
                double sumPrice2 = 0;
                for (OrderItem o: huizhiItemList){
                    int productId = o.getProductId();
                    int num = o.getNum();
                    Product product = iProductDao.getProductById(productId);
                    double price = product.getSellingPrice();
                    double discount = product.getDiscount();
                    double multiPrice = price*num*discount*0.1;
                    sumPrice2 = sumPrice2 + multiPrice;
                }

                //设置回执单的属性，总价和交款日期
                huiZhi.setSumOriginalPrice(sumPrice2);
                huiZhi.setBackPrice(order.getSumPrice()-sumPrice);
                System.out.println(signatureForm.getSignDate());
                huiZhi.setCollectionDate(signatureForm.getSignDate());
                huiZhi.setType("部分完成");

            }
            if(signatureForm.getStatus().equals("全部签收")){
                task.setStatus("已完成");
                iTaskService.updateTaskById(task);

                order.setStatus(8);
                iOrderService.updateOrderById(order);

                huiZhi.setSumOriginalPrice(sumOriginalPrice);
                huiZhi.setCollectionDate(signatureForm.getSignDate());
                huiZhi.setType("已完成");
            }
            if(signatureForm.getStatus().equals("拒收")){
                task.setStatus("失败");
                iTaskService.updateTaskById(task);

                //修改了订单的状态
                order.setStatus(11);
                iOrderService.updateOrderById(order);

                double sumPrice = 0;
                for (OrderItem o: huizhiItemList){
                    int productId = o.getProductId();
                    int num = o.getNum();
                    Product product = iProductDao.getProductById(productId);
                    double price = product.getSellingPrice();
                    double discount = product.getDiscount();
                    double multiPrice = price*num*discount*0.1;
                    sumPrice = sumPrice + multiPrice;
                }
                //产生一个退货订单

                Order orderBack = new Order();
                orderBack.setType(3);
                orderBack.setCustomerId(order.getCustomerId());
                orderBack.setOriginalOrderId(order.getId());
                orderBack.setReceiver(substation.getManager());
                orderBack.setDeliveryAddress(substation.getName());
                orderBack.setReceiverPhone("0");
                orderBack.setReason(huiZhi.getReason());
                orderBack.setSumPrice(sumPrice);
                orderBack.setReceiverPostCode(order.getReceiverPostCode());
                orderBack.setGenerationDate(DateUtil.getCurrentDate());
                orderBack.setStatus(1);
                orderBack.setId(0);
                orderBack.setIsReceipt(1);
                orderBack.setSubStationId(order.getSubStationId());
                orderBack.setRequestArrivalDate(order.getRequestArrivalDate());
                orderBack.setReason(huiZhi.getReason());
                orderBack.setOrderItemList(order.getOrderItemList());
                iOrderService.addOrderPlus(orderBack);

                //修改回执单的属性
                huiZhi.setSumOriginalPrice(sumOriginalPrice);
                huiZhi.setCollectionDate(signatureForm.getSignDate());
                huiZhi.setType("失败");
            }
        }
        if(task.getType().equals("退货") && task.getStatus().equals("待回执")){
            Order order2 = iOrderService.getOrderById(order.getOriginalOrderId());
            if(order2.getType()==2){
                Order orderNew = checkProduct(order2);

                iOrderService.updateOrderById(orderNew);
            }
            task.setStatus("已完成");
            iTaskService.updateTaskById(task);

            //修改了订单的状态
            order.setStatus(8);
            System.out.println(order);
            iOrderDao.updateOrderById(order);



            //设置回执单的属性，总价和交款日期
            System.out.println(order);
            huiZhi.setSumOriginalPrice(order2.getSumPrice());
            huiZhi.setBackPrice(order.getSumPrice());
            Date date = order.getGenerationDate();
            huiZhi.setCollectionDate(date);
            huiZhi.setType("完成");
            System.out.println(huiZhi);
        }
        huiZhi.setSubStationId(order.getSubStationId());
        System.out.println(huiZhi);
        iHuiZhiDao.addHuiZhi(huiZhi);
        int maxid = iHuiZhiDao.getMaxId();
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,huiZhi,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<HuiZhi> getAllHuiZhi() {
        List<HuiZhi> huiZhiRedis = (List<HuiZhi>)redisUtil.get(Cache_Key_List);
        if (huiZhiRedis != null){
            for (HuiZhi hz:huiZhiRedis){
                List<OrderItem> huiZhiItemList = JSON.parseArray(hz.getHuiZhiItems(),OrderItem.class);
                hz.setHuiZhiItemList(huiZhiItemList);
            }
            System.out.println("list存在redis");
            return huiZhiRedis;
        }

        System.out.println("list不存在redis");
        List<HuiZhi> huiZhiList = iHuiZhiDao.getAllHuiZhi();
        for (HuiZhi hz:huiZhiList){
            List<OrderItem> huiZhiItemList = JSON.parseArray(hz.getHuiZhiItems(),OrderItem.class);
            hz.setHuiZhiItemList(huiZhiItemList);
        }
        redisUtil.setex(Cache_Key_List, huiZhiList,100);
        return huiZhiList;
    }

    @Override
    public HuiZhi getHuiZhiById(int id) {
        String key = Cache_Key_Id + id;
        HuiZhi huiZhiRedis = (HuiZhi) redisUtil.get(key);
        if (huiZhiRedis != null){
            System.out.println("id存在redis");
            List<OrderItem> huiZhiItemsList = JSON.parseArray(huiZhiRedis.getHuiZhiItems(),OrderItem.class);
            huiZhiRedis.setHuiZhiItemList(huiZhiItemsList);
            return huiZhiRedis;
        }

        System.out.println("id不存在redis");
        HuiZhi huiZhi = iHuiZhiDao.getHuiZhiById(id);
        List<OrderItem> huiZhiItemsList = JSON.parseArray(huiZhi.getHuiZhiItems(),OrderItem.class);
        huiZhi.setHuiZhiItemList(huiZhiItemsList);
        redisUtil.setex(key, huiZhi,100);
        return huiZhi;
    }

    @Override
    public void deleteHuiZhiById(int id) {
        iHuiZhiDao.deleteHuiZhiById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateHuiZhiById(HuiZhi huiZhi) {
        iHuiZhiDao.updateHuiZhiById(huiZhi);

        HuiZhi huiZhi1 = iHuiZhiDao.getHuiZhiById(huiZhi.getId());
        String key = Cache_Key_Id + huiZhi.getId();
        redisUtil.setex(key, huiZhi1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<HuiZhi> getHuiZhiByQuery(HuiZhi huiZhi) {
        List<HuiZhi> huiZhiList = iHuiZhiDao.getHuiZhiByQuery(huiZhi);

        for (HuiZhi hz:huiZhiList){
            List<OrderItem> huiZhiItemList = JSON.parseArray(hz.getHuiZhiItems(),OrderItem.class);
            hz.setHuiZhiItemList(huiZhiItemList);
        }

        return huiZhiList;
    }
    private Order checkProduct(Order order) {
        List<OrderItem> list = order.getOrderItemList();
        //去中心库房看一下有没有缺货
        for (OrderItem o : list){
            Map<String,Object> map = iStoreService.getItemByProductId(1,o.getProductId());
            StoreItem storeItem = JSON.parseObject(JSON.toJSONString(map.get("storeItem")),StoreItem.class);
            if (storeItem.getUnallocatedNum()<o.getNum()){
                order.setStatus(2);
                break;
            }else {
                order.setStatus(1);
            }
        }
        return order;
    }

    @Override
    public List<Map<String, Object>> getHuiZhiByQueryPlus(HuiZhi huiZhi) {
          List<Map<String,Object>> returnMap = new ArrayList<>();
          List<HuiZhi> huiZhiList = iHuiZhiDao.getHuiZhiByQuery(huiZhi);
          for (HuiZhi hz:huiZhiList){
              Task task = new Task();
              task.setId(hz.getTaskId());
              List<Map<String,Object>> taskMap = iTaskService.getTaskByQuery(task);
              List<Map<String, Object>> huiZhiItemsMap = getHuiZhiItemsByQuery(hz);
              Map<String,Object> mapSub = new HashMap<>();

             mapSub.put("huiZhi",hz);
             mapSub.put("huiZhiItemsMap",huiZhiItemsMap);
             mapSub.put("taskMap",taskMap);
             returnMap.add(mapSub);
        }
        return returnMap;
    }

    private List<Map<String, Object>> getHuiZhiItemsByQuery(HuiZhi huiZhi) {
        HuiZhi huiZhi1 = getHuiZhiById(huiZhi.getId());
        List<OrderItem> orderItems = huiZhi1.getHuiZhiItemList();
        System.out.println(huiZhi1);
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        for (OrderItem oi: orderItems){
            Map<String, Object> oimap = new HashMap<String, Object>();
            Product product = iProductDao.getProductById(oi.getProductId());
            System.out.println(product);
            oimap.put("product",product);
            oimap.put("num",oi.getNum());
            mapList.add(oimap);
        }
        return mapList;
    }
}
