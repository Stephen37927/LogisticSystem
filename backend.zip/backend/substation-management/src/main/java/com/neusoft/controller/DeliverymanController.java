package com.neusoft.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.entity.Deliveryman;
import com.neusoft.service.IDeliverymanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin
@RequestMapping("/deliveryman")
public class DeliverymanController {
    private final Logger logger = LoggerFactory.getLogger(DeliverymanController.class);
    @Autowired
    private IDeliverymanService iDeliverymanService;

    @RequestMapping(value = "/addDeliveryman")
    @ResponseBody
    public HttpResponseEntity addDeliveryman(@RequestBody Deliveryman deliveryman){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iDeliverymanService.addDeliveryman(deliveryman);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addDeliveryman 添加配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllDeliveryman")
    @ResponseBody
    public HttpResponseEntity getAllDeliveryman(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<Deliveryman> deliverymanList = iDeliverymanService.getDeliverymanList();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(deliverymanList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllDeliveryman 查询所有配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteDeliveryman")
    @ResponseBody
    public HttpResponseEntity deleteDeliverymanById(@RequestBody Deliveryman deliveryman){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDeliverymanService.getDeliverymanById(deliveryman.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iDeliverymanService.deleteDeliverymanById(deliveryman.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteDeliverymanById 根据id删除配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getDeliverymanById/{id}")
    @ResponseBody
    public HttpResponseEntity getDeliverymanById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDeliverymanService.getDeliverymanById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                Deliveryman deliveryman1 = iDeliverymanService.getDeliverymanById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(deliveryman1);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getDeliverymanById 根据id查询配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/updateDeliverymanById")
    @ResponseBody
    public HttpResponseEntity updateDeliverymanById(@RequestBody Deliveryman deliveryman){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDeliverymanService.getDeliverymanById(deliveryman.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iDeliverymanService.updateDeliverymanById(deliveryman);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateDeliverymanById 根据id修改配送员>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getDeliverymanByQuery")
    @ResponseBody
    public HttpResponseEntity getDeliverymanByQuery(@RequestBody Deliveryman deliveryman, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize ){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iDeliverymanService.getDeliverymanByQuery(deliveryman)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                PageHelper.startPage(pageNum,pageSize);
                List<Deliveryman> deliverymanList = iDeliverymanService.getDeliverymanByQuery(deliveryman);
                PageInfo<Deliveryman> pageInfo =new PageInfo<>(deliverymanList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageInfo);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getDeliverymanByQuery 根据query查询配送员（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
