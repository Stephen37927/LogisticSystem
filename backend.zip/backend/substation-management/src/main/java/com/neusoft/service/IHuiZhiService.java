package com.neusoft.service;

import com.neusoft.entity.HuiZhi;

import java.util.List;
import java.util.Map;

public interface IHuiZhiService {
    void addHuiZhi(HuiZhi huiZhi);

    List<HuiZhi> getAllHuiZhi();

    HuiZhi getHuiZhiById(int id);

    void deleteHuiZhiById(int id);

    void updateHuiZhiById(HuiZhi huiZhi);

    List<HuiZhi> getHuiZhiByQuery(HuiZhi huiZhi);

    List<Map<String, Object>> getHuiZhiByQueryPlus(HuiZhi huiZhi);
}
