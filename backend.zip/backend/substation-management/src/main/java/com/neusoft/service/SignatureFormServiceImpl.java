package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.ISignatureFormDao;
import com.neusoft.dao.ITaskDao;
import com.neusoft.entity.Order;
import com.neusoft.entity.SignatureForm;
import com.neusoft.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SignatureFormServiceImpl implements ISignatureFormService{
    private static final String Cache_Key_Id = "signatureformid:";
    private static final String Cache_Key_List = "signatureformlist";



    @Autowired
    private ISignatureFormDao iSignatureFormDao;

    @Autowired
    private ITaskService iTaskService;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private ITaskDao iTaskDao;

    @Override
    public void addSignatureForm(SignatureForm signatureForm) {
        //配送员信息，还要生成一个调拨出库单
        signatureForm.setStatus("初始状态");
        iSignatureFormDao.addSignatureForm(signatureForm);

        int maxid = iSignatureFormDao.getMaxId();
        signatureForm.setId(maxid);

        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key,signatureForm,100);
        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<SignatureForm> getAllSignatureForm() {
        List<SignatureForm> signatureFormListRedis = (List<SignatureForm>)redisUtil.get(Cache_Key_List);
        if (signatureFormListRedis != null){
            System.out.println("list存在redis");
            return signatureFormListRedis;
        }

        System.out.println("list不存在redis");
        List<SignatureForm> signatureFormList = iSignatureFormDao.getAllSignatureForm();
        redisUtil.setex(Cache_Key_List, signatureFormList,100);
        return signatureFormList;
    }

    @Override
    public SignatureForm getSignatureFormById(int id) {
        String key = Cache_Key_Id + id;
        SignatureForm signatureFormRedis = (SignatureForm) redisUtil.get(key);
        if (signatureFormRedis != null){
            System.out.println("id存在redis");
            return signatureFormRedis;
        }

        System.out.println("id不存在redis");
        SignatureForm signatureForm = iSignatureFormDao.getSignatureFormById(id);
        redisUtil.setex(key, signatureForm,100);
        return signatureForm;
    }

    @Override
    public SignatureForm getSignatureFormByTaskId(int taskId) {
        SignatureForm signatureForm = iSignatureFormDao.getSignatureFormByTaskId(taskId);
        return signatureForm;
    }

    @Override
    public void deleteSignatureFormById(int id) {
        iSignatureFormDao.deleteSignatureFormById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public void updateSignatureFormById(SignatureForm signatureForm) {

        Task task = iTaskDao.getTaskById(signatureForm.getTaskId());
        task.setStatus("待回执");
        iTaskDao.updateTaskById(task);
        iSignatureFormDao.updateSignatureFormById(signatureForm);

        SignatureForm signatureForm1 = iSignatureFormDao.getSignatureFormById(signatureForm.getId());
        String key = Cache_Key_Id + signatureForm.getId();
        redisUtil.setex(key, signatureForm1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Map<String, Object>> getSignatureFormByQuery(SignatureForm signatureForm) {
        List<Map<String,Object>> returnMap = new ArrayList<>();
        List<SignatureForm> signatureFormList = iSignatureFormDao.getSignatureFormByQuery(signatureForm);
        for (SignatureForm signatureFormSub : signatureFormList){
            Map<String,Object> mapSub = new HashMap<>();
            Task task = iTaskService.getTaskById(signatureFormSub.getTaskId());
            List<Map<String,Object>> taskMapList = iTaskService.getTaskByQuery(task);
            Map<String,Object> taskMap = taskMapList.get(0);

            mapSub.put("taskMap", taskMap);
            mapSub.put("signatureForm",signatureFormSub);

            returnMap.add(mapSub);

        }
        return returnMap;
    }

}
