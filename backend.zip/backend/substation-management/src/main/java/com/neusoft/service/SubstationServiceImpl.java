package com.neusoft.service;

import com.alibaba.fastjson.JSON;
import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IHuiZhiDao;
import com.neusoft.dao.IProductDao;
import com.neusoft.dao.ISubstationDao;
import com.neusoft.entity.Deliveryman;
import com.neusoft.entity.HuiZhi;
import com.neusoft.entity.Product;
import com.neusoft.entity.Substation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SubstationServiceImpl implements ISubstationService{
    private static final String Cache_Key_Id = "substationid:";
    private static final String Cache_Key_List = "substationlist";

    @Autowired
    private IDeliverymanService iDeliverymanService;

    @Autowired
    private ISubstationDao iSubstationDao;
    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private IProductDao iProductDao;

    @Autowired
    private IHuiZhiService iHuiZhiService;



    @Override
    public void addSubstation(Substation substation) {
        iSubstationDao.addSubstation(substation);

        int maxid = iSubstationDao.getMaxId();
        substation.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key, substation,100);

        redisUtil.del(Cache_Key_List);

    }

    @Override
    public List<Substation> getSubstationList() {
        List<Substation> substationListRedis = (List<Substation>)redisUtil.get(Cache_Key_List);
        if (substationListRedis != null){
            System.out.println("list存在redis");
            return substationListRedis;
        }

        System.out.println("list不存在redis");
        List<Substation> substationList = iSubstationDao.getSubstationList();
        redisUtil.setex(Cache_Key_List, substationList,100);
        return substationList;
    }

    @Override
    public void deleteSubstationById(int id) {
        Substation substation = getSubstationById(id);
        iSubstationDao.deleteSubstationById(id);

        //删分站的同时把分站的配送员也删了
        Deliveryman deliveryman = new Deliveryman();
        deliveryman.setSubstationId(id);
        List<Deliveryman> list = iDeliverymanService.getDeliverymanByQuery(deliveryman);
        for (Deliveryman d : list){
            iDeliverymanService.deleteDeliverymanById(d.getId());
        }

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Substation getSubstationById(int id) {
        String key = Cache_Key_Id + id;
        Substation substationRedis = (Substation)redisUtil.get(key);
        if (substationRedis != null){
            System.out.println("id存在redis");
            return substationRedis;
        }

        System.out.println("id不存在redis");
        Substation substation = iSubstationDao.getSubstationById(id);
        redisUtil.setex(key, substation,100);
        return substation;
    }

    @Override
    public void updateSubstationById(Substation substation) {
        iSubstationDao.updateSubstationById(substation);

        String key = Cache_Key_Id + substation.getId();
        redisUtil.setex(key, substation,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Substation> getSubstationByQuery(Substation substation) {

        List<Substation> list = iSubstationDao.getSubstationByQuery(substation);
        return list;
    }

}
