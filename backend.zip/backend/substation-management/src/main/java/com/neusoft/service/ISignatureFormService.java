package com.neusoft.service;

import com.neusoft.entity.SignatureForm;

import java.util.List;
import java.util.Map;

public interface ISignatureFormService {
    void addSignatureForm(SignatureForm signatureForm);

    List<SignatureForm> getAllSignatureForm();

    SignatureForm getSignatureFormById(int id);
    SignatureForm getSignatureFormByTaskId(int taskId);

    void deleteSignatureFormById(int id);

    void updateSignatureFormById(SignatureForm signatureForm);

    List<Map<String, Object>> getSignatureFormByQuery(SignatureForm signatureForm);

}
