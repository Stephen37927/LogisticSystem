package com.neusoft.dao;

import com.neusoft.entity.HuiZhi;
import com.neusoft.entity.SignatureForm;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IHuiZhiDao {
    void addHuiZhi(HuiZhi huiZhi);

    int getMaxId();

    List<HuiZhi> getAllHuiZhi();

    HuiZhi getHuiZhiById(int id);

    void deleteHuiZhiById(int id);

    void updateHuiZhiById(HuiZhi huiZhi);

    List<HuiZhi> getHuiZhiByQuery(HuiZhi huiZhi);
}
