package com.neusoft.service;

import com.neusoft.common.utils.RedisUtil;
import com.neusoft.dao.IDeliverymanDao;
import com.neusoft.entity.Deliveryman;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeliverymanServiceImpl implements IDeliverymanService{
    private static final String Cache_Key_Id = "deliverymanid:";
    private static final String Cache_Key_List = "deliverymanlist";

    @Autowired
    private IDeliverymanDao iDeliverymanDao;
    @Autowired
    private RedisUtil redisUtil;



    @Override
    public void addDeliveryman(Deliveryman deliveryman) {
        iDeliverymanDao.addDeliveryman(deliveryman);

        int maxid = iDeliverymanDao.getMaxId();
        deliveryman.setId(maxid);
        String key = Cache_Key_Id + maxid;
        redisUtil.setex(key, deliveryman,100);

        redisUtil.del(Cache_Key_List);

    }
    @Override
    public List<Deliveryman> getDeliverymanList() {
        List<Deliveryman> deliverymanListRedis = (List<Deliveryman>)redisUtil.get(Cache_Key_List);
        if (deliverymanListRedis != null){
            System.out.println("list存在redis");
            return deliverymanListRedis;
        }

        System.out.println("list不存在redis");
        List<Deliveryman> deliverymanList = iDeliverymanDao.getDeliverymanList();
        redisUtil.setex(Cache_Key_List, deliverymanList,100);
        return deliverymanList;
    }

    @Override
    public void deleteDeliverymanById(int id) {
        Deliveryman deliveryman = getDeliverymanById(id);
        iDeliverymanDao.deleteDeliverymanById(id);

        String key = Cache_Key_Id + id;
        redisUtil.del(key);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public Deliveryman getDeliverymanById(int id) {
        String key = Cache_Key_Id + id;
        Deliveryman deliverymanRedis = (Deliveryman)redisUtil.get(key);
        if (deliverymanRedis != null){
            System.out.println("id存在redis");
            return deliverymanRedis;
        }

        System.out.println("id不存在redis");
        Deliveryman deliveryman = iDeliverymanDao.getDeliverymanById(id);
        redisUtil.setex(key, deliveryman,100);
        return deliveryman;
    }

    @Override
    public void updateDeliverymanById(Deliveryman deliveryman) {
        iDeliverymanDao.updateDeliverymanById(deliveryman);

        Deliveryman deliveryman1 = iDeliverymanDao.getDeliverymanById(deliveryman.getId());
        String key = Cache_Key_Id + deliveryman.getId();
        redisUtil.setex(key, deliveryman1,100);

        redisUtil.del(Cache_Key_List);
    }

    @Override
    public List<Deliveryman> getDeliverymanByQuery(Deliveryman deliveryman) {

        List<Deliveryman> list = iDeliverymanDao.getDeliverymanByQuery(deliveryman);
        return list;
    }
}
