package com.neusoft.service;

import com.neusoft.entity.Substation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface ISubstationService {
    void addSubstation(Substation substation);
    List<Substation> getSubstationList();

    void deleteSubstationById(int id);

    Substation getSubstationById(int id);

    void updateSubstationById(Substation substation);

    List<Substation> getSubstationByQuery(Substation substation);

}
