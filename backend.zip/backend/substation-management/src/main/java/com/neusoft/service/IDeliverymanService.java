package com.neusoft.service;

import com.neusoft.entity.Deliveryman;

import java.util.List;

public interface IDeliverymanService {
    void addDeliveryman(Deliveryman deliveryman);
    List<Deliveryman> getDeliverymanList();

    void deleteDeliverymanById(int id);

    Deliveryman getDeliverymanById(int id);

    void updateDeliverymanById(Deliveryman deliveryman);

    List<Deliveryman> getDeliverymanByQuery(Deliveryman deliveryman);
}
