package com.neusoft.controller;


import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.PageResult;
import com.neusoft.entity.SignatureForm;
import com.neusoft.service.ISignatureFormService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/signatureForm")
public class SignatureFormController {
    private final Logger logger = LoggerFactory.getLogger(SignatureFormController.class);

    @Autowired
    private ISignatureFormService iSignatureFormService;

    @RequestMapping(value = "/addSignatureForm")
    @ResponseBody
    HttpResponseEntity addSignatureFovhbrm(@RequestBody SignatureForm signatureForm){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iSignatureFormService.addSignatureForm(signatureForm);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addSignatureForm 添加签收单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllSignatureForm")
    @ResponseBody
    public HttpResponseEntity getAllSignatureForm(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<SignatureForm> signatureFormList = iSignatureFormService.getAllSignatureForm();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(signatureFormList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllSignatureForm 查询所有签收单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteSignatureForm")
    @ResponseBody
    public HttpResponseEntity deleteSignatureFormById(@RequestBody SignatureForm signatureForm){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSignatureFormService.getSignatureFormById(signatureForm.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSignatureFormService.deleteSignatureFormById(signatureForm.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteSignatureFormById 根据id删除签收单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getSignatureFormById/{id}")
    @ResponseBody
    public HttpResponseEntity getSignatureFormById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSignatureFormService.getSignatureFormById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                SignatureForm signatureForm = iSignatureFormService.getSignatureFormById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(signatureForm);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSignatureFormById 根据id查询签收单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/updateSignatureFormById")
    @ResponseBody
    public HttpResponseEntity updateSignatureFormById(@RequestBody SignatureForm signatureForm){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSignatureFormService.getSignatureFormByTaskId(signatureForm.getTaskId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iSignatureFormService.updateSignatureFormById(signatureForm);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateSignatureFormById 根据id修改签收单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }




    @RequestMapping(value = "/getSignatureFormByQuery")
    @ResponseBody
    public HttpResponseEntity getSignatureFormByQuery(@RequestBody SignatureForm signatureForm, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iSignatureFormService.getSignatureFormByQuery(signatureForm)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                List<Map<String,Object>> signatureFormList = iSignatureFormService.getSignatureFormByQuery(signatureForm);
                int totalItems = signatureFormList.size();
                if (totalItems > pageSize) {
                    int toIndex = pageSize * pageNum;
                    if (toIndex > totalItems) {
                        toIndex = totalItems;
                    }
                    signatureFormList = signatureFormList.subList(pageSize * (pageNum - 1), toIndex);
                }
                PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,signatureFormList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageResult);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getSignatureFormByQuery 根据query查询签收单（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
