package com.neusoft.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.neusoft.common.bean.OrderItem;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class HuiZhi {
    private int id;
    private int taskId;
    private String huiZhiItems;
    private List<OrderItem> huiZhiItemList;
    private String customerSatisfaction;
    private String comment;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date collectionDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date startDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date finishDate;
    private double sumOriginalPrice;

    private double backPrice;

    private String type;

    private String reason;

    private  int subStationId;}
