package com.neusoft.dao;

import com.neusoft.entity.Deliveryman;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IDeliverymanDao {
    Deliveryman getDeliverymanById(int id);//根据id获取分站

    void addDeliveryman(Deliveryman deliveryman);//增加分站

    List<Deliveryman> getDeliverymanList();//获取分站列表

    void deleteDeliverymanById(int id);//根据id删除分站

    void updateDeliverymanById(Deliveryman deliveryman);

    List<Deliveryman> getDeliverymanByQuery(Deliveryman deliveryman);

    int getMaxId();
}
