package com.neusoft.controller;


import com.neusoft.common.Constans;
import com.neusoft.common.bean.HttpResponseEntity;
import com.neusoft.common.bean.PageResult;
import com.neusoft.entity.HuiZhi;

import com.neusoft.service.IHuiZhiService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@CrossOrigin
@RequestMapping("/huizhi")
public class HuiZhiController {
    private final Logger logger = LoggerFactory.getLogger(HuiZhiController.class);

    @Autowired
    private IHuiZhiService iHuiZhiService;

    @RequestMapping(value = "/addHuiZhi")
    @ResponseBody
    HttpResponseEntity addHuiZhi(@RequestBody HuiZhi huiZhi){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            iHuiZhiService.addHuiZhi(huiZhi);
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(null);
            httpResponseEntity.setMessage(Constans.ADD_MESSAGE);
        }catch (Exception e){
            logger.info("addHuiZhi 添加回执单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping("/getAllHuiZhi")
    @ResponseBody
    public HttpResponseEntity getAllHuiZhi(){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<HuiZhi> HuiZhiList = iHuiZhiService.getAllHuiZhi();
            httpResponseEntity.setCode(Constans.SUCCESS_CODE);
            httpResponseEntity.setData(HuiZhiList);
            httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
        }catch (Exception e){
            logger.info("getAllHuiZhi 查询所有回执单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/deleteHuiZhi")
    @ResponseBody
    public HttpResponseEntity deleteHuiZhiById(@RequestBody HuiZhi huiZhi){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iHuiZhiService.getHuiZhiById(huiZhi.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iHuiZhiService.deleteHuiZhiById(huiZhi.getId());
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.DELETE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("deleteHuiZhiById 根据id删除回执单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }

    @RequestMapping(value = "/getHuiZhiById/{id}")
    @ResponseBody
    public HttpResponseEntity getHuiZhiById(@PathVariable int id){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iHuiZhiService.getHuiZhiById(id)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                HuiZhi HuiZhi = iHuiZhiService.getHuiZhiById(id);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(HuiZhi);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getHuiZhiById 根据id查询回执单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/updateHuiZhiById")
    @ResponseBody
    public HttpResponseEntity updateHuiZhiById(@RequestBody HuiZhi huiZhi){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iHuiZhiService.getHuiZhiById(huiZhi.getId())==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                iHuiZhiService.updateHuiZhiById(huiZhi);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.UPDATE_MESSAGE);
            }
        }catch (Exception e){
            logger.info("updateHuiZhiById 根据id修改回执单>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }


    @RequestMapping(value = "/getHuiZhiByQuery")
    @ResponseBody
    public HttpResponseEntity getHuiZhiByQuery(@RequestBody HuiZhi HuiZhi, @RequestParam("pageNum") Integer pageNum, @RequestParam("PageSize") Integer pageSize){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            if(iHuiZhiService.getHuiZhiByQuery(HuiZhi)==null){
                httpResponseEntity.setCode(Constans.EXIST_CODE);
                httpResponseEntity.setData(null);
                httpResponseEntity.setMessage(Constans.MESSAGE_NULL);
            }else{
                List<Map<String,Object>> HuiZhiList = iHuiZhiService.getHuiZhiByQueryPlus(HuiZhi);
                int totalItems = HuiZhiList.size();
                if (totalItems > pageSize) {
                    int toIndex = pageSize * pageNum;
                    if (toIndex > totalItems) {
                        toIndex = totalItems;
                    }
                    HuiZhiList = HuiZhiList.subList(pageSize * (pageNum - 1), toIndex);
                }
                PageResult<Map<String,Object>> pageResult = new PageResult<>(pageNum, pageSize,(totalItems + pageSize - 1) / pageSize, totalItems,HuiZhiList);
                httpResponseEntity.setCode(Constans.SUCCESS_CODE);
                httpResponseEntity.setData(pageResult);
                httpResponseEntity.setMessage(Constans.STATUS_MESSAGE);
            }
        }catch (Exception e){
            logger.info("getHuiZhiByQuery 根据query查询签收单（支持模糊查询）>>>>>>>>>>>" + e.getLocalizedMessage());
            httpResponseEntity.setCode(Constans.EXIST_CODE);
            httpResponseEntity.setMessage(Constans.EXIST_MESSAGE);
        }
        return httpResponseEntity;
    }
}
