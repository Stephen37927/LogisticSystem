package com.neusoft.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.neusoft.common.bean.OrderItem;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class SignatureForm {
    private int id;
    private int taskId;
    private String comment;
    private String feedback;
    private String sign;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date signDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date startDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date finishDate;

    private String signItems;
    private List<OrderItem> signItemList;
    private String status;

}
