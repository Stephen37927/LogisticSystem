package com.neusoft.dao;

import com.neusoft.entity.Substation;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ISubstationDao {
    Substation getSubstationById(int id);//根据id获取分站

    void addSubstation(Substation substation);//增加分站

    List<Substation> getSubstationList();//获取分站列表

    void deleteSubstationById(int id);//根据id删除分站

    void updateSubstationById(Substation substation);

    List<Substation> getSubstationByQuery(Substation substation);

    int getMaxId();
}
