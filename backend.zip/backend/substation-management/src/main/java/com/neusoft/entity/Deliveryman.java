package com.neusoft.entity;

import lombok.Data;

@Data
public class Deliveryman {
    private int id;
    private String name;
    private int substationId;
}
