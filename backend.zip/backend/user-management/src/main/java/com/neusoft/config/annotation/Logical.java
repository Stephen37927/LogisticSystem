package com.neusoft.config.annotation;

public enum Logical {
    AND, OR
}

